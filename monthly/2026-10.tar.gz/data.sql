--
-- PostgreSQL database dump
--


-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, full_name, role, created_at, status, username) FROM stdin;
a6271f16-534a-4325-aee1-5ed0ab3eb261	Agyemang Casper	admin	2026-10-09 10:06:17.85286+00	approved	palatipus
34cb4aa6-890b-4397-bf22-95f48620affa	Sylvester Kuffour Paul	admin	2026-10-09 10:18:41.22666+00	approved	sly
82735742-c8fd-4042-b60f-67a9fca0d0ab	Kelvin Osei gyamfi kwaku	admin	2026-10-15 16:14:17.390092+00	approved	kelvin
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_settings (id, data, updated_by, updated_at) FROM stdin;
1	{"bank": {"name": "CAL BANK", "account": "1400004948868", "merchantNo": "0598591194", "accountName": "WORKING FOR GOD VENTURES"}, "name": "WORKING FOR GOD VENTURES", "email": "oseigyamfikelvinkwaku@gmail.com", "phone": "0549576787", "terms": ["Payment shall be made in accordance with the agreed terms. Cash customers are required to pay immediately unless otherwise agreed in writing. For credit customers, payment is due on or before the agreed due date.", "Customers are requested to inspect all goods upon delivery. Any shortages, damages or discrepancies should be reported within 12 hours of receipt.", "Please quote the invoice number in all payments and correspondence relating to this transaction. This invoice serves as evidence of the transaction and should be retained for your records.", "When mobile money, bank transfer or any other payment is made, please send a screenshot or take a picture of the slip and send it to this WhatsApp number 0549576787."], "address": ["Behind Roman Catholic Church, Bantama.", "Adjacent Atwima Kwawoma Rural Bank Ltd", "Closer to Race Course"], "tagline": "Mindray specialists  |  Lab equipment, reagents and training", "whatsapp": "0549576787", "defaultDueDays": null}	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:49:46.364673+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, email, location, created_at) FROM stdin;
258d7a7d-9240-4d4e-9204-2a31ea55792c	Sonoscan	\N	\N	\N	2026-10-15 13:55:39.263286+00
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (username, attempted_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_id, salesperson_id, notes, created_at, previous_balance, due_date, cancelled_at, cancelled_by, cancel_reason, customer_name, customer_phone, customer_location, opening_amount) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, message, order_id, is_read, created_at, link) FROM stdin;
e3d463fa-c520-4aec-91ef-382ff709d14d	a6271f16-534a-4325-aee1-5ed0ab3eb261	Kelvin Osei gyamfi kwaku signed up and is waiting for approval	\N	t	2026-10-15 16:14:17.390092+00	\N
57ca2276-7318-4ceb-9f94-f75b8881bcb8	34cb4aa6-890b-4397-bf22-95f48620affa	Kelvin Osei gyamfi kwaku signed up and is waiting for approval	\N	t	2026-10-15 16:14:17.390092+00	\N
1fb181b8-b3e3-4663-bea9-a5af2590f795	a6271f16-534a-4325-aee1-5ed0ab3eb261	Diff Lyse is running low: 5 left	\N	f	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
00a0193a-c097-4ce0-ba45-47b34fb6e7c1	34cb4aa6-890b-4397-bf22-95f48620affa	Diff Lyse is running low: 5 left	\N	f	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
4219aee0-e3bd-4d1e-9283-fa8ad22cda73	82735742-c8fd-4042-b60f-67a9fca0d0ab	Diff Lyse is running low: 5 left	\N	f	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, category, brand, description, image_url, stock_qty, reorder_level, is_active, created_at) FROM stdin;
ead2b374-e435-4025-bead-d804071dda77	AST	reagent	Mindray	Aspartate Aminotransferase (historically known as SGOT), a crucial enzyme biomarker used to evaluate liver function, cardiac injury, and muscle diseases.	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9db64f89-1cd7-45fc-ad63-30ad61413d94.jpeg	1	5	t	2026-10-12 08:28:02.964028+00
d6d4fda9-6087-410a-8bc9-0a5622f40e32	GGT	reagent	Mindray	A GGT (Gamma-Glutamyltransferase) reagent is an in vitro diagnostic chemical kit used in clinical chemistry analyzers to quantitatively measure GGT enzyme activity in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/92faba04-454d-4ac6-afb1-4041cffb953e.jpeg	8	5	t	2026-10-15 10:16:43.503611+00
9ff4f240-9f00-460f-87f1-e745c6647e36	ALT	reagent	Mindray	ALT (Alanine Aminotransferase / GPT) reagent is an in vitro diagnostic chemical kit used to measure the activity of the ALT enzyme in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/22b5bcdb-27b8-4824-9673-a35f79076567.jpeg	1	5	t	2026-10-15 10:20:54.41821+00
dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	DBil	reagent	Mindray	Direct Bilirubin (Bil-D / D-Bil) is an in-vitro diagnostic (IVD) clinical chemistry reagent used for the quantitative determination of direct (conjugated) bilirubin in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/616cb355-313a-4d3a-8bac-d66529963d59.jpeg	1	5	t	2026-10-15 10:24:21.942008+00
51291b09-5c9c-4ece-b5ab-caab1507e9e2	CKMB	reagent	Mindray	CK-MB reagent is an in-vitro diagnostic test kit used to quantitatively measure the activity or concentration of Creatine Kinase-MB (CK-MB) in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e164c06c-5d42-4653-a27b-d0db49fe396c.png	4	5	t	2026-10-15 10:25:58.340328+00
a3bcccdf-2488-4ee9-a784-1ece4fab3df0	Total Protein(TP)	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8f5ceece-e525-4358-8688-d87870719f26.jpeg	1	5	t	2026-10-15 10:49:12.545901+00
e32d59af-01ec-496c-9be5-ae5285d46a1a	LDL-C	reagent	Mindray	LDL cholesterol reagent is a two-part clinical chemistry diagnostic kit used for the direct, quantitative measurement of low-density lipoprotein cholesterol (LDL-C) in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/83e107d1-96c6-41c8-8276-e407d23abb9a.jpeg	1	5	t	2026-10-15 10:28:01.36808+00
427a9551-fb8c-45c7-9076-19c9ee015002	Magnesium	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/295f9d3e-7d85-4230-8819-e9f716a65e70.jpeg	4	5	t	2026-10-15 10:32:06.816804+00
5a58c58c-8ed5-4082-a9e3-3d91b026c57d	Calcium	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0fdada34-3160-42c0-a188-fbcaac990a59.jpeg	1	5	t	2026-10-15 10:39:35.551033+00
91abfef3-d9b8-40d2-9109-a66e97f2607c	TBil	reagent	Mindray	Bil-T stands for Total Bilirubin (T-Bil), an in-vitro diagnostic clinical chemistry reagent used to measure total bilirubin levels in serum and plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7c5f0487-98ff-49b4-8331-70286a3036e8.jpeg	2	5	t	2026-10-15 10:23:13.086882+00
9c309e3f-ca58-4ed7-b6f8-1ff19b498864	Glucose	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/3687d599-a3c0-480b-90c7-c669b462d48f.jpeg	2	5	t	2026-10-15 10:33:13.16359+00
6452048e-904a-481d-9879-dfbc9b3b89ba	Phosphorus	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/af0bf0af-12c2-484c-8a35-8e1578136f5a.jpeg	2	5	t	2026-10-15 10:38:05.678202+00
81ef7ace-0699-42db-85ba-4c050a08a008	LDH	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8597a079-adbb-4fd4-93d2-ffa486624ad6.jpeg	1	5	t	2026-10-15 10:44:07.506625+00
ea5ebf85-f433-452c-ba48-3f8c921b68c0	Control Level 1	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/836ae23d-374d-46f5-82b5-9a6391ea666c.jpeg	16	5	t	2026-10-15 11:08:04.639296+00
2cf77d43-efc0-4773-9519-610d10df99b7	HDL-C	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ffb2009d-575c-4127-83e3-b093d6c730d6.jpeg	16	5	t	2026-10-15 10:46:06.291342+00
6d4f3554-2ee0-412a-af30-471500879cbf	TC	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6cec0cf9-407b-4a80-aaa2-f0cc6e81090b.jpeg	10	5	t	2026-10-15 10:46:53.682468+00
171c693e-768a-4e98-9fa7-b78f91a85944	Triglyceride	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1c3bf861-48f5-49b6-adc3-e073bc8d225a.png	5	5	t	2026-10-15 10:48:04.076138+00
cb424877-c00e-41ba-a9ab-94854c930087	Albumin	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/87cb2f1c-ef9d-49a1-944b-4fdd6f88e1b8.jpeg	2	5	t	2026-10-15 10:50:01.478552+00
a9061735-ec3b-4533-8124-e44acec27679	MALB	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/eb37311f-6102-498f-acb9-cdf7785def05.jpeg	3	5	t	2026-10-15 10:52:15.857138+00
c8247369-36e0-4af0-99cc-13be486f3c9d	Creatinine	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/345c7fc7-e835-4aa0-99f9-ea41b02baba3.jpeg	2	5	t	2026-10-15 10:45:29.514277+00
280a9428-5bc6-41a2-beee-924f8d94d88f	Urea	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f690d882-8cf3-4823-a04d-453d52eb50b1.jpeg	2	5	t	2026-10-15 10:40:47.423101+00
bab661ed-e425-4095-a183-0c8b35a9a73e	Control Level 2	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd342f6a-ec69-4180-aa68-c3c5fdf52b1d.jpeg	20	5	t	2026-10-15 11:05:56.83578+00
ee6fe6e3-87aa-4930-8a88-97f801e23fe0	Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6292a22e-2704-4beb-a6ad-96cb31ee59e7.jpeg	22	5	t	2026-10-15 11:09:41.606059+00
fab99f9a-b0b2-4e61-989f-5a2da8585cb8	Enzyme Detergent	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/dde4356d-76c4-41c5-bcd2-ee009bb86270.jpeg	1	5	t	2026-10-15 11:14:03.335102+00
3e76ff9b-1c77-4346-891b-0123b161eac8	Hematology Control	reagent	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/811ce2b4-0ae0-4fc9-a81c-5bb06c3b1ca9.jpeg	1	5	t	2026-10-15 11:16:32.379791+00
653d76e0-0733-41e3-8620-8901b926557f	Electrode Suit	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b22b54d8-44b7-4c8b-968a-748176854f00.jpeg	1	5	t	2026-10-15 11:18:02.472926+00
421af267-9183-4ddb-a550-00597fb5a6f0	Uric Acid	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/82fc7522-59c3-48d3-b547-53493a046991.jpeg	2	5	t	2026-10-15 11:19:09.233448+00
64b67e4d-cc43-47ca-87aa-5ba976f98625	Elical 2	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b288b5c7-c099-4298-9d7f-03f0175384bb.jpeg	4	5	t	2026-10-15 11:21:59.38244+00
5f57a013-29c1-4526-b33a-dee64e43db66	Elitrol 1	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6d1ea94c-542f-49c6-b117-7cd7800dc850.jpeg	7	5	t	2026-10-15 11:23:13.456895+00
bc6e03e2-4719-41ca-ae33-56363faf99a3	Elitrol 2	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/873f44d3-d4d6-4891-9457-4144b1c744e3.jpeg	3	5	t	2026-10-15 11:24:21.386418+00
d95e9245-a421-4351-89a2-6c363c15c948	LH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4f1c2bf3-5089-4fa9-813c-83f4dcf73721.jpeg	5	5	t	2026-10-15 11:52:23.198079+00
6c0ed636-bee3-4945-ba22-9947e85b0e8a	Cystatin C Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/345c5f22-58e5-4036-bcd9-d779eb5c3d44.jpeg	1	5	t	2026-10-15 11:30:27.503076+00
c4ada7ad-90dc-4f0b-80c8-255fb280929f	Autocal	reagent	Human	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f75b1c6d-1c1b-4db4-878b-fe4df48798aa.jpeg	1	5	t	2026-10-15 11:35:09.29032+00
5dd86b23-1a0f-4610-b26f-1844b931e8cb	Cholesterol Standard	reagent	SDi	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bc770405-d8e7-4066-bbd9-af49d1f9f074.jpeg	1	5	t	2026-10-15 11:37:32.433661+00
b9b11539-9378-401d-b02f-1a6c57468a00	FT3	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/69b801fa-a2a9-40a6-b5ea-9b91a10f3f6e.jpeg	5	5	t	2026-10-15 11:52:46.678044+00
c4be0085-5b40-4025-8c3b-daaa440d0605	Creatinine 	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b8052c19-11f1-4ee4-80c2-1364750e2e56.png	1	5	t	2026-10-15 11:38:28.437416+00
2b78a00f-31f9-49df-bbc8-6a974284d9b3	Albumin	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/329faa94-6d75-4fe8-8a68-cccf49ecb313.jpeg	1	5	t	2026-10-15 11:41:15.165061+00
1bbd62da-cf4f-473a-a6e4-1b76dae811b5	CKMB Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e622683b-d744-49e6-8bdc-c63a8d7854ed.jpeg	1	5	t	2026-10-15 11:26:49.872566+00
c7d35921-00d7-4dd9-99f3-9d97185c8190	ALP	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/77354658-3bb9-49c4-bb9a-206f45e1ac78.jpeg	1	5	t	2026-10-15 11:43:38.73796+00
5dae3134-fa21-4b2f-8ddf-a1570bd60b39	Urea/Bun	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7dd08043-d5f4-4242-8d68-b9f748323ac7.jpeg	1	5	t	2026-10-15 11:44:09.315065+00
04e87bfa-87b9-4bb3-ba33-679389a8fac5	GGT	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b6aeeb30-10b9-4d4e-af07-1c4fdd0749e3.jpeg	1	5	t	2026-10-15 11:44:59.161149+00
2a93e8fb-51d0-4098-8240-98a251b14f1d	ALT	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f8b2d255-dcea-4e9d-8da7-4bec720ce300.jpeg	1	5	t	2026-10-15 11:45:30.890209+00
cab8db31-f31f-433f-8bf2-8f551509c2f7	Testosterone	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/471288f5-74d7-4a75-81a0-d930757b9225.jpeg	2	5	t	2026-10-15 11:51:30.001827+00
7fecdac8-2555-4a55-972b-e44c988f2e3b	E2	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ad44d0e6-462d-4247-baf5-cb683e45f1df.jpeg	5	5	t	2026-10-15 11:53:17.443733+00
308fcffa-e9b6-4762-a000-74f95c9ca638	HCG	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/39e87f1e-1860-4e1d-97d6-847bb254b511.jpeg	3	5	t	2026-10-15 11:53:57.803628+00
5f6badbf-8cf8-4416-9bf4-873503e719c5	Progesterone 	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/16240a74-c945-4579-83b2-a4d541419ad1.jpeg	4	5	t	2026-10-15 11:53:40.083308+00
d5ef0c98-1636-44ab-beb9-00c32af409e6	Prolactin	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/15357b8c-033e-4751-84a0-f65670e68bee.jpeg	3	5	t	2026-10-15 11:55:32.86325+00
4cd01e41-701c-48c4-991e-459cc8e31a3b	FSH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4fab4780-c3cc-49c0-b847-fd543436edfd.jpeg	4	5	t	2026-10-15 11:54:55.980319+00
b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	FT4	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b3d6505d-490d-4dd7-9bbc-3fb90ff6e304.jpeg	9	5	t	2026-10-15 11:55:51.883816+00
659be18d-7cb2-47fa-a814-6d48cc07b97b	Gram Positive	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ee02392c-b3aa-4dbc-9e77-eb4607e195e8.jpeg	1	5	t	2026-10-15 12:00:46.063897+00
65f2bdb9-292e-4f42-87af-ba69db497a1d	Gram Negative	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd4fd3fc-acdc-423f-90ec-ce2546c984ab.jpeg	1	5	t	2026-10-15 12:02:36.016637+00
461e45a1-6171-4515-9ada-d619ef45641b	UTI	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7a768418-4676-40bf-8f55-6ae97e03a5a4.jpeg	1	5	t	2026-10-15 12:04:29.199874+00
f2b1be08-5c83-4eda-8b9f-6ea582926dc1	ALP	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/01fa7b0b-976c-4ce0-ba07-4c34717c1247.jpeg	1	5	t	2026-10-15 12:26:16.162886+00
dd3669d4-2f57-453d-a7b6-aa21012d7813	CK(Nac Activated)	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5c0d59f7-85dd-48a6-b8a2-4f7f943e310b.jpeg	12	5	t	2026-10-15 12:16:49.385651+00
c4e57f6d-25dc-4abf-8212-37351a30f621	Ozopath	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/165f38e1-a210-4b0e-b479-b571e5e77613.jpeg	6	5	t	2026-10-15 12:13:15.226947+00
2a0b04c3-f851-4a67-9850-2fbf78c5e078	Grouping A	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b99c17cb-260e-4f7f-aef6-08578a73f092.jpeg	44	5	t	2026-10-15 12:08:22.962533+00
051566a2-cdd1-4edc-b86b-afc306c0f1ef	Ozocal	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/aabad715-3aa1-4354-a8b3-6874fb12c5e9.jpeg	2	5	t	2026-10-15 12:23:48.318938+00
2ff86e38-152d-49ab-801f-dbc3b8f682ac	Ozonorm	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fa6ef02f-5fd9-4331-ad30-cb5a22571da7.jpeg	21	5	t	2026-10-15 12:11:39.678558+00
34de459c-89d8-4821-9511-5b271b020f1f	AST	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/34c388fa-c5fd-4cda-9d3e-eb3034f2338f.jpeg	1	5	t	2026-10-15 12:26:58.944082+00
8e99c78f-3a46-4b61-84cb-e621621ccb57	Albumin	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c2d1daa0-0133-4dc7-98b8-20662b4f6534.jpeg	1	5	t	2026-10-15 12:28:04.131114+00
3c9fc04b-2f30-484a-9889-9236bd4342a0	Urea	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a349e43d-9c73-4d8f-a9ca-8fc5c65266f4.jpeg	1	5	t	2026-10-15 12:28:35.743476+00
bf552471-6e68-44ee-87c9-d9fd808c3f05	BilT/BilD	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b1dfb0c7-99f9-466a-b522-f48e41bb0cf8.jpeg	1	5	t	2026-10-15 11:43:07.458915+00
056fe8d8-9df5-4505-9a85-faaaf1cd5377	HDL-C	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4fb75d45-d405-4e8e-84a8-e5e5a3b12ba2.jpeg	2	5	t	2026-10-15 12:29:03.562521+00
322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	Total Protein(TP)	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9329c5a3-a57a-424a-b4df-2ced9d595221.jpeg	1	5	t	2026-10-15 12:29:23.422761+00
75adac4f-8200-439b-8426-0d1986416946	TC	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2e7b9220-6fa7-45d2-9b16-73cbc212935c.jpeg	1	5	t	2026-10-15 12:29:55.829469+00
757ad4e5-8fd5-41a8-8141-bc0909726064	Triglyceride	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0997b9b5-230a-41e9-8053-944b7040a41b.jpeg	1	5	t	2026-10-15 12:30:36.04525+00
cdfc7193-716c-401e-987e-ce20381b3e44	GGT	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f319eb09-e721-4c59-ab9c-b1c2d4740dd0.jpeg	1	5	t	2026-10-15 12:30:56.094711+00
d64307a7-c776-44e1-9823-0a94a43d9fcd	Creatinine	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2abcb458-e334-4f8e-a602-e08dc45baea3.jpeg	2	5	t	2026-10-15 12:31:15.978286+00
a1d9955d-4411-4f64-9dd7-b460068d52bc	DBil	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/52869e47-4ad6-43ad-b165-9ab935a11c62.jpeg	1	5	t	2026-10-15 12:32:10.977593+00
cfbd97f4-63db-4d59-a335-c37e37750f8a	BC3000 Plus Screen	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9c293620-7846-4da3-a3f6-277426a97cea.webp	2	5	t	2026-10-15 13:19:09.946796+00
cba33b9f-880c-42fa-b4ff-bf55a415bfb7	Creatinine	reagent	ULTRACARE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8a8e5059-117c-4423-823c-a0019ae164fe.jpeg	2	5	t	2026-10-15 12:36:17.032999+00
d4790878-c6c0-4c47-8c42-d8fdee4727d0	Grouping Sera Set	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2408cb39-904d-462d-9291-0a499011639a.jpeg	2	5	t	2026-10-15 12:38:22.582866+00
ad8ca44c-84e8-47a9-869a-0cb70f002019	WBC Light 	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd31c53d-2187-4c2d-9eba-79ea0303357c.jpeg	7	5	t	2026-10-15 12:52:17.270969+00
e43b07dc-3e00-442b-8ab0-1b78e55d200e	3-Way Valve	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/493a6ee0-3281-4609-b7e7-18b460629946.jpeg	6	5	t	2026-10-15 12:40:40.013172+00
26d5d1c1-9d87-4970-97e6-57791b50c3df	2-Way Valve	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f40acb22-0800-4d58-bce1-93c93fa7b22f.jpeg	7	5	t	2026-10-15 12:42:32.330621+00
f6f3649f-2f07-4c67-9943-5ab1429892e6	Isolation Chamber	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/11dc3879-5fa1-44bf-bb70-648fdfa1ce50.jpeg	9	5	t	2026-10-15 12:43:56.289868+00
576cd245-ef27-4989-8960-f52085ab307d	LMS Board	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b3205f97-ed6b-47dc-84e1-46bcc43980b5.jpeg	2	5	t	2026-10-15 12:46:22.049323+00
1c945adf-e636-446a-a0a9-1f3a712271c9	WBC Chamber	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e15ab3d2-cc99-4ebe-ac56-280b0395263c.jpeg	2	5	t	2026-10-15 12:48:13.87597+00
60c5327c-1e65-45be-8e6c-d466d560f1f4	Horizontal Belt	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5ec5fb90-3365-4e90-a3ed-1c8d4fa2966b.webp	2	5	t	2026-10-15 12:50:13.590666+00
14192d9b-42e4-43bf-b319-4cd7584aa3d8	Rotation Motor(Down)	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d9880cdb-f84f-4d8c-94ab-99e3a65dc076.jpeg	1	5	t	2026-10-15 12:54:00.739905+00
def0af54-5508-4904-8e51-c0dbf72a1618	BS230 Probe(Short)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/748a70f5-5121-4ccc-85e1-a079c9bb57b6.png	17	5	t	2026-10-15 12:56:47.007313+00
1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	Chemistry Lamp(Fully Auto)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b88bbb13-1bd5-454b-9c84-5f6749f3d4ee.png	16	5	t	2026-10-15 12:58:48.633398+00
491bd73e-fc85-400e-beb7-c0f433899ed8	Chemistry Lamp(Semi Auto)	equipment	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9e21c5ff-ba7b-4949-8235-844f04ec8db1.jpeg	1	5	t	2026-10-15 13:01:16.308434+00
acf4c443-9c3c-4c75-8886-738a9765d34a	BS 230/240 Power Pack	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fc2f4254-a330-4567-b446-3654e95216e7.webp	1	5	t	2026-10-15 13:03:01.065156+00
98816970-f9e2-4868-a95b-873475f0db3e	Screen	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/89bf9900-9b7f-4684-b1ec-384716e4e11e.jpeg	3	5	t	2026-10-15 13:04:33.597861+00
61dec910-f577-481c-93ef-f832bcec3d9f	Glass Syringe	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8ed14000-34bd-4a79-9cbb-0b92f20e1d04.jpeg	3	5	t	2026-10-15 13:06:52.164946+00
7fed6899-c746-49a4-a2da-cf871ceb495f	BC10 SD Card	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b2e86634-e1d4-45d8-ac87-3706ed7fab60.jpeg	4	5	t	2026-10-15 13:08:35.460079+00
5b736c5f-3c02-4672-8497-7dfc17b49a80	BC20 SD Card	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b4916a0c-f0a4-422d-8a8c-3eb6e7a32aad.webp	2	5	t	2026-10-15 13:09:18.70207+00
313c3a6a-b5bd-4b67-b3bb-9552f7207c59	Dry Block	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6e59c693-cc5b-4f83-9eef-75f2173ee28e.jpeg	1	5	t	2026-10-15 13:11:04.011164+00
05e53106-69b8-4682-a6be-b6de4bd64000	BS200 Cuvette	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0484674f-9272-4680-bb9c-46d0b07d14e0.jpeg	10	5	t	2026-10-15 13:13:11.96915+00
99777cff-18a4-4e87-bc75-988d35589c33	BS240 Cuvette	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/dfa30f3e-d5b1-4578-a73c-9fe563bbe894.jpeg	16	5	t	2026-10-15 13:14:56.820657+00
d4185435-b8a9-48bf-b7b1-7446245b35ab	Probe Wipe	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/492547c1-cf57-4cb7-80aa-52fd6c993c3b.webp	1	5	t	2026-10-15 13:16:02.147787+00
50ab9fee-98df-4ae0-ac78-4cbbc592272d	BS240 Probe(Long)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d1ae9474-e65d-4d8a-8211-e08bd96ca2a6.jpeg	9	5	t	2026-10-15 12:55:28.477615+00
59c06c74-f342-4be2-bc93-547b7f242c03	Macconkey Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/63b57424-6978-435a-90b8-32f7ca429438.jpeg	1	5	t	2026-10-15 13:20:57.898734+00
5ebb6d12-aa2b-4275-b322-949e5e7cc086	Sodium Meta Bisulphite	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fb29e44d-d6a2-49fc-895f-da320ce683ee.jpeg	1	5	t	2026-10-15 13:21:56.972558+00
190becce-9184-429f-b602-55c7beecea24	TBil	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/395e2639-764c-421d-ae70-5d21188abf80.jpeg	1	5	t	2026-10-15 12:31:40.4401+00
41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	Simon Citrate Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b199c36d-f13a-4075-b76f-4e226018266a.jpeg	1	5	t	2026-10-15 13:23:28.868665+00
950d3492-cf9e-4b6d-b6bf-eaa830f709a9	HIV	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8d0d3e6f-72b7-42c3-ad92-a20d4799ec23.jpeg	42	10	t	2026-10-16 08:48:40.823035+00
4fd457b6-2f0f-4771-b8fd-d54283355d9a	CLED Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fd80776a-b087-4d65-87a0-b42163794cfd.jpeg	1	5	t	2026-10-15 13:23:58.187924+00
ec733761-dbcb-4ae3-839b-8f759f29057f	Combi10	consumable	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7b2c9fb5-34fa-4000-9cd4-f3b87707e619.jpeg	6	5	t	2026-10-15 13:27:29.754352+00
0ded23de-1d23-4279-b783-1e5c5a59ca5d	ST200	reagent	Sensacore	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cab3000f-9772-40bb-8a16-ce3af608a899.webp	6	5	t	2026-10-16 09:12:15.679565+00
cf5815de-94e6-426d-8eca-594e2ef0f803	ALP	reagent	Mindray	Alkaline Phosphatase (ALP) Reagents are liquid, ready-to-use in-vitro diagnostic kits designed for clinical chemistry analysis of liver and bone function on Mindray BS-series automatic and semi-automatic analyzers	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e742cc1b-aab1-4d29-8901-3cc6daff0668.png	7	5	t	2026-10-15 10:18:36.162278+00
1cfbbd77-1dd6-41ac-b603-35af72ec737d	AMH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a8bcf332-eb0f-47b5-9a09-c51855c2141d.jpeg	1	5	t	2026-10-15 13:40:16.721556+00
fa3c9366-9b08-440c-8725-c5180ae578ee	Diluent Labnovation	reagent	Labnovation	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/adfbdb3b-9e28-4e6d-acdf-128df19a603e.webp	60	20	t	2026-10-16 08:25:55.12292+00
a7206327-20b6-44b6-b489-d2f563ee49b2	Diluent Sysmex	reagent	Sysmex	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a93a55a6-7b5d-47f3-b5ac-d3cbac308e47.jpeg	3	3	t	2026-10-16 08:27:37.330217+00
feed7224-1883-4dbb-87e9-244150e61d54	Diluent RD7	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/de27ad58-790e-4ab3-b7ef-bcc90c254716.jpeg	1	3	t	2026-10-16 08:32:56.896099+00
0f537939-ec3d-4520-8ec6-450b21480858	Syphilis	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6aacc74d-9eb3-4990-be07-2dda8f130d0d.jpeg	15	10	t	2026-10-16 08:47:32.029569+00
731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	Diluent LD3	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ffd133e9-40d7-4a10-8463-18bcd22fe05f.webp	2	5	t	2026-10-16 08:39:52.303641+00
318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	Diluent Rayto	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5d08e738-b7f2-4f75-85b6-4783a45c7b38.webp	26	5	t	2026-10-16 08:36:46.655981+00
ed335ad7-006a-4922-ad15-53f8faa37e4a	Rinse Labnovation	reagent	Labnovation	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d392786d-93f6-48c5-ab64-ba7357d2caab.jpeg	1	10	t	2026-10-16 08:42:14.12979+00
d359c066-20dd-4f17-baed-699c38753958	Rinse Cleaning Solution	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1dad73c3-066c-44b0-9d16-e4577b148f2c.jpeg	1	1	t	2026-10-16 08:45:26.847628+00
613b356c-997c-425c-98f3-876bb2203c6a	EDTA Tubes	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e541cc26-1b2f-445b-a840-017594025936.jpeg	7	5	t	2026-10-16 09:09:58.903264+00
d3992ca7-83aa-453b-a8d0-21d9644f6782	Timer	equipment	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4460ebbe-7f9d-43db-bd43-2230a37ef5f6.jpeg	122	10	t	2026-10-16 08:50:50.996832+00
daea334f-45d9-498f-91c5-c57769160d0b	M30 Lyse	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ab2654d1-ae23-406d-ba4a-92619de13d22.webp	1	2	t	2026-10-16 08:52:43.962901+00
9b21331b-4332-4cbc-97d3-33ed2ecc6acc	LD Lyse	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c550254a-ca93-43eb-835c-2db29b483c7a.webp	5	5	t	2026-10-16 08:55:51.388516+00
b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	Diluent Coded	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a4aa65ac-3f1b-4378-a2a3-c1a0e5774fa5.jpeg	0	10	t	2026-10-16 09:01:30.30164+00
ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	Hepatitis C	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fd7fac19-fb54-418c-b320-80fabec6a4d2.jpeg	3	10	t	2026-10-16 09:03:08.27778+00
6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	Hepatitis B	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d02b40b7-d3a8-4f59-b0d0-91855d1b06fc.jpeg	3	10	t	2026-10-16 09:03:59.343538+00
c02fa806-d252-4315-b4ae-b1ea0846c420	Typhoid	consumable	AlphaPharma	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/86002c5c-7e06-4388-b7f6-1b3562b487dc.jpeg	16	5	t	2026-10-16 09:08:25.374923+00
371b2c03-2b4b-4a87-87f4-bd2694338ef5	Finecare Analyser	equipment	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/834753e8-fad3-4fc3-bee6-8a61c16ff2ad.jpeg	2	5	t	2026-10-15 13:28:49.684437+00
b5fe9c12-b945-4aec-9049-39a8b9159733	Plain Tubes	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6ed29b75-e1ba-4255-aa49-08e51d9abb58.jpeg	1	3	t	2026-10-16 09:13:17.782818+00
3572f4d3-23dc-405a-a94e-3fa793df5fee	Glass Slides	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ac277b36-a9a3-4452-97ee-356173973dda.webp	1	5	t	2026-10-16 09:14:51.418808+00
bb775507-b788-41fb-ba00-660b1911bba2	Gloves	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/37a58f7c-8369-402f-a8d7-bf4be48e66d7.jpeg	2	5	t	2026-10-16 09:15:32.241793+00
b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	Plaster	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c6807a0f-453f-4557-ac6d-39457eb07fb7.jpeg	68	10	t	2026-10-16 09:16:58.262674+00
ef7a13be-5ef7-4044-a641-60561d491a66	Digital Clock	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7b8a1732-4bdb-4233-8ca0-7a1119443d3c.webp	1	3	t	2026-10-16 09:19:36.24207+00
28103a7e-6f63-430a-bac2-a8c6eef4b4e5	Distilled Water Plant	equipment	BIOBASE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9e57ee15-40a6-469f-bde4-b24c16715042.webp	4	2	t	2026-10-16 09:22:28.994901+00
9b2a4a10-c691-4cdf-957e-78ec49a74c7d	Blood Collection Needle	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9ba1a7ea-2773-4489-a340-83c53febb763.jpeg	3	5	t	2026-10-16 09:26:12.00105+00
56cdbdf2-3b93-46e7-9f90-83373145f827	Cotton	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e2baff53-5ed1-4b3f-9896-45cd9aa60f98.webp	18	5	t	2026-10-16 09:29:57.986665+00
9db7aae9-12d8-4716-aff7-0532026f939a	G26	consumable	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/55ff0958-801d-4cd6-a9eb-bf6b2fa37004.jpeg	10	5	t	2026-10-15 13:25:46.459532+00
1d462684-8f12-4d3c-8828-8b4f20f01e28	Gauze Roll	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/edfb5b2a-4f42-4c72-be5a-f39a0e6cc9c4.jpeg	6	2	t	2026-10-16 09:31:09.622411+00
507af4d6-75cf-43f6-a30a-3c118c7cd48a	PSA	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/08e05e01-4e0a-41f8-a453-193416dc5cee.jpeg	64	20	t	2026-10-16 10:01:18.971392+00
63e1b692-a6ed-4edf-8373-9349000b5f5e	Blood Lancets	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/be51b8d6-7cb5-429a-98af-73ae73565d8c.jpeg	2	2	t	2026-10-16 09:34:48.329147+00
f697ee81-89c0-4297-a5de-62ac36f325b5	Immersion Oil	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1280c3a6-5c3c-4718-8b04-f1a474e2808e.jpeg	1	2	t	2026-10-16 09:36:02.620856+00
f5cf61f8-72f0-4426-b0b3-2095ee7155b2	Urine Container	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/76e285ff-81bb-4102-99ba-1b67a43c04d5.jpeg	52	20	t	2026-10-16 09:36:58.270311+00
42433484-7a92-4459-9509-536e55910c3f	Glucose Lifecheck	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd96c3b0-ffc5-4554-bd67-4e23c8e0b3d2.jpeg	3	2	t	2026-10-16 09:38:20.33844+00
9d3efcc1-82a7-4697-9aca-9c11c4a31037	Sample Cup	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e9f22a17-8939-49b9-9b98-d8d649b25db3.jpeg	2500	1000	t	2026-10-16 09:39:50.54201+00
b50611fb-eeca-4b74-a02a-91e2ea2d9846	Testo	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2832fed3-2973-48d8-a784-36436e253324.png	5	5	t	2026-10-16 09:43:20.35562+00
62f9f784-9902-45e7-869e-0ce5e8cfdbd2	FT3	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/01174130-8fee-4aa4-b33a-979d4f79bcfa.png	20	10	t	2026-10-16 09:41:42.498779+00
154fbfed-8711-471d-badf-6bad744ce246	E2	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/000aa272-0fcc-4016-bf5a-c4cb9a2d3e95.jpeg	10	5	t	2026-10-16 09:44:28.314387+00
2f1bb631-b9aa-435b-9217-341aa3fe9ada	CKMB	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a02fbb2a-3440-4241-9b21-7e006e6cb78e.jpeg	5	5	t	2026-10-16 09:45:22.926005+00
48c8796e-48a2-4355-b4e7-16bce21b2710	Thermal Roll(L)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bf7ddf2f-ecb7-41ca-8466-632d794e7762.jpeg	23	15	t	2026-10-16 10:10:01.670009+00
d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	T3	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/75b55605-e91a-4f2b-acea-1a78c752e68d.jpeg	2	5	t	2026-10-16 09:48:14.748224+00
caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	Beta HCG	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bbf9de8a-24ac-446c-b5ed-c8e49cb3e1aa.jpeg	16	5	t	2026-10-16 09:51:14.035901+00
6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	Alcohol	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d17345df-164f-485d-945a-fa7110bd149e.jpeg	32	5	t	2026-10-16 10:06:34.670938+00
9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	Progesterone	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd484306-e6ad-4611-bbc0-1fa82648914a.jpeg	5	5	t	2026-10-16 09:54:34.910399+00
f837a23f-6bcd-4d96-9291-bba4d69caf3c	Diluent	reagent	SGBiotech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c51aa2e9-4ffd-4313-874b-2c795379939e.jpeg	1	5	t	2026-10-16 10:12:37.05425+00
fda6810f-87ff-4863-9c2b-e0213ac55cc8	Prolactin	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1b552d75-f0b1-4690-8501-77cabf663120.jpeg	9	5	t	2026-10-16 09:57:20.971802+00
b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	AMH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c4fe179b-b035-475e-ac28-e39d22004551.jpeg	5	5	t	2026-10-16 09:57:59.719297+00
38150feb-b79b-45e8-b451-9a1aeb96af06	FPSA	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1d1b888e-4f43-427b-8eea-baf9a58cea8d.jpeg	1	5	t	2026-10-16 09:59:47.395531+00
f5336cfc-123e-412b-9128-4aab6543591c	LH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a02bcbc6-7ea4-418d-81be-da47e478f6c2.jpeg	5	5	t	2026-10-16 10:00:46.965689+00
e1d8a6b9-b965-479f-a777-f85b0df18c59	CRP	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d267cc87-e77f-4cf5-a674-a80aa76fd008.jpeg	23	5	t	2026-10-16 09:49:34.303106+00
fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	FSH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/35a4f591-54df-49e2-ba98-152b496dcf72.jpeg	13	5	t	2026-10-16 10:02:03.55059+00
1df32cc2-2332-4453-9847-ad60db9ed220	D Dimer	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5160affc-ffbc-490c-b729-380a9a758233.png	13	5	t	2026-10-16 09:47:19.99488+00
dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	HBA1c	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/51f40454-d4bf-4fa9-8bbc-47698e8c9540.jpeg	9	10	t	2026-10-16 09:46:31.419933+00
12524346-ae4c-414d-a09c-d1fd4640cb50	TSH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6a87e591-b3db-4322-bb05-b4ded6815a0a.jpeg	6	5	t	2026-10-16 09:55:56.319837+00
f1aabb46-04f7-4c4f-83c0-d532953304a1	Thermal Roll(S)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/13e40071-2f9c-4f33-8b7f-4ce8a303bfa2.jpeg	36	20	t	2026-10-16 10:09:21.671484+00
4a0b448d-3fb8-4474-a9d9-267f5319518f	Pulse Oximeter	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9139ce19-67bf-4dd8-a07a-fadd10e4c8b8.jpeg	4	1	t	2026-10-16 09:32:44.595849+00
923b5487-1db2-46d0-a0a3-3af4a83830e6	BC10	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/45325985-46bf-447c-b5f4-dc56bcc011fc.jpeg	1	1	t	2026-10-16 10:17:57.03059+00
ba28ef00-70b2-4902-94ff-cd4545a1e506	BS240	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/46221dae-d44c-4889-9021-35a00d1d92a7.jpeg	1	2	t	2026-10-16 10:19:16.954194+00
79f46b6a-9be6-4131-a71b-79f864b7efe6	BC3000 Plus	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4ecf548c-0fe7-43af-a903-25f70b475ec2.jpeg	1	1	t	2026-10-16 10:20:19.642464+00
55170fd5-00ce-4241-9620-ee6dced18987	Microscope	equipment	Olympus	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/571d8795-4398-47d7-a26c-f1dfba2f7662.jpeg	2	1	t	2026-10-16 10:21:26.648637+00
0a2d780b-6404-4826-a300-d6c89964ae40	Centrifuge(6 Buckets)	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e2a3f529-7f31-490e-91c8-000f11ecab9a.jpeg	3	1	t	2026-10-16 10:22:32.887025+00
6faff9cb-851d-4fcc-8478-a18c83228de5	SensaStat Control	reagent	Sensacore	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/13a517d7-53d3-4789-9458-7120c1240df6.jpeg	3	5	t	2026-10-16 10:15:46.80767+00
1ccc204f-d62c-4f56-9a6b-39281f24d1e6	CD80 Detergent	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b07e3cd1-762a-4759-87d8-c059197be874.jpeg	15	5	t	2026-10-16 10:29:18.587449+00
2d096f70-6b8d-4a45-a9b9-0388c96a945d	Vaginal Speculum	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/eb788796-ce5f-4f4e-a62f-72ea063fd46c.jpeg	1	1	t	2026-10-16 10:32:26.400738+00
9cbfc261-d617-42b5-be18-97be0da5540b	Biosphere Filter Tip	consumable	Biosphere	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/05803019-914f-4793-aa73-e255911cafe5.jpeg	85	20	t	2026-10-16 10:36:37.7346+00
5a072e55-b0c1-4102-9b9f-6e786d9a2343	EZ Cleaning Solution	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/40b6462e-bd65-4d9e-a2c0-4d6d378a9044.jpeg	18	5	t	2026-10-16 10:46:42.942043+00
94d568da-7421-440c-839d-30290b500f97	Giemsa Stain	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8d068387-d7e4-4726-9279-02cd808d19d1.jpeg	3	5	t	2026-10-16 10:49:16.699959+00
2506f42e-d3d7-41f8-ab97-0473118c3630	Gonorrhoea	consumable	Micropoint	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd02e44a-550b-4b5a-a6d7-67c48dbaa50c.webp	5	5	t	2026-10-16 10:51:15.165475+00
49147609-1a68-4612-a2a5-3845b60a2d38	Swab Stick	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/47dfe762-a91a-4303-a039-920b19a98fdb.webp	50	10	t	2026-10-16 10:52:17.761104+00
2589ccdd-7774-4eb6-952f-aff007ddc585	Blue Pipette Tip	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/510c81df-a2f7-498d-814a-63a3932f6d52.jpeg	500	100	t	2026-10-16 10:54:20.298889+00
5325af28-0ff3-479d-ba25-2507b2dcb708	Yellow Pipette Tips	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4de827a3-9655-4d98-a76e-8bea70c7a5c7.jpeg	1000	100	t	2026-10-16 10:55:18.840108+00
328cc8a1-848e-4c8b-ad40-4a6fe279bcc2	Syringe(10 CC)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/034cfa1c-9ced-4290-b507-504803b45ca2.jpeg	0	5	t	2026-10-16 11:07:28.937316+00
571fa9c2-9b3f-4171-aebe-a02e9a9e79db	Sysmex Lyse(Stromatolyser)	reagent	Sysmex	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/00927b2a-a139-4571-9e31-6a011521583d.png	3	5	t	2026-10-16 11:21:30.025681+00
90cdf544-bf74-4d7c-9cef-c2e3148c29b2	Diff Lyse	reagent	XKivd	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b236ab29-0f9a-4fd3-ae93-5524b454a095.jpeg	5	5	t	2026-10-16 10:26:04.341785+00
9b2e77d6-dfee-4a2a-83b0-1224f12875ef	LH Lyse	reagent	XKivd	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2c4f5ca0-6974-4c3b-b1f5-388fc91640d0.webp	93	20	t	2026-10-16 11:10:03.48905+00
7640cb52-77e0-4374-a235-bdb6e0d41503	cTnI(Troponin)	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/898724f0-9188-4c3a-8666-e455fefe5a33.jpeg	2	5	t	2026-10-16 09:53:13.007561+00
0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	Cuvettes	consumable	\N	\N	\N	2	1	t	2026-10-16 13:47:45.587613+00
598eb297-3ff5-47e5-8cb9-5904f6bbf516	Daily Cleaner	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/22719fb3-a7e9-43e2-8c66-476a65c5969e.jpeg	22	15	t	2026-10-16 11:00:04.733017+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, qty, price, pending_qty, delivered_at, product_name) FROM stdin;
\.


--
-- Data for Name: order_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_returns (id, order_id, item_id, owed_removed, returned, restocked, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipts (id, receipt_number, customer_id, amount, method, note, balance_after, created_by, created_at, reversed_at, reversed_by, reversed_lines, credit_after) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, order_id, amount, method, note, paid_at, recorded_by, receipt_id) FROM stdin;
\.


--
-- Data for Name: pending_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_orders (id, customer_id, salesperson_id, notes, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: pending_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_order_items (id, pending_id, "position", product_id, name, qty, price, held_qty) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, created_at) FROM stdin;
ca75deab-00dc-490a-ba3c-06c8bf0c6ac3	a6271f16-534a-4325-aee1-5ed0ab3eb261	https://web.push.apple.com/QFMu5hVnH9vlm1yQMCWRTQ1rnB3xkpCYQcMqCp72VZhuyMi8EVXENP2nOIt4W3bz-qX-VYX4y2OHOCBpL934Wg9uMA-Uc5dvgQTbIXK9MGzuEeFqnRk-cR6CPdqp-_MIS1Wq71skGvCr1rbWxPN1alkXmum8aJGhk2UT8ADuH3g	BN939MYPpA6Xz5qAmCeYUSXUo7KPjtbub9KfyEWktdLDUcKS5yYdBTycLEuvCk52AqytIQ24M7r6JUjx_8X0lCc	pVpvzZ00jJm_m_QxXGLl9g	2026-10-13 07:06:59.034663+00
3d0d9c06-7407-470a-b9c8-9f2279ab4b8b	82735742-c8fd-4042-b60f-67a9fca0d0ab	https://web.push.apple.com/QGOmkhvwkNrn81coeFec78B_C8OY9x2_IJ_qNP5x81cSxrhUar5Ku-dU9FCuOmy1X-7nQvuY5h3pKgVPv5qpY3Kiy73SNppYfwut7nVJcXBxb3U-ePtw4clrbQM7qHD7FYnuNIvFpreYpOb68ji7zrV68Kl6YGq0WBr9pJ3PHZc	BIHwtjIzxXF-IazabDOvOjAYALa0IvNu6DtRiSWKT3HkmEdc9YLLO5P85Ix7RoS2Td00SR-V2mJ3oTsl7zwZjIM	9c06H8qraEx2XQ1D4OyYzA	2026-10-16 11:18:28.120438+00
5bd3e183-1e15-4e98-acca-f0eb8c96d4e8	34cb4aa6-890b-4397-bf22-95f48620affa	https://web.push.apple.com/QIbsVavBxNfvkhKIAdG0pw1pXpnn5fBDlAK891l0y7OKoR1XpptcRfxjnB6a0sbAw0iWapaHUmM_SJD5JSFXDXDJthSS47Y9yFIVkHvMyrgFGMLAWYjDkN_PhzUsJl7PYeJb1lki71LHllQVF5bsZsdZ0mPzp80dU7ZKU9s8AGg	BBHoQ3_4OCcVfYGeWETF_kmhV3KgE7RWmjZufpkvuCTVvKL9Xzy-cBTlBmtKvrI5IDGW07KgL02MtEWyIPwUEFA	l6GKIJqvHDraBMBgXTIDKg	2026-10-16 11:19:40.582574+00
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refunds (id, order_id, amount, method, note, created_by, created_at, refund_number) FROM stdin;
\.


--
-- Data for Name: stock_in; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_in (id, product_id, qty, supplier, received_at, created_by) FROM stdin;
79186191-7a0c-4466-9547-70f1fea1cf12	ead2b374-e435-4025-bead-d804071dda77	3	Opening stock	2026-10-12	a6271f16-534a-4325-aee1-5ed0ab3eb261
4c7c3454-e9c0-45c9-8317-c18d45cbdba4	d6d4fda9-6087-410a-8bc9-0a5622f40e32	8	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3ecfead-aba0-4128-9609-00c16c978de2	cf5815de-94e6-426d-8eca-594e2ef0f803	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
05af52c0-8ccd-46ff-9890-2952bf0ae825	9ff4f240-9f00-460f-87f1-e745c6647e36	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a50cd550-1894-485a-aeea-b3bd16e2edc7	91abfef3-d9b8-40d2-9109-a66e97f2607c	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
072e774b-1b90-41b9-861f-98cf5f1aa622	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
324b646c-05ea-42a7-b70d-19a43fe0d773	51291b09-5c9c-4ece-b5ab-caab1507e9e2	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3be614ba-751b-47ea-adf9-36d933870266	e32d59af-01ec-496c-9be5-ae5285d46a1a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
39806749-2dba-4395-9c80-89c0c3f3a7b1	427a9551-fb8c-45c7-9076-19c9ee015002	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4865b5f4-bb47-48fd-9249-bbf82bc118a5	9c309e3f-ca58-4ed7-b6f8-1ff19b498864	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
500c027a-40ff-400b-bd5e-d5539195b3e4	6452048e-904a-481d-9879-dfbc9b3b89ba	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
92b8d883-0172-4f69-af29-10c9f3e30c66	5a58c58c-8ed5-4082-a9e3-3d91b026c57d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
dc40bc9d-7e92-4956-8bc3-185dd104449b	280a9428-5bc6-41a2-beee-924f8d94d88f	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0fb4a605-0a89-48a1-bcb4-be2b30392192	81ef7ace-0699-42db-85ba-4c050a08a008	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
17d49884-19e2-4e49-9b01-8b5835fef790	c8247369-36e0-4af0-99cc-13be486f3c9d	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
971cc0ca-6a10-4f62-ad7a-a26d8dc8019c	2cf77d43-efc0-4773-9519-610d10df99b7	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9a4c5e3e-5fde-4113-b0f0-cff92f129de5	6d4f3554-2ee0-412a-af30-471500879cbf	10	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e2f03c72-0f04-4e76-ba87-606d83e34527	171c693e-768a-4e98-9fa7-b78f91a85944	5	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
d06341fd-3a82-46f0-a2a8-17dc78af33ff	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b0427d72-4f00-401c-934e-99a24062b261	cb424877-c00e-41ba-a9ab-94854c930087	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2f45e64e-3eae-42aa-afeb-6c5714144b1a	a9061735-ec3b-4533-8124-e44acec27679	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
84ce8bfb-4b7d-4844-b26b-bc9b5356a71f	bab661ed-e425-4095-a183-0c8b35a9a73e	20	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2848c616-4b83-4c2f-867e-dc68821be215	ea5ebf85-f433-452c-ba48-3f8c921b68c0	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6dbcbbad-96d4-4380-8e68-629206d01843	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	22	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
167a57df-ab76-4257-98ee-e15fa4c21828	fab99f9a-b0b2-4e61-989f-5a2da8585cb8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6e14224b-5623-42ef-840f-a590227e5a0b	3e76ff9b-1c77-4346-891b-0123b161eac8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
70bcecb0-b21a-429d-a70c-d792e727c22d	653d76e0-0733-41e3-8620-8901b926557f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
af002da2-2679-4845-a840-b115da050a49	421af267-9183-4ddb-a550-00597fb5a6f0	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9be88fd4-f2b9-423c-bb24-052cb6af894d	64b67e4d-cc43-47ca-87aa-5ba976f98625	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
343d0571-259c-41ea-be54-dc7b47c0c03b	5f57a013-29c1-4526-b33a-dee64e43db66	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
eaf2ac0c-6dae-4bfe-8085-497961868e03	bc6e03e2-4719-41ca-ae33-56363faf99a3	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
aba57409-a220-4043-8d0e-78bae4f1194d	1bbd62da-cf4f-473a-a6e4-1b76dae811b5	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
61e10487-7349-4847-b243-68851c083c87	6c0ed636-bee3-4945-ba22-9947e85b0e8a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
45f7e012-070a-4161-a2eb-334bcd0b297b	c4ada7ad-90dc-4f0b-80c8-255fb280929f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
569b6899-8efc-4f6a-8c7d-4aad438723fb	5dd86b23-1a0f-4610-b26f-1844b931e8cb	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0169681b-f745-42a2-be65-d9639a2e7213	c4be0085-5b40-4025-8c3b-daaa440d0605	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3c33fd2b-7611-4052-8676-03b246d1a415	2b78a00f-31f9-49df-bbc8-6a974284d9b3	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
c5100782-71a9-440d-89a9-c964c1b4ef65	bf552471-6e68-44ee-87c9-d9fd808c3f05	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e6b84ff6-95cd-483f-be65-ceb3a33eb3e0	c7d35921-00d7-4dd9-99f3-9d97185c8190	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
089cffef-e572-42c3-a34a-587b9bcf22b6	5dae3134-fa21-4b2f-8ddf-a1570bd60b39	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
5b796233-d068-4f43-b08a-e837a0dcffb1	04e87bfa-87b9-4bb3-ba33-679389a8fac5	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fde28b62-89ed-42af-afd2-39ae65af0cec	2a93e8fb-51d0-4098-8240-98a251b14f1d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4f8e0a1d-f6e7-421d-843a-9f14d9dd8473	cab8db31-f31f-433f-8bf2-8f551509c2f7	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
97658f0a-84a9-4a98-ab9f-22a13d00cdc2	d95e9245-a421-4351-89a2-6c363c15c948	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
cb813698-c635-4465-baaa-3d300ff265eb	b9b11539-9378-401d-b02f-1a6c57468a00	5	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9c37b039-c385-417b-8435-a159b3074422	7fecdac8-2555-4a55-972b-e44c988f2e3b	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
60663f72-fc34-4d9f-ab60-7ef356e5ac0d	5f6badbf-8cf8-4416-9bf4-873503e719c5	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
d39b143d-1026-4f6e-bb4f-3b1bcce0a7b8	308fcffa-e9b6-4762-a000-74f95c9ca638	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
1ea1c9ef-16ff-48f4-96f8-f80b89532f92	4cd01e41-701c-48c4-991e-459cc8e31a3b	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3da8523c-0e5c-41b2-8b71-6c11dbafc0f4	d5ef0c98-1636-44ab-beb9-00c32af409e6	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4f30fd94-a66c-480e-a799-a839b70d9ef9	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
08925466-7de9-46e6-a9f2-5dc600709a6d	659be18d-7cb2-47fa-a814-6d48cc07b97b	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9543b91e-cee0-4dbb-a94b-2ab7e9f6d7ce	65f2bdb9-292e-4f42-87af-ba69db497a1d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f7d1a290-78b7-45f1-a42b-eb48451a600c	461e45a1-6171-4515-9ada-d619ef45641b	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f27fb801-a6a1-4fb8-b540-bac1b2fc7d43	2a0b04c3-f851-4a67-9850-2fbf78c5e078	44	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e736fe9c-afa0-47ab-a383-3bf5f1988891	2ff86e38-152d-49ab-801f-dbc3b8f682ac	20	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
dd5b6e25-b627-4c80-aca9-257be59c8b6b	c4e57f6d-25dc-4abf-8212-37351a30f621	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
32b6b8c6-d53e-405f-86c3-7fd090f97213	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
876e9feb-d5ce-436a-b9b4-be0c34639e97	051566a2-cdd1-4edc-b86b-afc306c0f1ef	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
5937c5f0-a259-4194-b4d2-623bc0da752c	f2b1be08-5c83-4eda-8b9f-6ea582926dc1	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
7e2244e6-101d-4fac-ae2d-0a0e339de03c	34de459c-89d8-4821-9511-5b271b020f1f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
40deab5f-8bf6-4fcf-9be5-6ee7abb73f11	8e99c78f-3a46-4b61-84cb-e621621ccb57	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
99172a19-8570-4b86-b24d-800e0638e40c	3c9fc04b-2f30-484a-9889-9236bd4342a0	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6413a0cc-5757-432e-b466-267a9f8143d6	056fe8d8-9df5-4505-9a85-faaaf1cd5377	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3d5f2544-aeb3-4e97-ba8e-a2b9c405864b	322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6a2030e8-7545-43c6-851a-7f8cbdf0b75d	75adac4f-8200-439b-8426-0d1986416946	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3bf06c3-8196-421d-b084-59e850e918ef	757ad4e5-8fd5-41a8-8141-bc0909726064	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
308aaffa-b94e-4341-aa46-726fe2ad4da8	cdfc7193-716c-401e-987e-ce20381b3e44	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
91d6de20-bcbf-4c6f-927b-9283a47e2810	d64307a7-c776-44e1-9823-0a94a43d9fcd	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a5c3ed8c-49f2-4010-8b21-aed93dfb495c	190becce-9184-429f-b602-55c7beecea24	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
81b1eb6d-156e-4209-abfd-6ba142212101	a1d9955d-4411-4f64-9dd7-b460068d52bc	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
38c661e1-b05d-4185-86e5-d54672f8eab1	cba33b9f-880c-42fa-b4ff-bf55a415bfb7	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4a527ff6-bca7-4467-a4ac-67222e3fc066	d4790878-c6c0-4c47-8c42-d8fdee4727d0	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f1061a6c-7246-40a0-be24-ffd6bb9f50e8	e43b07dc-3e00-442b-8ab0-1b78e55d200e	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
081b926a-235d-48b0-aa27-767cf6c62e0a	26d5d1c1-9d87-4970-97e6-57791b50c3df	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
475e7100-bd24-49b5-a661-2e0afab5dcf8	f6f3649f-2f07-4c67-9943-5ab1429892e6	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4d4215db-2c63-4831-a0b3-059939b1361a	576cd245-ef27-4989-8960-f52085ab307d	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
ae0d333a-ee64-43e2-81e4-77b2b60c4ed2	1c945adf-e636-446a-a0a9-1f3a712271c9	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
68bd7870-e1d5-4455-ac78-0c55879d1200	60c5327c-1e65-45be-8e6c-d466d560f1f4	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
29df2627-fe6a-46d8-821a-b1aa15167e88	ad8ca44c-84e8-47a9-869a-0cb70f002019	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f906e05d-f2b4-4003-8532-4ed70569e6f5	14192d9b-42e4-43bf-b319-4cd7584aa3d8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
43b2c462-f3b6-4be8-b8e1-433a0adb00b1	def0af54-5508-4904-8e51-c0dbf72a1618	17	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
118637f4-c040-41e9-82aa-214a90cee714	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
57c8eca3-c0f2-4bae-9fce-32dcce8d7b81	491bd73e-fc85-400e-beb7-c0f433899ed8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a09aee42-ffec-42c9-a532-a75a7840b79f	acf4c443-9c3c-4c75-8886-738a9765d34a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
98614ced-241c-434c-9303-bfb04d6a7f53	98816970-f9e2-4868-a95b-873475f0db3e	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
045ef821-55e5-48b1-bf95-7e33df7bd3f3	61dec910-f577-481c-93ef-f832bcec3d9f	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
ae54c3e9-8b58-4003-a364-eb0ef70ebc38	7fed6899-c746-49a4-a2da-cf871ceb495f	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b46697b0-f894-44b7-adaa-046ce80d3b70	5b736c5f-3c02-4672-8497-7dfc17b49a80	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fcab40fc-819d-4d5f-9218-776eb4687737	313c3a6a-b5bd-4b67-b3bb-9552f7207c59	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
80575a80-bdf0-41af-b5d1-d9e2476ff597	05e53106-69b8-4682-a6be-b6de4bd64000	10	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f6c66ee1-e252-43e5-9714-c5148b2facf4	99777cff-18a4-4e87-bc75-988d35589c33	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fef1d322-e0b3-4da9-9ad0-159bac723386	d4185435-b8a9-48bf-b7b1-7446245b35ab	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2f5f0856-997a-47db-aef5-ef9ab42455fa	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a8260762-933a-4566-85e5-61eae3e79dfd	59c06c74-f342-4be2-bc93-547b7f242c03	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a13a43eb-3459-4840-80cd-da7753bac51d	5ebb6d12-aa2b-4275-b322-949e5e7cc086	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e7489add-c73b-4911-b75f-60a07796a9cb	41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0f6ef486-38fe-41e3-a3d1-5b82c9de50fe	9db7aae9-12d8-4716-aff7-0532026f939a	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
1fb4b3bc-5d6a-4de3-bbda-59d7b7513de0	ec733761-dbcb-4ae3-839b-8f759f29057f	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
adc7d873-10f8-4376-ac2f-a5d2ff49ab39	371b2c03-2b4b-4a87-87f4-bd2694338ef5	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a24bc1c8-f661-47c7-b988-8a6125607789	1cfbbd77-1dd6-41ac-b603-35af72ec737d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f0d20f88-efdb-4c85-977a-769ffd8cab24	fa3c9366-9b08-440c-8725-c5180ae578ee	60	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0ea97be4-762e-4dcc-bf5b-9164e964eb6e	a7206327-20b6-44b6-b489-d2f563ee49b2	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c4b8816c-365d-4263-9091-c4d49f01283b	feed7224-1883-4dbb-87e9-244150e61d54	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c5c62af2-ca25-460f-98b8-37adea874c3d	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	27	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
8a3988f4-2192-4c1a-a234-bf87f915c909	731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a71965b5-704c-4ad5-a207-7fcefe3e19e3	ed335ad7-006a-4922-ad15-53f8faa37e4a	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b70fb650-b812-4d81-b6f0-564447fbb114	d359c066-20dd-4f17-baed-699c38753958	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
10b52c4a-7f8c-4b2d-b40d-06e527de4ac9	0f537939-ec3d-4520-8ec6-450b21480858	15	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
932975aa-2de6-46c2-800c-700597d64693	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	42	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
83d22553-a49e-4360-8856-c5320ba88c7a	d3992ca7-83aa-453b-a8d0-21d9644f6782	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
939cd3bd-a3d0-4159-bbd8-b62ed688d822	daea334f-45d9-498f-91c5-c57769160d0b	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a03bc520-1560-4167-b9a4-d055d01235aa	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3a0c4c4-41dd-4be3-8c2c-c7211c240dd5	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
831d7775-35bc-4951-b897-ce534528758e	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
278ce567-0c61-4ccd-9f45-a9e1d6eca771	c02fa806-d252-4315-b4ae-b1ea0846c420	16	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
780a6a13-dc74-4990-b1e6-1da8c3399cd4	613b356c-997c-425c-98f3-876bb2203c6a	7	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
480c3547-9c1e-490e-90e3-8863648d8dcd	0ded23de-1d23-4279-b783-1e5c5a59ca5d	7	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
56fc55c3-543c-4293-85eb-12c0b5df9367	b5fe9c12-b945-4aec-9049-39a8b9159733	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
944a4edc-0958-49f1-a2b3-8deeeda7d5d6	3572f4d3-23dc-405a-a94e-3fa793df5fee	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
728addc7-f5a6-4355-8ef3-e997b34bf2de	bb775507-b788-41fb-ba00-660b1911bba2	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
655ab62f-6fea-4b04-be82-adc14b8f286e	b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	68	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5c7e1734-b2fb-4ab5-9dd1-2f5ee7228e24	ef7a13be-5ef7-4044-a641-60561d491a66	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9158fb42-2768-4d31-acea-ec6524543749	28103a7e-6f63-430a-bac2-a8c6eef4b4e5	4	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
28f6a5aa-bdfd-4ae2-94dc-10fd0fd2d605	9b2a4a10-c691-4cdf-957e-78ec49a74c7d	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
327ef374-9d23-4e6d-befb-dc584b8f3675	56cdbdf2-3b93-46e7-9f90-83373145f827	18	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
bfd49a35-b040-4f54-a5d8-ab1691a971c1	1d462684-8f12-4d3c-8828-8b4f20f01e28	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
683e30d0-f58a-4b4e-b370-b011795b1dcd	4a0b448d-3fb8-4474-a9d9-267f5319518f	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
d15bc34d-0286-4757-b9ac-9c4042c73d75	63e1b692-a6ed-4edf-8373-9349000b5f5e	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
da3f4e65-bbfc-4b47-aa65-11cb0f3a7120	f697ee81-89c0-4297-a5de-62ac36f325b5	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
186b2e51-650b-4955-a05e-7ddd469ddd8f	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	52	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0fc12562-3229-4cc8-b37c-b727bca6ad0f	42433484-7a92-4459-9509-536e55910c3f	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0f70e1b6-7c39-4bee-be0e-db1692949c0a	9d3efcc1-82a7-4697-9aca-9c11c4a31037	200	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
3ba202f0-2f1d-491e-912d-4c7f4b153165	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	20	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5a164b5e-1c67-4bb7-b1e5-2a78c6e11439	b50611fb-eeca-4b74-a02a-91e2ea2d9846	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
ad794469-4905-490e-b0e2-03ce490239f8	154fbfed-8711-471d-badf-6bad744ce246	10	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
e7ca05af-920a-4312-807d-d14e03723f9d	2f1bb631-b9aa-435b-9217-341aa3fe9ada	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a2ffaff9-0904-47b4-8ffa-293c0e5b255f	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	12	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
dfd5d96e-20e5-42b0-9c0b-8d73ee2935c5	1df32cc2-2332-4453-9847-ad60db9ed220	13	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c967ebfe-6e3b-4c24-bee8-40084e8e0ffb	d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
155afeb7-1b3a-4c9d-8146-df15476a0929	e1d8a6b9-b965-479f-a777-f85b0df18c59	24	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b1068c37-31f0-4e52-a896-e3923431f31f	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	16	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7af6808d-daf2-4bbb-9947-a1931c79b7ca	7640cb52-77e0-4374-a235-bdb6e0d41503	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
62b4c693-815b-469c-9204-4abc12dda5f0	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
df926210-4524-48bf-a5d2-d26f273eb814	12524346-ae4c-414d-a09c-d1fd4640cb50	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
88d4d842-caac-460b-98dc-a5c7f6cee8ea	fda6810f-87ff-4863-9c2b-e0213ac55cc8	9	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
6d4243f7-643a-4a10-99c0-5d5f4e1ef120	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
80c03a04-1099-46d9-8ccb-df6c483520bd	38150feb-b79b-45e8-b451-9a1aeb96af06	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
83e06e6f-a216-4a39-b517-3019273d7749	f5336cfc-123e-412b-9128-4aab6543591c	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
e209644a-8ef2-4bd6-8844-5a1ee0bf588c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	67	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
3eeea862-ac92-4e79-8087-065405f8c882	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	13	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5cf44534-2523-4b40-b077-a6f9409c80f5	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	32	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7c3e0fa5-15ba-4824-8369-0d125dc45899	f1aabb46-04f7-4c4f-83c0-d532953304a1	36	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
04a66bca-4b1a-43c5-abc4-c7497b6e7f14	48c8796e-48a2-4355-b4e7-16bce21b2710	23	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a575e709-0194-4957-ae9c-328bac5d00a3	f837a23f-6bcd-4d96-9291-bba4d69caf3c	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
94bc1afb-d07e-4deb-8a35-82193b48f6c7	6faff9cb-851d-4fcc-8478-a18c83228de5	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a8aec445-b83a-4da2-9d26-b8a1a1031d70	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
d9da2076-5a2e-498c-8424-fd4b907c3a59	ba28ef00-70b2-4902-94ff-cd4545a1e506	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
ca824ccd-9a62-4b65-98a6-50804b28d664	79f46b6a-9be6-4131-a71b-79f864b7efe6	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
02484599-2c5f-4b18-a496-79516b57f665	55170fd5-00ce-4241-9620-ee6dced18987	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
30bb15c2-ad09-474a-b811-8212bbdd9020	0a2d780b-6404-4826-a300-d6c89964ae40	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
aee1b326-8900-4428-a4ac-2a3fe790cd92	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7b4fb20b-562a-4fdd-ad44-5385ecb62eaa	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	15	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9be207e0-ea42-4506-aa59-4ff4ec89135d	2d096f70-6b8d-4a45-a9b9-0388c96a945d	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
952cedd6-99fd-4815-82a1-d76273b61fb3	9cbfc261-d617-42b5-be18-97be0da5540b	85	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9efcec25-b85b-439e-ae0c-1dbdf9dfcabb	5a072e55-b0c1-4102-9b9f-6e786d9a2343	18	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a9cab9e3-370b-48a5-887c-480e85fe1905	94d568da-7421-440c-839d-30290b500f97	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
1c0a6628-e265-479a-b9fb-97bbf068539f	2506f42e-d3d7-41f8-ab97-0473118c3630	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0798e611-4408-4563-bc95-dfa3bc5caf83	49147609-1a68-4612-a2a5-3845b60a2d38	50	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
aa5547c0-3680-4233-957b-0d501dfb2a3d	2589ccdd-7774-4eb6-952f-aff007ddc585	500	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
00fe6107-bea7-4b2a-8016-58b5a9215e67	5325af28-0ff3-479d-ba25-2507b2dcb708	1000	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0e7607f8-d698-4b5d-81a3-a9a2be2deece	598eb297-3ff5-47e5-8cb9-5904f6bbf516	24	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
bff73855-d302-4677-8cd3-d947511408e1	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	94	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a39244a4-109d-45a6-b6b7-1631cfc9d9db	571fa9c2-9b3f-4171-aebe-a02e9a9e79db	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
eaf48bcc-82ed-4fd7-9119-11c98042aecb	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	1	\N	2026-10-16	34cb4aa6-890b-4397-bf22-95f48620affa
b7ae2d03-58ce-4c3b-b18b-37d3b8642f01	0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	2	Opening stock	2026-10-16	34cb4aa6-890b-4397-bf22-95f48620affa
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, product_id, change, balance_after, kind, order_id, note, created_by, created_at, pending_id) FROM stdin;
1d5664e3-e114-4d91-9c5d-0d6d6e7080db	ead2b374-e435-4025-bead-d804071dda77	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-12 00:00:00+00	\N
7b1fafd6-1724-491a-b253-070cf9774424	ead2b374-e435-4025-bead-d804071dda77	-2	1	adjustment	\N	Other: sold by boss	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:14:12.29217+00	\N
c5cf5837-70a6-4fac-9f28-1f6611c609c9	d6d4fda9-6087-410a-8bc9-0a5622f40e32	8	8	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:16:44.535088+00	\N
64abc2fa-594b-442f-bcad-c3360708db0d	cf5815de-94e6-426d-8eca-594e2ef0f803	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:18:36.41876+00	\N
16b2374d-4885-4955-9e09-610fd834320a	9ff4f240-9f00-460f-87f1-e745c6647e36	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:20:57.98406+00	\N
73942ac0-33c7-42c4-9e39-49c78bbe52ce	91abfef3-d9b8-40d2-9109-a66e97f2607c	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:23:13.341824+00	\N
7976fa30-e9f6-4dc6-95a7-49f0041e5846	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:24:22.226628+00	\N
88f6144f-01e4-4285-b1ac-58fbd61db39b	51291b09-5c9c-4ece-b5ab-caab1507e9e2	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:25:58.615783+00	\N
1b254707-54c9-4a4a-93de-1bb74b15cfd0	e32d59af-01ec-496c-9be5-ae5285d46a1a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:28:01.609741+00	\N
528a9a2e-496b-41b1-9a88-74a054a634e2	427a9551-fb8c-45c7-9076-19c9ee015002	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:32:07.155804+00	\N
802ecac6-cc6b-4578-bcaf-9822b156ba32	9c309e3f-ca58-4ed7-b6f8-1ff19b498864	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:33:13.400178+00	\N
523a8e77-f5ee-4a7f-84ba-96402d1b9192	6452048e-904a-481d-9879-dfbc9b3b89ba	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:38:06.406846+00	\N
f7ea004b-3e6d-4f4b-b52e-2126894aa22b	5a58c58c-8ed5-4082-a9e3-3d91b026c57d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:39:35.792907+00	\N
9d6d86e8-3e26-428d-8144-15f52d6ee0c7	280a9428-5bc6-41a2-beee-924f8d94d88f	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:40:47.695585+00	\N
d3f186bb-918e-4dda-935d-edfa7159866c	81ef7ace-0699-42db-85ba-4c050a08a008	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:44:07.803391+00	\N
a3cf6ed5-4119-4916-af5a-b9be249edeba	c8247369-36e0-4af0-99cc-13be486f3c9d	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:45:29.740931+00	\N
91da6700-443b-46c7-8064-ca5ef206624a	2cf77d43-efc0-4773-9519-610d10df99b7	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:46:06.554927+00	\N
28622306-091c-45f7-b91e-e82edd095f8c	6d4f3554-2ee0-412a-af30-471500879cbf	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:46:53.924006+00	\N
9255b687-4a77-4d55-9128-a0ec78a66f86	171c693e-768a-4e98-9fa7-b78f91a85944	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:48:04.386968+00	\N
c7f530d6-ad9a-43bd-b212-e58543f3a974	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:49:12.937227+00	\N
a2040193-198e-411f-9b82-e7c8bcd1655f	cb424877-c00e-41ba-a9ab-94854c930087	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:50:01.948199+00	\N
24c49d8f-9f2f-4223-947b-2b5663587833	a9061735-ec3b-4533-8124-e44acec27679	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:52:18.525726+00	\N
1203f35d-5491-4100-bc7c-db8bedf4554b	bab661ed-e425-4095-a183-0c8b35a9a73e	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:05:57.536919+00	\N
2b4c96c0-55ab-4869-be2b-0fb3056dd009	ea5ebf85-f433-452c-ba48-3f8c921b68c0	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:08:04.894889+00	\N
5acfc7b6-bc4e-4c60-811f-f55c7b3149f2	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	22	22	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:09:41.952869+00	\N
dba1c6cd-7559-437a-8ae1-361b8e40f7bf	fab99f9a-b0b2-4e61-989f-5a2da8585cb8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:14:03.599246+00	\N
355eaa65-481e-4cfb-b5e2-2b6fc3586dbf	3e76ff9b-1c77-4346-891b-0123b161eac8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:16:32.643717+00	\N
df5d08fe-7550-4bb2-bbb6-762f01956261	653d76e0-0733-41e3-8620-8901b926557f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:18:02.852007+00	\N
2ace7d52-59a5-42e0-a48e-d222097ce30f	421af267-9183-4ddb-a550-00597fb5a6f0	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:19:09.497528+00	\N
db037915-2228-4217-a80b-d2ae8c1d6ff0	64b67e4d-cc43-47ca-87aa-5ba976f98625	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:21:59.76094+00	\N
b5ae4a3a-266d-431f-8150-59313b397841	5f57a013-29c1-4526-b33a-dee64e43db66	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:23:13.941687+00	\N
985cccd5-8bbf-4ea3-a880-25ca1e532308	bc6e03e2-4719-41ca-ae33-56363faf99a3	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:24:21.620837+00	\N
b05a0502-4d3b-4ff0-8682-ad15a480963a	1bbd62da-cf4f-473a-a6e4-1b76dae811b5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:26:50.100715+00	\N
c473cae1-b4d6-4df2-afa5-ee561dd2bbb5	6c0ed636-bee3-4945-ba22-9947e85b0e8a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:30:27.75234+00	\N
126a5c7d-e572-467e-bc7e-ffec282f3bfd	c4ada7ad-90dc-4f0b-80c8-255fb280929f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:35:09.925411+00	\N
e04d004f-404d-44bd-80d5-4dba34e1889d	5dd86b23-1a0f-4610-b26f-1844b931e8cb	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:37:32.658791+00	\N
b3905f15-2bf3-4584-876a-a955ed9c7074	c4be0085-5b40-4025-8c3b-daaa440d0605	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:38:28.817446+00	\N
391fb9bc-d957-46ce-a0f4-3ca275d72de8	2b78a00f-31f9-49df-bbc8-6a974284d9b3	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:41:15.428713+00	\N
835adb62-df19-4dc8-a6f8-512de4717f45	bf552471-6e68-44ee-87c9-d9fd808c3f05	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:43:07.785748+00	\N
d3e2c591-52be-4bba-9ccf-9bc62c440781	c7d35921-00d7-4dd9-99f3-9d97185c8190	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:43:38.989417+00	\N
1bbd0637-fee9-4bdd-b88b-fdbed40b4665	5dae3134-fa21-4b2f-8ddf-a1570bd60b39	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:44:09.655478+00	\N
09d6b410-7177-40b7-8cda-7fce1146c8f7	04e87bfa-87b9-4bb3-ba33-679389a8fac5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:44:59.354466+00	\N
9bb96e5a-6bad-41cc-a10f-99b14980ae16	2a93e8fb-51d0-4098-8240-98a251b14f1d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:45:31.161547+00	\N
9f885a59-9e2f-4dec-b32d-8cf4994d2d83	cab8db31-f31f-433f-8bf2-8f551509c2f7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:51:31.447343+00	\N
9f42c85e-5b7e-4756-8513-a0ed9b3bf389	d95e9245-a421-4351-89a2-6c363c15c948	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:52:23.418291+00	\N
44a71255-2272-49fe-b230-8cdc6c4d1b38	b9b11539-9378-401d-b02f-1a6c57468a00	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:52:46.877588+00	\N
cb174aed-0aa7-4d5c-a7aa-7debfbf174dc	7fecdac8-2555-4a55-972b-e44c988f2e3b	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:17.657303+00	\N
c3b99081-15a3-409f-a0ce-01015f0fee64	5f6badbf-8cf8-4416-9bf4-873503e719c5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:40.283243+00	\N
148a3afc-c478-4afc-8e48-0f4d9d795523	308fcffa-e9b6-4762-a000-74f95c9ca638	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:57.9823+00	\N
20ee4c46-8fff-4419-a9bd-9549f00e28b9	4cd01e41-701c-48c4-991e-459cc8e31a3b	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:54:56.210398+00	\N
15572c8d-d657-4de4-905d-1d67c5499554	d5ef0c98-1636-44ab-beb9-00c32af409e6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:55:33.096023+00	\N
7283a673-e7ac-4850-90c0-5bff1195826c	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:55:52.096984+00	\N
ae350ed0-5be6-4aef-bb01-6145ac1bb1db	659be18d-7cb2-47fa-a814-6d48cc07b97b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:00:46.464725+00	\N
45729c40-9b20-46a2-92f6-9d5d58d7cdff	65f2bdb9-292e-4f42-87af-ba69db497a1d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:02:36.217299+00	\N
2d3c788f-0a20-4639-87f9-998742b36248	461e45a1-6171-4515-9ada-d619ef45641b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:04:29.527882+00	\N
d409ff18-b806-4915-bd5f-c02b2cd1fce4	2a0b04c3-f851-4a67-9850-2fbf78c5e078	44	44	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:08:23.222799+00	\N
06cc839c-e101-413a-bfb3-fe2f8423c2ea	2ff86e38-152d-49ab-801f-dbc3b8f682ac	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:11:39.939786+00	\N
f76b573d-9b3e-445e-8794-54934f36c11b	c4e57f6d-25dc-4abf-8212-37351a30f621	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:13:15.447314+00	\N
45fc191f-43b0-4ec1-9870-0b1f8fb3f264	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:16:49.598773+00	\N
374a3a26-6286-474d-b033-6ad3c302a8ef	051566a2-cdd1-4edc-b86b-afc306c0f1ef	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:23:48.591876+00	\N
a3f9fffe-ab0b-4f1f-aa4a-cc5ddf7b0352	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	12	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:24:18.744078+00	\N
e2966a06-e5df-479b-b95a-55a24d3ccf2e	2ff86e38-152d-49ab-801f-dbc3b8f682ac	1	21	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:24:33.278915+00	\N
c4830510-3e3a-4afb-aabd-c03dc5191e57	f2b1be08-5c83-4eda-8b9f-6ea582926dc1	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:26:16.381748+00	\N
a90751f1-3780-410f-bfe8-a839ed46d4f3	34de459c-89d8-4821-9511-5b271b020f1f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:26:59.152921+00	\N
6ba92b0b-2218-4b89-be86-abc6ea17d0fa	8e99c78f-3a46-4b61-84cb-e621621ccb57	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:28:04.323414+00	\N
0e294ded-523b-4db9-adcb-c1f2ea08bdec	3c9fc04b-2f30-484a-9889-9236bd4342a0	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:28:36.037254+00	\N
8792f564-c31a-4a5d-80a7-186592705fc1	056fe8d8-9df5-4505-9a85-faaaf1cd5377	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:03.873261+00	\N
b0f4994a-e500-4370-9191-a74782da9d81	322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:23.622546+00	\N
e5380581-a8f6-43ab-9c6a-05d472007e79	75adac4f-8200-439b-8426-0d1986416946	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:56.154485+00	\N
c2e5a42f-b6c5-4314-a911-9f5cb8d65f8b	757ad4e5-8fd5-41a8-8141-bc0909726064	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:30:36.365946+00	\N
b84b58f0-1a51-42de-bb6d-0bc0c81ffacb	cdfc7193-716c-401e-987e-ce20381b3e44	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:30:56.292159+00	\N
03a0563c-84f5-431a-a288-823d8b8d185a	d64307a7-c776-44e1-9823-0a94a43d9fcd	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:31:16.206873+00	\N
40a49c8a-751a-42d7-a586-fa22c6896883	190becce-9184-429f-b602-55c7beecea24	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:31:40.624424+00	\N
871ceb20-159a-4977-998b-3b21d11e3f11	a1d9955d-4411-4f64-9dd7-b460068d52bc	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:32:11.197926+00	\N
29b306c8-21bb-41cd-b71e-677455082576	cba33b9f-880c-42fa-b4ff-bf55a415bfb7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:36:17.270806+00	\N
f7b2ec67-816c-4a4b-b978-5b4d21c7f1db	d4790878-c6c0-4c47-8c42-d8fdee4727d0	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:38:22.807798+00	\N
a21f3042-1e27-4864-af7c-c2a49dfc2620	e43b07dc-3e00-442b-8ab0-1b78e55d200e	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:40:40.220539+00	\N
49ca0cdf-ceda-4e82-bee9-328dea8bbdc2	26d5d1c1-9d87-4970-97e6-57791b50c3df	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:42:32.548036+00	\N
16bb6be8-89f8-437c-93c8-26d344353157	f6f3649f-2f07-4c67-9943-5ab1429892e6	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:43:56.548351+00	\N
e6273221-2b47-44e4-a20d-f2771bd15f07	576cd245-ef27-4989-8960-f52085ab307d	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:46:22.262119+00	\N
0264bdc5-3112-4cf7-bfbb-e83b384538d8	1c945adf-e636-446a-a0a9-1f3a712271c9	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:48:14.096528+00	\N
5cc93e09-0db3-4765-a924-a45a544e5389	60c5327c-1e65-45be-8e6c-d466d560f1f4	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:50:13.801932+00	\N
83884bf2-ace7-4739-9f67-8516b4265865	ad8ca44c-84e8-47a9-869a-0cb70f002019	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:52:17.507223+00	\N
0952a8ac-ca0e-4a52-bbed-18e1a2a33e72	14192d9b-42e4-43bf-b319-4cd7584aa3d8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:54:01.006756+00	\N
4c8c4c79-1d4a-4cce-a410-5dccbce6ea9a	50ab9fee-98df-4ae0-ac78-4cbbc592272d	10	10	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:55:44.466965+00	\N
6240c01c-ce39-4ee6-9569-93f8a01d621f	def0af54-5508-4904-8e51-c0dbf72a1618	17	17	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:56:47.232969+00	\N
18df09c6-c186-4cfc-8cbd-f34910a2b4cb	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:58:48.852895+00	\N
97f9f66a-658e-4bd3-905f-95aeae3c9d0a	491bd73e-fc85-400e-beb7-c0f433899ed8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:01:16.607114+00	\N
1faabf66-8006-49eb-8d72-bed978a6e3f1	acf4c443-9c3c-4c75-8886-738a9765d34a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:03:01.342056+00	\N
e208c8fb-4fff-442a-b22a-89d5a23ac101	98816970-f9e2-4868-a95b-873475f0db3e	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:04:33.931128+00	\N
34fa8a9e-ab1f-494c-8da3-b1f6ae02389e	61dec910-f577-481c-93ef-f832bcec3d9f	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:06:52.385005+00	\N
02cdd717-684a-4a2d-8010-81e5ba391519	7fed6899-c746-49a4-a2da-cf871ceb495f	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:08:35.681418+00	\N
a839c873-a2c6-4637-9fd5-356fc85b4dc7	5b736c5f-3c02-4672-8497-7dfc17b49a80	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:09:18.916113+00	\N
bc5cd33a-ea82-459a-8346-30ae9534e743	313c3a6a-b5bd-4b67-b3bb-9552f7207c59	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:11:04.366202+00	\N
3bc5d049-2f34-4d99-8ec4-970170a5013c	05e53106-69b8-4682-a6be-b6de4bd64000	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:13:12.180141+00	\N
f0fde5da-864a-4aa3-bb69-d4b2a6f626d5	99777cff-18a4-4e87-bc75-988d35589c33	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:14:57.015913+00	\N
0e254a6c-c250-451b-a2ef-300fb3ae711f	d4185435-b8a9-48bf-b7b1-7446245b35ab	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:16:02.34628+00	\N
4309d138-15b8-481b-be8c-206f09e26bab	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:19:10.162089+00	\N
195119eb-5aff-45d1-9b01-a683b652bba0	59c06c74-f342-4be2-bc93-547b7f242c03	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:20:58.183658+00	\N
d22b14cd-fd16-4463-9cc1-d25cc8c32d93	5ebb6d12-aa2b-4275-b322-949e5e7cc086	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:21:57.233403+00	\N
9293f975-7bf1-441a-867b-4ec242771263	41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:23:29.167174+00	\N
6eb41013-46ee-42f3-8483-e91efc69488c	4fd457b6-2f0f-4771-b8fd-d54283355d9a	1	1	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:24:33.167517+00	\N
50bbe44d-8be2-4b8c-a1c8-8caad2871d29	9db7aae9-12d8-4716-aff7-0532026f939a	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:25:46.783427+00	\N
bd8318d0-bb8b-4fd1-a6af-4f05b9747d6c	ec733761-dbcb-4ae3-839b-8f759f29057f	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:27:30.010478+00	\N
d8dc3903-a4cf-4bd4-b449-73b4ad349fee	371b2c03-2b4b-4a87-87f4-bd2694338ef5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:28:49.996738+00	\N
4d28ea23-02c2-4980-9805-2b07c7453229	1cfbbd77-1dd6-41ac-b603-35af72ec737d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:40:16.980545+00	\N
d3a4ccca-a452-4616-8b2d-f3fe560fed8b	d95e9245-a421-4351-89a2-6c363c15c948	2	5	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:40:58.896836+00	\N
06e0ca8a-0dab-4ca5-9b81-5e0fb437eef6	7fecdac8-2555-4a55-972b-e44c988f2e3b	1	5	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:20.045874+00	\N
4190264b-ac75-4015-ba4f-d5f38d0c8ffe	308fcffa-e9b6-4762-a000-74f95c9ca638	1	3	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:36.58368+00	\N
e955d6e9-eec3-4496-8519-985dede857ce	d5ef0c98-1636-44ab-beb9-00c32af409e6	2	3	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:58.567531+00	\N
be76b756-87d3-46a2-ab5c-0d8ea051e021	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	2	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:46:06.366686+00	\N
3deac078-3387-49c2-847f-e2c945af2fcc	fa3c9366-9b08-440c-8725-c5180ae578ee	60	60	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:25:55.426066+00	\N
ae8e536f-89be-461f-ae3d-3795860dfabc	a7206327-20b6-44b6-b489-d2f563ee49b2	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:27:37.56164+00	\N
01a2340e-7979-448d-be1b-5ec4f50bbcee	feed7224-1883-4dbb-87e9-244150e61d54	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:32:57.133409+00	\N
5bf3531b-5404-41ad-a3a8-70d042c953da	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	27	27	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:36:46.900424+00	\N
a531605d-f77a-41cc-9834-87003692fe07	731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:39:52.5792+00	\N
6fa7768d-25eb-4386-bda6-2c9978bfddc4	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	-1	26	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:40:12.223541+00	\N
dcebae7b-5997-426d-9ce4-527971d475c4	ed335ad7-006a-4922-ad15-53f8faa37e4a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:42:14.398541+00	\N
c7ce8ac8-aaa6-4a0e-84bb-c3fb1f24cc2c	d359c066-20dd-4f17-baed-699c38753958	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:45:27.149209+00	\N
f7620eea-3fca-4d70-b97d-950fb48a05cd	0f537939-ec3d-4520-8ec6-450b21480858	15	15	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:47:32.295762+00	\N
f31f9e65-0ff2-4685-b4a9-d824b5d1da25	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	42	42	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:48:41.125475+00	\N
7c150249-db88-4b5d-9b15-c927b31b9f8d	d3992ca7-83aa-453b-a8d0-21d9644f6782	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:50:51.617834+00	\N
949f926e-fbda-4dc7-85c4-f292ba0ac4c9	daea334f-45d9-498f-91c5-c57769160d0b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:52:44.224183+00	\N
e5c3a42a-022a-489c-bc39-c0470e1a6ac3	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:55:51.694873+00	\N
b790b994-ba0a-4347-a226-66c3439f837b	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:03:08.565117+00	\N
b794e984-00ec-4b19-bcb3-9bb37b369d05	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:03:59.623732+00	\N
82a04529-536f-45c2-bdc3-6b96aa7b372a	c02fa806-d252-4315-b4ae-b1ea0846c420	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:08:25.671193+00	\N
819c8fc9-8c95-423a-b4cf-a2c45c589475	613b356c-997c-425c-98f3-876bb2203c6a	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:09:59.197722+00	\N
6ed0c437-54dc-492a-b1a2-0d08fb1830d2	0ded23de-1d23-4279-b783-1e5c5a59ca5d	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:12:15.949485+00	\N
40a10de7-07b0-4fad-a356-231e9617f9ab	b5fe9c12-b945-4aec-9049-39a8b9159733	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:13:18.191631+00	\N
f13aeb52-b8af-4d6a-8bf8-9e8fa406eb81	3572f4d3-23dc-405a-a94e-3fa793df5fee	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:14:51.719011+00	\N
d532df4e-035d-4d21-a10d-0f1da8b108ca	bb775507-b788-41fb-ba00-660b1911bba2	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:15:32.700862+00	\N
a03e705b-60aa-41c8-a728-6e93d1367d99	b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	68	68	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:16:58.562776+00	\N
dfcc3570-1714-4c7f-b80f-badd0a0af39c	ef7a13be-5ef7-4044-a641-60561d491a66	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:19:36.514642+00	\N
7c9e9383-4dac-4a40-91be-3ec63f75b11c	28103a7e-6f63-430a-bac2-a8c6eef4b4e5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:22:29.264026+00	\N
94f7e891-c787-422f-9d29-5bb5da59a433	d3992ca7-83aa-453b-a8d0-21d9644f6782	117	122	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:24:25.086295+00	\N
2be70da0-4105-479f-bb63-6bc7395ca408	9b2a4a10-c691-4cdf-957e-78ec49a74c7d	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:26:12.380536+00	\N
ab9a12b0-7953-48c3-9a4d-13738da63277	56cdbdf2-3b93-46e7-9f90-83373145f827	18	18	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:29:58.216707+00	\N
35584b73-889d-4f58-af52-4bf5ed624d2e	1d462684-8f12-4d3c-8828-8b4f20f01e28	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:31:09.888534+00	\N
7f0e56e7-84c7-43ef-8fa2-66d0353ef0fa	4a0b448d-3fb8-4474-a9d9-267f5319518f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:32:44.837015+00	\N
209d3fb5-b9aa-4cfa-88f1-58f4603279e8	63e1b692-a6ed-4edf-8373-9349000b5f5e	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:34:48.562526+00	\N
4f1a2fa5-36c7-46c0-806a-a9cf842454a2	f697ee81-89c0-4297-a5de-62ac36f325b5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:36:02.915495+00	\N
52d8ba86-47de-41f1-aa7e-bd6426a1fca0	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	52	52	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:36:58.670777+00	\N
676857a7-843d-4334-940e-9a08d6fe2b20	42433484-7a92-4459-9509-536e55910c3f	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:38:20.649965+00	\N
b00ffef1-3a72-4318-af86-9f4cde4abe15	9d3efcc1-82a7-4697-9aca-9c11c4a31037	200	200	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:39:50.841446+00	\N
69716f9b-79a7-4222-b501-ac5dc701a603	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:41:42.818716+00	\N
5d0641d7-0094-4c4a-a006-6dad573e6470	b50611fb-eeca-4b74-a02a-91e2ea2d9846	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:43:20.639024+00	\N
e2044940-5e71-4de4-a168-55c3517c7756	154fbfed-8711-471d-badf-6bad744ce246	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:44:28.587121+00	\N
12a0c5a4-e81d-4c69-95e2-b7ff6f347647	2f1bb631-b9aa-435b-9217-341aa3fe9ada	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:45:23.247029+00	\N
4fe3a15a-1fda-48f2-bf06-2053aac9e079	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	12	12	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:46:31.782951+00	\N
6a10b3f2-f106-4824-b2ac-de2a4909f6c3	1df32cc2-2332-4453-9847-ad60db9ed220	13	13	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:47:20.287321+00	\N
f7fc3019-6869-4869-baaa-14cfbe2d73b2	d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:48:15.048272+00	\N
f0e4563c-3b64-438c-965f-4f6124959c61	e1d8a6b9-b965-479f-a777-f85b0df18c59	24	24	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:49:34.544987+00	\N
2b6a243d-7e49-4df2-b38d-755760d00f00	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:51:14.325327+00	\N
5daebd62-ef82-44bf-a780-514b09298dc5	7640cb52-77e0-4374-a235-bdb6e0d41503	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:53:13.281167+00	\N
b296f55d-7f6b-489d-b5f7-8dff6fda5494	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:54:35.16856+00	\N
5d3550be-1817-4bce-8118-ddf250d42a06	12524346-ae4c-414d-a09c-d1fd4640cb50	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:55:56.633947+00	\N
d3156697-5bfb-4162-bee3-3449c478ba4c	fda6810f-87ff-4863-9c2b-e0213ac55cc8	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:57:21.216536+00	\N
bf691f26-3881-4378-be24-97753bda56ae	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:58:00.32373+00	\N
f9b40e3a-06e1-4dcc-8a85-3554648fa33f	38150feb-b79b-45e8-b451-9a1aeb96af06	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:59:47.711554+00	\N
c513967e-0443-4a70-8c27-361435f75423	f5336cfc-123e-412b-9128-4aab6543591c	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:00:47.249339+00	\N
34b7559c-74fb-4bbf-8e0c-7a2ba7fa7d08	507af4d6-75cf-43f6-a30a-3c118c7cd48a	67	67	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:01:19.240937+00	\N
c9ab1bc6-dd80-45d0-bcfb-7ee6fa4d8088	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	13	13	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:02:03.875897+00	\N
5eef7668-f2ff-4597-8cba-2f4aa1dc10ca	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	32	32	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:06:35.02952+00	\N
b0aeb07e-e1b4-4689-8eee-4539b31599fc	f1aabb46-04f7-4c4f-83c0-d532953304a1	36	36	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:09:22.540332+00	\N
27af9e52-47eb-4d07-975d-1a7a25e4e38c	48c8796e-48a2-4355-b4e7-16bce21b2710	23	23	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:10:03.162946+00	\N
5e3f3f7b-1c44-441a-be14-fad2c7cf7ae2	f837a23f-6bcd-4d96-9291-bba4d69caf3c	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:12:37.388415+00	\N
187b1117-249d-4762-a245-4e651510727e	6faff9cb-851d-4fcc-8478-a18c83228de5	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:15:47.122132+00	\N
7955863d-2584-4bfe-b706-8c73a5ac0167	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:17:57.350648+00	\N
2ee3a92b-de03-44b3-b87e-52a1412b01a7	ba28ef00-70b2-4902-94ff-cd4545a1e506	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:19:17.253652+00	\N
16db488c-8b1b-46ac-b10a-cc473c5667de	79f46b6a-9be6-4131-a71b-79f864b7efe6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:20:19.855329+00	\N
93615c14-6482-4430-a0d9-c144fe261e12	55170fd5-00ce-4241-9620-ee6dced18987	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:21:27.24692+00	\N
63d0af46-daec-4a46-8570-002f1d8e0a39	0a2d780b-6404-4826-a300-d6c89964ae40	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:22:33.170715+00	\N
bee27afc-b1bb-4515-83c3-4abec2c1e21f	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:26:04.88851+00	\N
7a574de8-49d7-403e-b4d0-45bd0dd912c9	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	15	15	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:29:18.840437+00	\N
9d006dbb-5b8c-4514-9ce5-3ac05916a057	9d3efcc1-82a7-4697-9aca-9c11c4a31037	2300	2500	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:30:49.716027+00	\N
7926c793-db53-4e33-a1f9-1438014ca253	2d096f70-6b8d-4a45-a9b9-0388c96a945d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:32:26.761328+00	\N
78b233a3-f1a8-4a5d-b4a6-98cf37dc8536	9cbfc261-d617-42b5-be18-97be0da5540b	85	85	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:36:38.056063+00	\N
43e9dc19-7d79-4302-be62-7f105d11d29d	4a0b448d-3fb8-4474-a9d9-267f5319518f	3	4	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:42:48.909531+00	\N
cadb62b2-c117-4407-98c1-841f21b21c20	5a072e55-b0c1-4102-9b9f-6e786d9a2343	18	18	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:46:43.250801+00	\N
5a09cff3-4591-408f-ac53-5778b104032c	94d568da-7421-440c-839d-30290b500f97	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:49:17.042516+00	\N
62e77a08-cbf9-4c0c-a16a-48e01bb53109	2506f42e-d3d7-41f8-ab97-0473118c3630	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:51:15.45247+00	\N
a35983da-66eb-4410-bea7-6df0b93ffdb3	49147609-1a68-4612-a2a5-3845b60a2d38	50	50	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:52:18.141454+00	\N
ac84ff18-ae51-4333-a997-a88fe48768a6	2589ccdd-7774-4eb6-952f-aff007ddc585	500	500	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:54:20.93816+00	\N
36579a6e-2391-4155-91e6-c6df697b042c	5325af28-0ff3-479d-ba25-2507b2dcb708	1000	1000	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:55:19.10569+00	\N
65440439-098b-4d1f-9e05-48cbc1cb0e48	9db7aae9-12d8-4716-aff7-0532026f939a	1	10	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:56:39.746481+00	\N
410eb004-3135-44db-ac40-8ae0e4922ff9	598eb297-3ff5-47e5-8cb9-5904f6bbf516	24	24	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:00:05.004468+00	\N
8a48991d-d2a3-4daf-be60-bc3a38d3b1b7	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	94	94	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:10:04.940058+00	\N
9605764d-4d51-494f-a00d-682dbb927f97	ec733761-dbcb-4ae3-839b-8f759f29057f	2	6	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:12:48.674876+00	\N
282586d5-380e-4a4b-8a01-64d3987520af	571fa9c2-9b3f-4171-aebe-a02e9a9e79db	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:21:30.398568+00	\N
d652e59f-121d-4760-8a90-f60a15ec9b25	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	1	33	received	\N	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:36:58.896125+00	\N
a7315ce2-7daf-4a11-a63d-98b7d81763eb	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	-1	32	adjustment	\N	Correction	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:38:03.728297+00	\N
de1344a8-82fc-4d83-ae9e-2222a3bf65d3	50ab9fee-98df-4ae0-ac78-4cbbc592272d	-1	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:40:14.448504+00	\N
9e14c553-44f3-41aa-a74d-a2846c1a15df	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	-1	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:41:24.978977+00	\N
625955ec-09e9-46d7-a855-bcc52e14daf5	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	-1	93	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:41:38.551529+00	\N
46397558-13f5-4a01-974d-a061f2159219	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-3	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:42:36.01917+00	\N
de45fb1d-d55a-490b-8c0c-e15a17a0a90c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-3	64	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:43:33.688274+00	\N
59651727-c0b6-40f0-8bb6-1ce7c456ec24	e1d8a6b9-b965-479f-a777-f85b0df18c59	-1	23	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:44:00.11749+00	\N
b5086c26-80b1-4378-abff-923435fb4154	7640cb52-77e0-4374-a235-bdb6e0d41503	-1	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:44:16.151972+00	\N
43321001-5fd3-4922-af88-40786cf7692d	0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:47:46.004914+00	\N
106270d7-3314-4bb3-a6fd-b92deeb1687b	0ded23de-1d23-4279-b783-1e5c5a59ca5d	-1	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:43:26.88346+00	\N
095dcb1b-cc5f-4f44-af0c-0e832da9b7c6	598eb297-3ff5-47e5-8cb9-5904f6bbf516	-2	22	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:43:52.577425+00	\N
b8b96552-b864-4129-983b-d6b8f48c7b6b	371b2c03-2b4b-4a87-87f4-bd2694338ef5	-2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:44:35.144694+00	\N
\.


--
-- Name: orders_order_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_order_number_seq', 1, false);


--
-- Name: receipts_receipt_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipts_receipt_number_seq', 1, false);


--
-- Name: refunds_refund_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refunds_refund_number_seq', 1, false);


--
-- PostgreSQL database dump complete
--


