--
-- PostgreSQL database dump
--


-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.12 (Ubuntu 17.12-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	82735742-c8fd-4042-b60f-67a9fca0d0ab	authenticated	authenticated	oseigyamfikelvinkwaku@gmail.com	$2a$10$aWMzo5IEqgfhHwlOH5aO1.6/WohxHr17heGsta8jgoqcpp0wJSJNG	2026-10-15 16:14:17.586893+00	\N		\N		2026-10-22 10:31:12.422995+00			\N	2026-10-22 10:33:35.556951+00	{"provider": "email", "providers": ["email"]}	{"sub": "82735742-c8fd-4042-b60f-67a9fca0d0ab", "email": "oseigyamfikelvinkwaku@gmail.com", "username": "kelvin", "full_name": "Kelvin Osei gyamfi kwaku", "email_verified": true, "phone_verified": false}	\N	2026-10-15 16:14:17.390655+00	2026-11-16 16:44:51.756733+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	34cb4aa6-890b-4397-bf22-95f48620affa	authenticated	authenticated	sylvesterkuffour55@gmail.com	$2a$10$CX5MKCdSFj457kJO1amo0uB1mKeZqdgM/Eg3ghiz/3lXm2eNAW5Eq	2026-10-09 10:18:41.275427+00	\N		\N		\N			\N	2026-10-14 09:43:45.477652+00	{"provider": "email", "providers": ["email"]}	{"sub": "34cb4aa6-890b-4397-bf22-95f48620affa", "email": "sylvesterkuffour55@gmail.com", "username": "sly", "full_name": "Sylvester Kuffour Paul", "email_verified": true, "phone_verified": false}	\N	2026-10-09 10:18:41.228487+00	2026-11-16 17:43:53.193574+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a6271f16-534a-4325-aee1-5ed0ab3eb261	authenticated	authenticated	casperagyengo12@gmail.com	$2a$10$Bzx7adBoy9BXlC9k6ikhQO.nuV1ehuBsB14hB6QKLXSLw7NQ.ySpS	2026-10-09 10:06:17.90483+00	\N		\N		\N			\N	2026-10-26 13:22:30.733495+00	{"provider": "email", "providers": ["email"]}	{"sub": "a6271f16-534a-4325-aee1-5ed0ab3eb261", "email": "casperagyengo12@gmail.com", "username": "palatipus", "full_name": "Agyemang Casper", "email_verified": true, "phone_verified": false}	\N	2026-10-09 10:06:17.858293+00	2026-11-11 13:11:51.108967+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
a6271f16-534a-4325-aee1-5ed0ab3eb261	a6271f16-534a-4325-aee1-5ed0ab3eb261	{"sub": "a6271f16-534a-4325-aee1-5ed0ab3eb261", "email": "casperagyengo12@gmail.com", "username": "palatipus", "full_name": "Agyemang Casper", "email_verified": false, "phone_verified": false}	email	2026-10-09 10:06:17.897354+00	2026-10-09 10:06:17.897437+00	2026-10-09 10:06:17.897437+00	4a387c9e-28b0-4ce2-8409-a6aa35b1d4ce
34cb4aa6-890b-4397-bf22-95f48620affa	34cb4aa6-890b-4397-bf22-95f48620affa	{"sub": "34cb4aa6-890b-4397-bf22-95f48620affa", "email": "sylvesterkuffour55@gmail.com", "username": "sly", "full_name": "Sylvester Kuffour Paul", "email_verified": false, "phone_verified": false}	email	2026-10-09 10:18:41.267839+00	2026-10-09 10:18:41.267908+00	2026-10-09 10:18:41.267908+00	9de37e47-14d3-4362-80f5-d69addf08ebc
82735742-c8fd-4042-b60f-67a9fca0d0ab	82735742-c8fd-4042-b60f-67a9fca0d0ab	{"sub": "82735742-c8fd-4042-b60f-67a9fca0d0ab", "email": "oseigyamfikelvinkwaku@gmail.com", "username": "kelvin", "full_name": "Kelvin Osei gyamfi kwaku", "email_verified": false, "phone_verified": false}	email	2026-10-15 16:14:17.576059+00	2026-10-15 16:14:17.576122+00	2026-10-15 16:14:17.576122+00	b1c83c84-ed4e-49ed-af32-6c348782f18c
\.


--
-- PostgreSQL database dump complete
--


