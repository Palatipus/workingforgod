--
-- PostgreSQL database dump
--


-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.12 (Ubuntu 17.12-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA IF NOT EXISTS public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: adjust_stock(uuid, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.adjust_stock(p_product_id uuid, p_change integer, p_reason text, p_note text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_stock int;
  v_label text;
begin
  if not is_admin() then raise exception 'Only an admin can adjust stock'; end if;
  if p_change is null or p_change = 0 then raise exception 'Enter how many to add or remove'; end if;

  v_label := case p_reason
    when 'correction' then 'Correction' when 'damaged' then 'Damaged' when 'expired' then 'Expired'
    when 'lost' then 'Lost or missing' when 'returned' then 'Returned to supplier' when 'other' then 'Other' end;
  if v_label is null then raise exception 'Choose a reason'; end if;

  select stock_qty into v_stock from products where id = p_product_id for update;
  if not found then raise exception 'Product not found'; end if;
  if v_stock + p_change < 0 then raise exception 'Only % in stock, so you cannot remove %', v_stock, -p_change; end if;

  perform set_move('adjustment', null, v_label || coalesce(': ' || nullif(trim(p_note), ''), ''));
  update products set stock_qty = stock_qty + p_change where id = p_product_id;
end;
$$;


--
-- Name: allocate_credit(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.allocate_credit(p_customer uuid, p_only_order uuid DEFAULT NULL::uuid) RETURNS numeric
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  o record;
  r record;
  v_left numeric;
  v_take numeric;
  v_applied numeric := 0;
begin
  for o in
    select t.order_id, t.balance
    from order_totals t join orders od on od.id = t.order_id
    where t.customer_id = p_customer and t.balance > 0 and od.cancelled_at is null
      and (p_only_order is null or t.order_id = p_only_order)
    order by od.created_at
  loop
    v_left := o.balance;
    for r in
      select rc.id, rc.method,
        rc.amount - coalesce((select sum(p.amount) from payments p where p.receipt_id = rc.id), 0) as free
      from receipts rc
      where rc.customer_id = p_customer and rc.reversed_at is null
      order by rc.created_at
    loop
      exit when v_left <= 0;
      continue when r.free <= 0;
      v_take := least(r.free, v_left);
      insert into payments (order_id, amount, method, note, recorded_by, receipt_id)
      values (o.order_id, v_take, r.method, 'From customer credit', auth.uid(), r.id);
      v_left := v_left - v_take;
      v_applied := v_applied + v_take;
    end loop;
  end loop;
  return v_applied;
end;
$$;


--
-- Name: apply_customer_credit(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_customer_credit(p_customer_id uuid) RETURNS numeric
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_applied numeric;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;
  v_applied := allocate_credit(p_customer_id);
  if v_applied <= 0 then raise exception 'There is no credit to use, or nothing is owed'; end if;
  return v_applied;
end;
$$;


--
-- Name: apply_stock_in(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_stock_in() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_owed int;
  v_count int;
  v_names text;
  v_product text;
begin
  perform set_move('received', null, new.supplier);
  update products set stock_qty = stock_qty + new.qty where id = new.product_id;

  select sum(oi.pending_qty), count(distinct o.customer_id), string_agg(distinct c.name, ', ')
  into v_owed, v_count, v_names
  from order_items oi
  join orders o on o.id = oi.order_id
  join customers c on c.id = o.customer_id
  where oi.product_id = new.product_id and oi.pending_qty > 0 and o.cancelled_at is null;

  if v_owed > 0 then
    select name into v_product from products where id = new.product_id;
    insert into notifications (user_id, message, link)
    select p.id,
      new.qty || ' ' || v_product || ' received. ' || v_owed || ' owed to ' ||
        case when v_count = 1 then v_names else v_count || ' customers (' || left(v_names, 80) || ')' end ||
        '. Deliver them first.',
      '/inventory?product=' || new.product_id
    from profiles p
    where p.status = 'approved' and (
      p.role = 'admin' or p.id in (
        select o.salesperson_id from orders o join order_items oi on oi.order_id = o.id
        where oi.product_id = new.product_id and oi.pending_qty > 0 and o.cancelled_at is null));
  end if;

  return new;
end;
$$;


--
-- Name: cancel_order(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_order(p_order_id uuid, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  r record;
  v_salesperson uuid;
  v_number bigint;
  v_invoice text;
  v_by text;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;

  select salesperson_id, order_number into v_salesperson, v_number
  from orders where id = p_order_id and cancelled_at is null for update;
  if not found then raise exception 'Order not found or already cancelled'; end if;

  if exists (select 1 from refunds where order_id = p_order_id) then
    raise exception 'This order has had a refund, so it cannot be cancelled. Use "Return items" to take everything off it instead';
  end if;
  if exists (select 1 from payments where order_id = p_order_id) then
    raise exception 'This order has payments. An admin must reverse them before it can be cancelled';
  end if;

  perform 1 from products where id in (select product_id from order_items where order_id = p_order_id) order by id for update;

  perform set_move('cancel', p_order_id, nullif(trim(p_reason), ''));
  for r in select product_id, qty - pending_qty as taken from order_items where order_id = p_order_id loop
    if r.taken > 0 then
      update products set stock_qty = stock_qty + r.taken where id = r.product_id;
    end if;
  end loop;

  update order_items set pending_qty = 0 where order_id = p_order_id;
  update orders set cancelled_at = now(), cancelled_by = auth.uid(), cancel_reason = nullif(trim(p_reason), '')
  where id = p_order_id;

  v_invoice := 'INV' || case when v_number < 1000 then lpad(v_number::text, 4, '0') else v_number::text end;
  select full_name into v_by from profiles where id = auth.uid();

  insert into notifications (user_id, message, order_id)
  select id, 'Invoice ' || v_invoice || ' was cancelled by ' || v_by ||
    coalesce(': ' || nullif(trim(p_reason), ''), ''), p_order_id
  from profiles
  where status = 'approved' and id <> auth.uid() and (id = v_salesperson or role = 'admin');
end;
$$;


--
-- Name: check_order_lines(jsonb, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_order_lines(p_items jsonb, p_prices_required boolean) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_item jsonb;
  v_qty int;
  v_price numeric;
  v_product uuid;
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'An order needs at least one item'; end if;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'qty')::int;
    v_price := round(nullif(v_item->>'price', '')::numeric, 2);
    v_product := nullif(v_item->>'product_id', '')::uuid;
    if v_qty is null or v_qty < 1 then raise exception 'Quantity must be at least 1'; end if;
    if v_price is null and p_prices_required then raise exception 'Every item needs a price'; end if;
    if v_price is not null and v_price <= 0 then raise exception 'Price must be above 0'; end if;
    if v_product is null then
      if nullif(trim(v_item->>'name'), '') is null then raise exception 'Give each extra charge a description'; end if;
    elsif not exists (select 1 from products where id = v_product and is_active) then
      raise exception 'A product in this order is no longer available';
    end if;
  end loop;

  if (select count(*) from jsonb_array_elements(p_items) e where nullif(e->>'product_id', '') is not null)
     <> (select count(distinct e->>'product_id') from jsonb_array_elements(p_items) e where nullif(e->>'product_id', '') is not null) then
    raise exception 'The same product is listed twice. Put it on one line with the full quantity';
  end if;
end;
$$;


--
-- Name: create_opening_balance(uuid, numeric, date, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_opening_balance(p_customer_id uuid, p_amount numeric, p_as_of date DEFAULT NULL::date, p_note text DEFAULT NULL::text, p_due_date date DEFAULT NULL::date) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_id uuid;
  v_when timestamptz := coalesce(p_as_of::timestamptz, now());
begin
  if not is_admin() then raise exception 'Only an admin can enter opening balances'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Enter the amount the customer owed'; end if;
  if not exists (select 1 from customers where id = p_customer_id) then raise exception 'Customer not found'; end if;
  if v_when > now() then raise exception 'The date cannot be in the future'; end if;

  -- Dated in the past, so payments clear it before newer invoices
  insert into orders (customer_id, salesperson_id, notes, previous_balance, due_date, opening_amount, created_at)
  values (p_customer_id, auth.uid(), coalesce(nullif(trim(p_note), ''), 'Opening balance brought forward'), 0,
          p_due_date, round(p_amount, 2), v_when)
  returning id into v_id;
  return v_id;
end;
$$;


--
-- Name: create_order(uuid, jsonb, text, numeric, text, date, boolean, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_order(p_customer_id uuid, p_items jsonb, p_notes text DEFAULT NULL::text, p_amount_paid numeric DEFAULT 0, p_method text DEFAULT 'cash'::text, p_due_date date DEFAULT NULL::date, p_use_credit boolean DEFAULT false, p_pending_id uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_order_id uuid;
  v_item jsonb;
  v_product uuid;
  v_stock int;
  v_held int;
  v_take int;
  v_change int;
  v_qty int;
  v_price numeric;
  v_total numeric := 0;
  v_prev numeric;
  v_from_credit numeric := 0;
  v_on_order numeric;
  v_extra numeric;
  v_left numeric := 0;
  v_receipt uuid;
  v_salesperson uuid := auth.uid();
  v_sales_name text;
  v_by text;
  v_customer text;
  v_invoice text;
  r record;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;
  if not exists (select 1 from customers where id = p_customer_id) then raise exception 'Customer not found'; end if;
  perform check_order_lines(p_items, true);

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_total := v_total + (v_item->>'qty')::int * round((v_item->>'price')::numeric, 2);
  end loop;

  if p_amount_paid is null or p_amount_paid < 0 then raise exception 'Amount paid cannot be negative'; end if;

  -- Finishing a pending order: the order stays with the salesperson who started it
  if p_pending_id is not null then
    select salesperson_id into v_salesperson from pending_orders where id = p_pending_id for update;
    if not found then raise exception 'This pending order was already finished or deleted'; end if;
    if v_salesperson <> auth.uid() and not is_admin() then
      raise exception 'Only the salesperson who saved this pending order or an admin can finish it';
    end if;
  end if;

  -- Lock every product in this order in the same (id) order, so two orders at once never deadlock
  perform 1 from products
  where id in (select nullif(e->>'product_id', '')::uuid from jsonb_array_elements(p_items) e
               union select product_id from pending_order_items where pending_id = p_pending_id)
  order by id for update;

  v_prev := customer_owed(p_customer_id);

  insert into orders (customer_id, salesperson_id, notes, previous_balance, due_date)
  values (p_customer_id, v_salesperson, nullif(trim(p_notes), ''), v_prev, p_due_date)
  returning id, 'INV' || case when order_number < 1000 then lpad(order_number::text, 4, '0') else order_number::text end
  into v_order_id, v_invoice;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_product := nullif(v_item->>'product_id', '')::uuid;
    v_qty := (v_item->>'qty')::int;
    v_price := round((v_item->>'price')::numeric, 2);

    if v_product is null then
      insert into order_items (order_id, product_id, product_name, qty, price, pending_qty)
      values (v_order_id, null, trim(v_item->>'name'), v_qty, v_price, 0);
      continue;
    end if;

    -- Stock held for this product by the pending order is already out of stock
    select coalesce(sum(held_qty), 0) into v_held from pending_order_items
    where pending_id = p_pending_id and product_id = v_product;
    update pending_order_items set held_qty = 0 where pending_id = p_pending_id and product_id = v_product;

    select stock_qty into v_stock from products where id = v_product;
    v_take := least(v_stock + v_held, v_qty);
    v_change := v_take - v_held;
    if v_change > 0 then
      perform set_move('sale', v_order_id, null);
    elsif v_change < 0 then
      perform set_move('release', v_order_id, 'Held for the pending order but not needed');
    end if;
    if v_change <> 0 then
      update products set stock_qty = stock_qty - v_change where id = v_product;
    end if;

    insert into order_items (order_id, product_id, qty, price, pending_qty)
    values (v_order_id, v_product, v_qty, v_price, v_qty - v_take);
  end loop;

  if p_pending_id is not null then
    -- Products dropped while finishing go back to stock
    for r in select product_id, held_qty from pending_order_items where pending_id = p_pending_id and held_qty > 0 loop
      perform set_move('release', v_order_id, 'Removed when the pending order was finished');
      update products set stock_qty = stock_qty + r.held_qty where id = r.product_id;
    end loop;
    -- The stock held earlier for products on this invoice now belongs to it
    update stock_movements set order_id = v_order_id
    where pending_id = p_pending_id and order_id is null
      and product_id in (select product_id from order_items where order_id = v_order_id);
    delete from pending_orders where id = p_pending_id;
  end if;

  -- Credit the customer already has goes to this order first
  if p_use_credit then
    v_from_credit := allocate_credit(p_customer_id, v_order_id);
  end if;

  -- Then money received now: this order, then older debt, and anything left stays as credit
  v_on_order := least(p_amount_paid, v_total - v_from_credit);
  v_extra := p_amount_paid - v_on_order;

  if p_amount_paid > 0 then
    insert into receipts (customer_id, amount, method, created_by)
    values (p_customer_id, p_amount_paid, p_method, auth.uid())
    returning id into v_receipt;

    if v_on_order > 0 then
      insert into payments (order_id, amount, method, recorded_by, receipt_id)
      values (v_order_id, v_on_order, p_method, auth.uid(), v_receipt);
    end if;

    if v_extra > 0 then
      v_left := pay_oldest_orders(v_receipt, p_customer_id, v_extra, p_method, 'Paid with a new order', v_order_id);
    end if;

    update receipts set balance_after = customer_owed(p_customer_id), credit_after = customer_credit_amount(p_customer_id)
    where id = v_receipt;
  end if;

  -- What is still owed on earlier invoices after this payment
  update orders set previous_balance = v_prev - (v_extra - v_left) where id = v_order_id;

  select full_name into v_sales_name from profiles where id = v_salesperson;
  select full_name into v_by from profiles where id = auth.uid();
  select name into v_customer from customers where id = p_customer_id;

  insert into notifications (user_id, message, order_id)
  select id,
    'New order by ' || v_sales_name || ' for ' || v_customer ||
      case when v_salesperson <> auth.uid() then ' (finished by ' || v_by || ')' else '' end ||
      case when v_on_order + v_from_credit < v_total
           then ' (balance GHS ' || (v_total - v_on_order - v_from_credit) || ')' else '' end,
    v_order_id
  from profiles where role = 'admin' and status = 'approved' and id <> auth.uid() and id <> v_salesperson;

  -- The salesperson hears when someone else finished their pending order
  if v_salesperson <> auth.uid() then
    insert into notifications (user_id, message, order_id)
    values (v_salesperson, v_by || ' finished your pending order for ' || v_customer || ': ' || v_invoice, v_order_id);
  end if;

  return v_order_id;
end;
$$;


--
-- Name: customer_credit_amount(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.customer_credit_amount(p_customer uuid) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select coalesce((select credit from customer_credit where customer_id = p_customer), 0);
$$;


--
-- Name: customer_owed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.customer_owed(p_customer uuid) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select coalesce(sum(balance), 0) from order_totals where customer_id = p_customer and balance > 0;
$$;


--
-- Name: dashboard_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dashboard_stats() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_result json;
begin
  if not is_admin() then raise exception 'Admins only'; end if;

  select json_build_object(
    'revenue_this_month', coalesce((select sum(oi.qty * oi.price) from order_items oi
        join orders o on o.id = oi.order_id
        where o.cancelled_at is null and o.created_at >= date_trunc('month', now())), 0),
    'revenue_last_month', coalesce((select sum(oi.qty * oi.price) from order_items oi
        join orders o on o.id = oi.order_id
        where o.cancelled_at is null
          and o.created_at >= date_trunc('month', now()) - interval '1 month'
          and o.created_at <  date_trunc('month', now())), 0),
    'cash_this_month', coalesce((select sum(amount) from receipts
        where reversed_at is null and created_at >= date_trunc('month', now())), 0)
      - coalesce((select sum(amount) from refunds where created_at >= date_trunc('month', now())), 0),
    'cash_last_month', coalesce((select sum(amount) from receipts where reversed_at is null
        and created_at >= date_trunc('month', now()) - interval '1 month' and created_at < date_trunc('month', now())), 0)
      - coalesce((select sum(amount) from refunds
        where created_at >= date_trunc('month', now()) - interval '1 month' and created_at < date_trunc('month', now())), 0),
    'orders_this_month', (select count(*) from orders
        where cancelled_at is null and opening_amount = 0 and created_at >= date_trunc('month', now())),
    'pending_deliveries', (select count(*) from order_items where pending_qty > 0),
    'low_stock_count', (select count(*) from products
        where is_active and stock_qty > 0 and stock_qty <= reorder_level),
    'out_of_stock_count', (select count(*) from products where is_active and stock_qty = 0),
    'total_products', (select count(*) from products where is_active),
    'pending_signups', (select count(*) from profiles where status = 'pending'),
    'outstanding_debt', coalesce((select sum(balance) from order_totals where balance > 0), 0),
    'customers_owing', (select count(distinct customer_id) from order_totals where balance > 0),
    'overdue_amount', coalesce((select sum(t.balance) from order_totals t join orders o on o.id = t.order_id
        where t.balance > 0 and o.due_date < current_date), 0),
    'customer_credit', coalesce((select sum(credit) from customer_credit where credit > 0), 0)
  ) into v_result;

  return v_result;
end;
$$;


--
-- Name: delete_pending_order(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_pending_order(p_pending_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_owner uuid;
  v_customer text;
  v_by text;
  r record;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;

  select po.salesperson_id, c.name into v_owner, v_customer
  from pending_orders po join customers c on c.id = po.customer_id
  where po.id = p_pending_id for update of po;
  if not found then raise exception 'This pending order was already finished or deleted'; end if;
  if v_owner <> auth.uid() and not is_admin() then
    raise exception 'Only the salesperson who saved this pending order or an admin can delete it';
  end if;

  perform 1 from products where id in (select product_id from pending_order_items where pending_id = p_pending_id)
  order by id for update;

  for r in select product_id, held_qty from pending_order_items where pending_id = p_pending_id and held_qty > 0 loop
    perform set_move_pending('release', p_pending_id, 'Pending order for ' || v_customer || ' deleted');
    update products set stock_qty = stock_qty + r.held_qty where id = r.product_id;
  end loop;

  delete from pending_orders where id = p_pending_id;

  if v_owner <> auth.uid() then
    select full_name into v_by from profiles where id = auth.uid();
    insert into notifications (user_id, message, link)
    values (v_owner, v_by || ' deleted your pending order for ' || v_customer, '/orders');
  end if;
end;
$$;


--
-- Name: email_for_login(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.email_for_login(p_username text, p_password text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth', 'extensions'
    AS $$
declare
  v_name text := lower(trim(p_username));
  v_email text;
  v_hash text;
begin
  delete from login_attempts where attempted_at < now() - interval '1 day';

  if (select count(*) from login_attempts
      where username = v_name and attempted_at > now() - interval '15 minutes') >= 10 then
    raise exception 'Too many attempts. Try again in 15 minutes.';
  end if;

  select u.email::text, u.encrypted_password into v_email, v_hash
  from profiles p join auth.users u on u.id = p.id
  where lower(p.username) = v_name
  limit 1;

  if v_hash is not null and v_hash = crypt(p_password, v_hash) then
    delete from login_attempts where username = v_name;
    return v_email;
  end if;

  insert into login_attempts (username) values (v_name);
  return null;
end;
$$;


--
-- Name: guard_product_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_product_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if current_user in ('authenticated', 'anon') then
    if tg_op = 'INSERT' and new.stock_qty <> 0 then
      raise exception 'Add opening stock through stock received';
    end if;
    if tg_op = 'UPDATE' and new.stock_qty is distinct from old.stock_qty then
      raise exception 'Stock can only change through stock received, orders or deliveries';
    end if;
    if tg_op = 'UPDATE' and new.is_active is distinct from old.is_active and not is_admin() then
      raise exception 'Only an admin can remove products';
    end if;
  end if;
  return new;
end;
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_name text := coalesce(new.raw_user_meta_data->>'full_name', new.email);
begin
  insert into profiles (id, full_name, username)
  values (new.id, v_name, lower(new.raw_user_meta_data->>'username'));

  insert into notifications (user_id, message)
  select id, v_name || ' signed up and is waiting for approval' from profiles
  where role = 'admin' and status = 'approved';

  return new;
end;
$$;


--
-- Name: is_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and status = 'approved');
$$;


--
-- Name: is_approved(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_approved() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'approved');
$$;


--
-- Name: last_prices(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.last_prices(p_customer_id uuid) RETURNS TABLE(product_id uuid, price numeric, for_customer boolean)
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select distinct on (oi.product_id) oi.product_id, oi.price, (o.customer_id = p_customer_id)
  from order_items oi join orders o on o.id = oi.order_id
  where o.cancelled_at is null and oi.product_id is not null
  order by oi.product_id, (o.customer_id = p_customer_id) desc, o.created_at desc;
$$;


--
-- Name: log_stock_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_stock_change() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.stock_qty is distinct from old.stock_qty then
    insert into stock_movements (product_id, change, balance_after, kind, order_id, note, created_by, pending_id)
    values (new.id, new.stock_qty - old.stock_qty, new.stock_qty,
      coalesce(nullif(current_setting('app.move_kind', true), ''), 'adjustment'),
      nullif(current_setting('app.move_order', true), '')::uuid,
      nullif(current_setting('app.move_note', true), ''),
      auth.uid(),
      nullif(current_setting('app.move_pending', true), '')::uuid);

    -- Low stock alert for admins when a product crosses its reorder level
    if new.is_active and new.stock_qty <= new.reorder_level and old.stock_qty > new.reorder_level then
      insert into notifications (user_id, message, link)
      select id,
        case when new.stock_qty = 0 then new.name || ' is out of stock'
             else new.name || ' is running low: ' || new.stock_qty || ' left' end,
        '/inventory?product=' || new.id
      from profiles where role = 'admin' and status = 'approved';
    end if;
  end if;
  return new;
end;
$$;


--
-- Name: mark_delivered(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_delivered(p_item_id uuid, p_qty integer DEFAULT NULL::integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_item order_items;
  v_qty int;
  v_stock int;
  v_name text;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;

  select * into v_item from order_items where id = p_item_id for update;
  if v_item.id is null or v_item.pending_qty = 0 then raise exception 'Nothing left to deliver on this item'; end if;
  if exists (select 1 from orders where id = v_item.order_id and cancelled_at is not null) then
    raise exception 'This order was cancelled';
  end if;

  v_qty := coalesce(p_qty, v_item.pending_qty);
  if v_qty < 1 or v_qty > v_item.pending_qty then
    raise exception 'Deliver between 1 and %', v_item.pending_qty;
  end if;

  select stock_qty, name into v_stock, v_name from products where id = v_item.product_id for update;
  if v_stock < v_qty then
    raise exception 'Only % % in stock. Record the stock you received first.', v_stock, v_name;
  end if;

  perform set_move('delivery', v_item.order_id, null);
  update products set stock_qty = stock_qty - v_qty where id = v_item.product_id;
  update order_items set pending_qty = pending_qty - v_qty,
    delivered_at = case when pending_qty - v_qty = 0 then now() else delivered_at end
  where id = p_item_id;
end;
$$;


--
-- Name: my_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_stats() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_me uuid := auth.uid();
  v_result json;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;

  select json_build_object(
    'sales_this_month', coalesce((select sum(oi.qty * oi.price) from order_items oi
        join orders o on o.id = oi.order_id
        where o.salesperson_id = v_me and o.cancelled_at is null and o.created_at >= date_trunc('month', now())), 0),
    'sales_last_month', coalesce((select sum(oi.qty * oi.price) from order_items oi
        join orders o on o.id = oi.order_id
        where o.salesperson_id = v_me and o.cancelled_at is null
          and o.created_at >= date_trunc('month', now()) - interval '1 month'
          and o.created_at < date_trunc('month', now())), 0),
    'orders_this_month', (select count(*) from orders
        where salesperson_id = v_me and cancelled_at is null and opening_amount = 0 and created_at >= date_trunc('month', now())),
    'cash_this_month', coalesce((select sum(amount) from receipts
        where created_by = v_me and reversed_at is null and created_at >= date_trunc('month', now())), 0)
      - coalesce((select sum(amount) from refunds
        where created_by = v_me and created_at >= date_trunc('month', now())), 0),
    'owed_on_my_orders', coalesce((select sum(t.balance) from order_totals t join orders o on o.id = t.order_id
        where o.salesperson_id = v_me and t.balance > 0), 0),
    'overdue_on_my_orders', coalesce((select sum(t.balance) from order_totals t join orders o on o.id = t.order_id
        where o.salesperson_id = v_me and t.balance > 0 and o.due_date < current_date), 0),
    'pending_on_my_orders', (select count(*) from order_items oi join orders o on o.id = oi.order_id
        where o.salesperson_id = v_me and oi.pending_qty > 0)
  ) into v_result;

  return v_result;
end;
$$;


--
-- Name: pay_oldest_orders(uuid, uuid, numeric, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pay_oldest_orders(p_receipt uuid, p_customer uuid, p_amount numeric, p_method text, p_note text, p_skip uuid DEFAULT NULL::uuid) RETURNS numeric
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_left numeric := p_amount;
  v_take numeric;
  r record;
begin
  for r in
    select t.order_id, t.balance
    from order_totals t join orders o on o.id = t.order_id
    where t.customer_id = p_customer and t.balance > 0 and o.cancelled_at is null
      and (p_skip is null or t.order_id <> p_skip)
    order by o.created_at
  loop
    exit when v_left <= 0;
    v_take := least(v_left, r.balance);
    insert into payments (order_id, amount, method, note, recorded_by, receipt_id)
    values (r.order_id, v_take, p_method, p_note, auth.uid(), p_receipt);
    v_left := v_left - v_take;
  end loop;
  return v_left;
end;
$$;


--
-- Name: push_notification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.push_notification() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_url text;
  v_secret text;
begin
  if not exists (select 1 from push_subscriptions where user_id = new.user_id) then
    return new;
  end if;
  select decrypted_secret into v_url from vault.decrypted_secrets where name = 'push_function_url';
  select decrypted_secret into v_secret from vault.decrypted_secrets where name = 'push_secret';
  if v_url is null then return new; end if;

  perform net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', coalesce(v_secret, '')),
    body := jsonb_build_object('record', to_jsonb(new))
  );
  return new;
exception when others then
  -- A push problem must never stop an order, payment or approval from saving
  return new;
end;
$$;


--
-- Name: record_customer_payment(uuid, numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_customer_payment(p_customer_id uuid, p_amount numeric, p_method text DEFAULT 'cash'::text, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_receipt uuid;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Amount must be above 0'; end if;
  if not exists (select 1 from customers where id = p_customer_id) then raise exception 'Customer not found'; end if;

  insert into receipts (customer_id, amount, method, note, created_by)
  values (p_customer_id, round(p_amount, 2), p_method, nullif(trim(p_note), ''), auth.uid())
  returning id into v_receipt;

  perform pay_oldest_orders(v_receipt, p_customer_id, round(p_amount, 2), p_method, nullif(trim(p_note), ''));

  update receipts set balance_after = customer_owed(p_customer_id), credit_after = customer_credit_amount(p_customer_id)
  where id = v_receipt;
  return v_receipt;
end;
$$;


--
-- Name: record_order_payment(uuid, numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_order_payment(p_order_id uuid, p_amount numeric, p_method text DEFAULT 'cash'::text, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_balance numeric;
  v_customer uuid;
  v_receipt uuid;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;

  select o.customer_id, t.balance into v_customer, v_balance
  from orders o join order_totals t on t.order_id = o.id
  where o.id = p_order_id and o.cancelled_at is null;
  if v_customer is null then raise exception 'Order not found or cancelled'; end if;
  if p_amount <= 0 or p_amount > v_balance then
    raise exception 'Amount must be above 0 and at most the balance of %', v_balance;
  end if;

  insert into receipts (customer_id, amount, method, note, created_by)
  values (v_customer, p_amount, p_method, nullif(trim(p_note), ''), auth.uid())
  returning id into v_receipt;

  insert into payments (order_id, amount, method, note, recorded_by, receipt_id)
  values (p_order_id, p_amount, p_method, nullif(trim(p_note), ''), auth.uid(), v_receipt);

  update receipts set balance_after = customer_owed(v_customer), credit_after = customer_credit_amount(v_customer)
  where id = v_receipt;
  return v_receipt;
end;
$$;


--
-- Name: return_items(uuid, jsonb, text, boolean, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.return_items(p_order_id uuid, p_items jsonb, p_reason text DEFAULT NULL::text, p_restock boolean DEFAULT true, p_refund_method text DEFAULT 'cash'::text) RETURNS numeric
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  r jsonb;
  v_item order_items;
  v_qty int;
  v_owed int;
  v_back int;
  v_restock boolean;
  v_total numeric;
  v_paid numeric;
  v_refund numeric := 0;
  v_salesperson uuid;
  v_number bigint;
  v_by text;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'Choose at least one item to return'; end if;

  select salesperson_id, order_number into v_salesperson, v_number
  from orders where id = p_order_id and cancelled_at is null for update;
  if not found then raise exception 'Order not found or cancelled'; end if;

  perform 1 from products where id in (select product_id from order_items where order_id = p_order_id) order by id for update;
  perform set_move('return', p_order_id, nullif(trim(p_reason), ''));

  for r in select * from jsonb_array_elements(p_items) loop
    v_qty := (r->>'qty')::int;
    if v_qty is null or v_qty < 1 then raise exception 'Quantity must be at least 1'; end if;

    select * into v_item from order_items where id = (r->>'item_id')::uuid and order_id = p_order_id for update;
    if not found then raise exception 'Item not found on this order'; end if;
    if v_qty > v_item.qty then raise exception 'Only % of this item are on the order', v_item.qty; end if;

    v_owed := least(v_qty, v_item.pending_qty);
    v_back := v_qty - v_owed;
    v_restock := p_restock and v_back > 0 and v_item.product_id is not null;

    update order_items set qty = qty - v_qty, pending_qty = pending_qty - v_owed where id = v_item.id;

    if v_restock then
      update products set stock_qty = stock_qty + v_back where id = v_item.product_id;
    end if;

    insert into order_returns (order_id, item_id, owed_removed, returned, restocked, reason, created_by)
    values (p_order_id, v_item.id, v_owed, v_back, v_restock, nullif(trim(p_reason), ''), auth.uid());
  end loop;

  select total, paid into v_total, v_paid from order_totals where order_id = p_order_id;
  if v_paid - v_total > 0.005 then
    v_refund := v_paid - v_total;
    if not is_admin() then
      raise exception 'The customer has paid GHS % more than the new total, so that must be refunded. Ask an admin to do this return.', v_refund;
    end if;
    insert into refunds (order_id, amount, method, note, created_by)
    values (p_order_id, v_refund, p_refund_method, nullif(trim(p_reason), ''), auth.uid());
  end if;

  select full_name into v_by from profiles where id = auth.uid();
  insert into notifications (user_id, message, order_id)
  select id,
    'Return on INV' || case when v_number < 1000 then lpad(v_number::text, 4, '0') else v_number::text end ||
      ' by ' || v_by || coalesce(': ' || nullif(trim(p_reason), ''), '') ||
      case when v_refund > 0 then ' (refunded GHS ' || v_refund || ')' else '' end,
    p_order_id
  from profiles
  where status = 'approved' and id <> auth.uid() and (id = v_salesperson or role = 'admin');

  return v_refund;
end;
$$;


--
-- Name: reverse_payment(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reverse_payment(p_payment_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_receipt uuid;
begin
  if not is_admin() then raise exception 'Only an admin can reverse payments'; end if;
  select receipt_id into v_receipt from payments where id = p_payment_id;
  if not found then raise exception 'Payment not found'; end if;
  if v_receipt is null then
    delete from payments where id = p_payment_id;
  else
    perform reverse_receipt(v_receipt);
  end if;
end;
$$;


--
-- Name: reverse_receipt(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reverse_receipt(p_receipt_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Only an admin can reverse payments'; end if;

  if exists (select 1 from payments p join refunds f on f.order_id = p.order_id where p.receipt_id = p_receipt_id) then
    raise exception 'An invoice on this receipt has had a refund, so the payment cannot be reversed';
  end if;

  update receipts set reversed_at = now(), reversed_by = auth.uid(),
    reversed_lines = (select jsonb_agg(jsonb_build_object('order_number', o.order_number, 'amount', p.amount) order by o.order_number)
                      from payments p join orders o on o.id = p.order_id where p.receipt_id = p_receipt_id)
  where id = p_receipt_id and reversed_at is null;
  if not found then raise exception 'Receipt not found or already reversed'; end if;

  delete from payments where receipt_id = p_receipt_id;
end;
$$;


--
-- Name: sales_by_day(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sales_by_day(p_days integer DEFAULT 30) RETURNS TABLE(day date, total numeric, orders bigint)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;

  return query
  select d::date, coalesce(sum(oi.qty * oi.price), 0), count(distinct o.id)
  from generate_series(current_date - (p_days - 1), current_date, interval '1 day') d
  left join orders o on o.created_at::date = d::date and o.cancelled_at is null
  left join order_items oi on oi.order_id = o.id
  group by d
  order by d;
end;
$$;


--
-- Name: save_pending_order(uuid, jsonb, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.save_pending_order(p_customer_id uuid, p_items jsonb, p_notes text DEFAULT NULL::text, p_pending_id uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_id uuid;
  v_owner uuid;
  v_item jsonb;
  v_product uuid;
  v_qty int;
  v_old int;
  v_stock int;
  v_take int;
  v_change int;
  v_new_id uuid;
  v_keep uuid[] := '{}';
  v_pos int := 0;
  v_customer text;
  v_sales_name text;
  v_missing int;
  r record;
begin
  if not is_approved() then raise exception 'Account not approved'; end if;
  if not exists (select 1 from customers where id = p_customer_id) then raise exception 'Customer not found'; end if;
  perform check_order_lines(p_items, false);

  if p_pending_id is not null then
    select salesperson_id into v_owner from pending_orders where id = p_pending_id for update;
    if not found then raise exception 'This pending order was already finished or deleted'; end if;
    if v_owner <> auth.uid() and not is_admin() then
      raise exception 'Only the salesperson who saved this pending order or an admin can change it';
    end if;
    v_id := p_pending_id;
    update pending_orders set customer_id = p_customer_id, notes = nullif(trim(p_notes), ''),
      updated_at = now(), updated_by = auth.uid()
    where id = v_id;
  else
    insert into pending_orders (customer_id, salesperson_id, notes, updated_by)
    values (p_customer_id, auth.uid(), nullif(trim(p_notes), ''), auth.uid())
    returning id into v_id;
  end if;

  select name into v_customer from customers where id = p_customer_id;

  -- Lock every product involved (old and new lines) in the same (id) order, so nothing deadlocks
  perform 1 from products
  where id in (select product_id from pending_order_items where pending_id = v_id
               union select nullif(e->>'product_id', '')::uuid from jsonb_array_elements(p_items) e)
  order by id for update;

  delete from pending_order_items where pending_id = v_id and product_id is null;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_pos := v_pos + 1;
    v_product := nullif(v_item->>'product_id', '')::uuid;
    v_qty := (v_item->>'qty')::int;
    v_take := 0;

    if v_product is not null then
      -- Already held for this product by this pending order counts as available
      select coalesce(sum(held_qty), 0) into v_old from pending_order_items where pending_id = v_id and product_id = v_product;
      delete from pending_order_items where pending_id = v_id and product_id = v_product;
      select stock_qty into v_stock from products where id = v_product;
      v_take := least(v_stock + v_old, v_qty);
      v_change := v_take - v_old;
      if v_change <> 0 then
        perform set_move_pending(case when v_change > 0 then 'hold' else 'release' end, v_id,
          'Pending order for ' || v_customer);
        update products set stock_qty = stock_qty - v_change where id = v_product;
      end if;
    end if;

    insert into pending_order_items (pending_id, position, product_id, name, qty, price, held_qty)
    values (v_id, v_pos, v_product, case when v_product is null then trim(v_item->>'name') end, v_qty,
      round(nullif(v_item->>'price', '')::numeric, 2), v_take)
    returning id into v_new_id;
    v_keep := v_keep || v_new_id;
  end loop;

  -- Products taken off the pending order go back to stock
  for r in select id, product_id, held_qty from pending_order_items
           where pending_id = v_id and not (id = any(v_keep)) loop
    if r.held_qty > 0 then
      perform set_move_pending('release', v_id, 'Removed from pending order for ' || v_customer);
      update products set stock_qty = stock_qty + r.held_qty where id = r.product_id;
    end if;
    delete from pending_order_items where id = r.id;
  end loop;

  if p_pending_id is null then
    select full_name into v_sales_name from profiles where id = auth.uid();
    select count(*) into v_missing from pending_order_items where pending_id = v_id and price is null;
    insert into notifications (user_id, message, link)
    select id,
      v_sales_name || ' saved a pending order for ' || v_customer ||
        case when v_missing = 1 then ': 1 price needed'
             when v_missing > 1 then ': ' || v_missing || ' prices needed'
             else '' end,
      '/orders/new?pending=' || v_id
    from profiles where role = 'admin' and status = 'approved' and id <> auth.uid();
  end if;

  return v_id;
end;
$$;


--
-- Name: save_push_subscription(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  insert into push_subscriptions (user_id, endpoint, p256dh, auth)
  values (auth.uid(), p_endpoint, p_p256dh, p_auth)
  on conflict (endpoint) do update
    set user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth;
end;
$$;


--
-- Name: set_move(text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_move(p_kind text, p_order uuid DEFAULT NULL::uuid, p_note text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql
    AS $$
  select set_config('app.move_kind', p_kind, true),
         set_config('app.move_order', coalesce(p_order::text, ''), true),
         set_config('app.move_note', coalesce(p_note, ''), true),
         set_config('app.move_pending', '', true);
$$;


--
-- Name: set_move_pending(text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_move_pending(p_kind text, p_pending uuid, p_note text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql
    AS $$
  select set_move(p_kind, null, p_note);
  select set_config('app.move_pending', coalesce(p_pending::text, ''), true);
$$;


--
-- Name: set_my_name(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_my_name(p_name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if length(trim(coalesce(p_name, ''))) < 2 or length(trim(p_name)) > 80 then
    raise exception 'Name must be 2-80 characters';
  end if;
  update profiles set full_name = trim(p_name) where id = auth.uid();
end;
$$;


--
-- Name: set_my_username(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_my_username(p_username text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_name text := lower(trim(p_username));
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if not valid_username(v_name) then
    raise exception 'Username must be 3-30 characters: letters, numbers, dots, dashes or underscores';
  end if;
  if exists (select 1 from profiles where lower(username) = v_name and id <> auth.uid()) then
    raise exception 'That username is already taken';
  end if;
  update profiles set username = v_name where id = auth.uid();
end;
$$;


--
-- Name: set_stock_in_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_stock_in_user() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if auth.uid() is not null then new.created_by := auth.uid(); end if;
  return new;
end;
$$;


--
-- Name: set_user_name(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_user_name(p_user uuid, p_name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if length(trim(coalesce(p_name, ''))) < 2 or length(trim(p_name)) > 80 then
    raise exception 'Name must be 2-80 characters';
  end if;
  update profiles set full_name = trim(p_name) where id = p_user;
end;
$$;


--
-- Name: set_user_role(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_user_role(p_user uuid, p_role text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if p_user = auth.uid() then raise exception 'You cannot change your own role'; end if;
  if p_role not in ('admin', 'salesperson') then raise exception 'Invalid role'; end if;
  update profiles set role = p_role where id = p_user and status = 'approved';
  if not found then raise exception 'Only approved users can be given a role'; end if;
end;
$$;


--
-- Name: set_user_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_user_status(p_user uuid, p_status text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if p_user = auth.uid() then raise exception 'You cannot change your own access'; end if;
  if p_status not in ('approved', 'rejected') then raise exception 'Invalid status'; end if;
  update profiles set status = p_status where id = p_user;
end;
$$;


--
-- Name: set_user_username(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_user_username(p_user uuid, p_username text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_name text := lower(trim(p_username));
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if not valid_username(v_name) then
    raise exception 'Username must be 3-30 characters: letters, numbers, dots, dashes or underscores';
  end if;
  if exists (select 1 from profiles where lower(username) = v_name and id <> p_user) then
    raise exception 'That username is already taken';
  end if;
  update profiles set username = v_name where id = p_user;
end;
$$;


--
-- Name: snapshot_item_product(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_item_product() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.product_id is not null then
    select name into new.product_name from products where id = new.product_id;
  end if;
  return new;
end;
$$;


--
-- Name: snapshot_order_customer(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.snapshot_order_customer() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  select name, phone, location into new.customer_name, new.customer_phone, new.customer_location
  from customers where id = new.customer_id;
  return new;
end;
$$;


--
-- Name: stamp_settings(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stamp_settings() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at := now();
  if auth.uid() is not null then new.updated_by := auth.uid(); end if;
  return new;
end;
$$;


--
-- Name: top_products(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.top_products(p_limit integer DEFAULT 5) RETURNS TABLE(product_name text, units bigint, revenue numeric)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;

  return query
  select p.name, sum(oi.qty)::bigint, sum(oi.qty * oi.price)
  from order_items oi
  join orders o on o.id = oi.order_id and o.cancelled_at is null
  join products p on p.id = oi.product_id
  group by p.name order by sum(oi.qty * oi.price) desc limit p_limit;
end;
$$;


--
-- Name: top_salespeople(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.top_salespeople(p_limit integer DEFAULT 5) RETURNS TABLE(salesperson text, orders bigint, revenue numeric)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;

  return query
  select pr.full_name, count(distinct o.id), sum(oi.qty * oi.price)
  from orders o join profiles pr on pr.id = o.salesperson_id
  join order_items oi on oi.order_id = o.id
  where o.cancelled_at is null
  group by pr.full_name order by sum(oi.qty * oi.price) desc limit p_limit;
end;
$$;


--
-- Name: username_taken(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.username_taken(p_username text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from profiles where lower(username) = lower(p_username));
$$;


--
-- Name: valid_username(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.valid_username(p_username text) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
  select p_username ~ '^[a-z0-9][a-z0-9._-]{1,28}[a-z0-9]$';
$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_settings (
    id integer DEFAULT 1 NOT NULL,
    data jsonb NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT company_settings_id_check CHECK ((id = 1))
);


--
-- Name: customer_balances; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.customer_balances AS
SELECT
    NULL::uuid AS customer_id,
    NULL::text AS name,
    NULL::text AS phone,
    NULL::text AS location,
    NULL::bigint AS orders,
    NULL::numeric AS total,
    NULL::numeric AS paid,
    NULL::numeric AS owed,
    NULL::numeric AS overdue,
    NULL::text AS email,
    NULL::numeric AS credit;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    note text,
    paid_at timestamp with time zone DEFAULT now() NOT NULL,
    recorded_by uuid,
    receipt_id uuid,
    CONSTRAINT payments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT payments_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'bank_transfer'::text, 'other'::text])))
);


--
-- Name: receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    receipt_number bigint NOT NULL,
    customer_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    note text,
    balance_after numeric(12,2),
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reversed_at timestamp with time zone,
    reversed_by uuid,
    reversed_lines jsonb,
    credit_after numeric(12,2),
    CONSTRAINT receipts_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT receipts_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'bank_transfer'::text, 'other'::text])))
);


--
-- Name: customer_credit; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.customer_credit WITH (security_invoker='true') AS
 SELECT customer_id,
    sum((amount - COALESCE(( SELECT sum(p.amount) AS sum
           FROM public.payments p
          WHERE (p.receipt_id = r.id)), (0)::numeric))) AS credit
   FROM public.receipts r
  WHERE (reversed_at IS NULL)
  GROUP BY customer_id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    phone text,
    email text,
    location text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    username text NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    message text NOT NULL,
    order_id uuid,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    link text
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid,
    qty integer NOT NULL,
    price numeric(12,2) NOT NULL,
    pending_qty integer DEFAULT 0 NOT NULL,
    delivered_at timestamp with time zone,
    product_name text,
    CONSTRAINT order_items_named_check CHECK (((product_id IS NOT NULL) OR (NULLIF(TRIM(BOTH FROM product_name), ''::text) IS NOT NULL))),
    CONSTRAINT order_items_pending_qty_check CHECK ((pending_qty >= 0)),
    CONSTRAINT order_items_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT order_items_qty_check CHECK ((qty >= 0))
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_number bigint NOT NULL,
    customer_id uuid NOT NULL,
    salesperson_id uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    previous_balance numeric(12,2) DEFAULT 0 NOT NULL,
    due_date date,
    cancelled_at timestamp with time zone,
    cancelled_by uuid,
    cancel_reason text,
    customer_name text,
    customer_phone text,
    customer_location text,
    opening_amount numeric(12,2) DEFAULT 0 NOT NULL,
    CONSTRAINT orders_opening_amount_check CHECK ((opening_amount >= (0)::numeric))
);


--
-- Name: refunds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refunds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    note text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    refund_number bigint NOT NULL,
    CONSTRAINT refunds_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT refunds_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'bank_transfer'::text, 'other'::text])))
);


--
-- Name: order_totals; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.order_totals WITH (security_invoker='true') AS
 SELECT o.id AS order_id,
    o.customer_id,
        CASE
            WHEN (o.cancelled_at IS NULL) THEN (COALESCE(i.total, (0)::numeric) + o.opening_amount)
            ELSE (0)::numeric
        END AS total,
    (COALESCE(p.paid, (0)::numeric) - COALESCE(r.refunded, (0)::numeric)) AS paid,
    (
        CASE
            WHEN (o.cancelled_at IS NULL) THEN (COALESCE(i.total, (0)::numeric) + o.opening_amount)
            ELSE (0)::numeric
        END - (COALESCE(p.paid, (0)::numeric) - COALESCE(r.refunded, (0)::numeric))) AS balance
   FROM (((public.orders o
     LEFT JOIN LATERAL ( SELECT sum(((order_items.qty)::numeric * order_items.price)) AS total
           FROM public.order_items
          WHERE (order_items.order_id = o.id)) i ON (true))
     LEFT JOIN LATERAL ( SELECT sum(payments.amount) AS paid
           FROM public.payments
          WHERE (payments.order_id = o.id)) p ON (true))
     LEFT JOIN LATERAL ( SELECT sum(refunds.amount) AS refunded
           FROM public.refunds
          WHERE (refunds.order_id = o.id)) r ON (true));


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    full_name text NOT NULL,
    role text DEFAULT 'salesperson'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    status text DEFAULT 'pending'::text NOT NULL,
    username text,
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'salesperson'::text]))),
    CONSTRAINT profiles_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: order_list; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.order_list WITH (security_invoker='true') AS
 SELECT o.id,
    o.order_number,
    ('INV'::text ||
        CASE
            WHEN (o.order_number < 1000) THEN lpad((o.order_number)::text, 4, '0'::text)
            ELSE (o.order_number)::text
        END) AS invoice_number,
    o.created_at,
    o.due_date,
    o.cancelled_at,
    o.customer_id,
    c.name AS customer_name,
    pr.full_name AS salesperson,
    t.total,
    t.paid,
    t.balance,
    (EXISTS ( SELECT 1
           FROM public.order_items oi
          WHERE ((oi.order_id = o.id) AND (oi.pending_qty > 0)))) AS has_pending,
    ((o.cancelled_at IS NULL) AND (t.balance > (0)::numeric) AND (o.due_date < CURRENT_DATE)) AS overdue,
    o.salesperson_id,
    (o.opening_amount > (0)::numeric) AS is_opening
   FROM (((public.orders o
     JOIN public.customers c ON ((c.id = o.customer_id)))
     JOIN public.profiles pr ON ((pr.id = o.salesperson_id)))
     JOIN public.order_totals t ON ((t.order_id = o.id)));


--
-- Name: order_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_returns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    item_id uuid NOT NULL,
    owed_removed integer DEFAULT 0 NOT NULL,
    returned integer DEFAULT 0 NOT NULL,
    restocked boolean DEFAULT false NOT NULL,
    reason text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: orders_order_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.orders ALTER COLUMN order_number ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.orders_order_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pending_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pending_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    product_id uuid,
    name text,
    qty integer NOT NULL,
    price numeric(12,2),
    held_qty integer DEFAULT 0 NOT NULL,
    CONSTRAINT pending_order_items_held_qty_check CHECK ((held_qty >= 0)),
    CONSTRAINT pending_order_items_named_check CHECK (((product_id IS NOT NULL) OR (NULLIF(TRIM(BOTH FROM name), ''::text) IS NOT NULL))),
    CONSTRAINT pending_order_items_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT pending_order_items_qty_check CHECK ((qty > 0))
);


--
-- Name: pending_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid NOT NULL,
    salesperson_id uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- Name: product_owed; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.product_owed WITH (security_invoker='true') AS
 SELECT oi.product_id,
    (sum(oi.pending_qty))::integer AS owed_qty,
    (count(DISTINCT o.customer_id))::integer AS customers_waiting
   FROM (public.order_items oi
     JOIN public.orders o ON ((o.id = oi.order_id)))
  WHERE ((oi.pending_qty > 0) AND (o.cancelled_at IS NULL))
  GROUP BY oi.product_id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    brand text,
    description text,
    image_url text,
    stock_qty integer DEFAULT 0 NOT NULL,
    reorder_level integer DEFAULT 5 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT products_category_check CHECK ((category = ANY (ARRAY['equipment'::text, 'reagent'::text, 'consumable'::text]))),
    CONSTRAINT products_stock_qty_check CHECK ((stock_qty >= 0))
);


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: receipts_receipt_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.receipts ALTER COLUMN receipt_number ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.receipts_receipt_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: refunds_refund_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.refunds ALTER COLUMN refund_number ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.refunds_refund_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stock_in; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_in (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    qty integer NOT NULL,
    supplier text,
    received_at date DEFAULT CURRENT_DATE NOT NULL,
    created_by uuid,
    CONSTRAINT stock_in_qty_check CHECK ((qty > 0))
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    change integer NOT NULL,
    balance_after integer NOT NULL,
    kind text NOT NULL,
    order_id uuid,
    note text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pending_id uuid,
    CONSTRAINT stock_movements_kind_check CHECK ((kind = ANY (ARRAY['opening'::text, 'received'::text, 'sale'::text, 'delivery'::text, 'cancel'::text, 'adjustment'::text, 'return'::text, 'hold'::text, 'release'::text])))
);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_returns order_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_returns
    ADD CONSTRAINT order_returns_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_order_items pending_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_order_items
    ADD CONSTRAINT pending_order_items_pkey PRIMARY KEY (id);


--
-- Name: pending_orders pending_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_orders
    ADD CONSTRAINT pending_orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: stock_in stock_in_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_in
    ADD CONSTRAINT stock_in_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: notifications_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_unread_idx ON public.notifications USING btree (user_id) WHERE (NOT is_read);


--
-- Name: notifications_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_idx ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: order_items_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_order_idx ON public.order_items USING btree (order_id);


--
-- Name: order_items_owed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_owed_idx ON public.order_items USING btree (product_id) WHERE (pending_qty > 0);


--
-- Name: order_items_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_product_idx ON public.order_items USING btree (product_id);


--
-- Name: order_returns_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_returns_order_idx ON public.order_returns USING btree (order_id);


--
-- Name: orders_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_idx ON public.orders USING btree (created_at DESC);


--
-- Name: orders_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_customer_idx ON public.orders USING btree (customer_id, created_at);


--
-- Name: orders_salesperson_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_salesperson_idx ON public.orders USING btree (salesperson_id, created_at);


--
-- Name: payments_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_order_idx ON public.payments USING btree (order_id);


--
-- Name: payments_receipt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_receipt_idx ON public.payments USING btree (receipt_id);


--
-- Name: pending_order_items_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_order_items_pending_idx ON public.pending_order_items USING btree (pending_id);


--
-- Name: pending_order_items_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_order_items_product_idx ON public.pending_order_items USING btree (product_id) WHERE (held_qty > 0);


--
-- Name: profiles_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profiles_username_key ON public.profiles USING btree (lower(username));


--
-- Name: push_subscriptions_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_subscriptions_user_idx ON public.push_subscriptions USING btree (user_id);


--
-- Name: receipts_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipts_created_idx ON public.receipts USING btree (created_at);


--
-- Name: receipts_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipts_customer_idx ON public.receipts USING btree (customer_id, created_at);


--
-- Name: refunds_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refunds_created_idx ON public.refunds USING btree (created_at);


--
-- Name: refunds_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refunds_order_idx ON public.refunds USING btree (order_id);


--
-- Name: stock_in_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_in_product_idx ON public.stock_in USING btree (product_id);


--
-- Name: stock_movements_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_product_idx ON public.stock_movements USING btree (product_id, created_at DESC);


--
-- Name: customer_balances _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.customer_balances WITH (security_invoker='true') AS
 SELECT c.id AS customer_id,
    c.name,
    c.phone,
    c.location,
    count(o.id) FILTER (WHERE (o.cancelled_at IS NULL)) AS orders,
    COALESCE(sum(t.total), (0)::numeric) AS total,
    COALESCE(sum(t.paid), (0)::numeric) AS paid,
    COALESCE(sum(t.balance), (0)::numeric) AS owed,
    COALESCE(sum(t.balance) FILTER (WHERE ((o.due_date < CURRENT_DATE) AND (t.balance > (0)::numeric))), (0)::numeric) AS overdue,
    c.email,
    COALESCE(( SELECT cc.credit
           FROM public.customer_credit cc
          WHERE (cc.customer_id = c.id)), (0)::numeric) AS credit
   FROM ((public.customers c
     LEFT JOIN public.orders o ON ((o.customer_id = c.id)))
     LEFT JOIN public.order_totals t ON ((t.order_id = o.id)))
  GROUP BY c.id;


--
-- Name: notifications push_notification; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER push_notification AFTER INSERT ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.push_notification();


--
-- Name: products trg_guard_products; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_products BEFORE INSERT OR UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.guard_product_changes();


--
-- Name: products trg_log_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_stock AFTER UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.log_stock_change();


--
-- Name: orders trg_snapshot_customer; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_snapshot_customer BEFORE INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.snapshot_order_customer();


--
-- Name: order_items trg_snapshot_product; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_snapshot_product BEFORE INSERT ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.snapshot_item_product();


--
-- Name: company_settings trg_stamp_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_stamp_settings BEFORE UPDATE ON public.company_settings FOR EACH ROW EXECUTE FUNCTION public.stamp_settings();


--
-- Name: stock_in trg_stock_in; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_stock_in AFTER INSERT ON public.stock_in FOR EACH ROW EXECUTE FUNCTION public.apply_stock_in();


--
-- Name: stock_in trg_stock_in_user; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_stock_in_user BEFORE INSERT ON public.stock_in FOR EACH ROW EXECUTE FUNCTION public.set_stock_in_user();


--
-- Name: company_settings company_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.profiles(id);


--
-- Name: notifications notifications_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_returns order_returns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_returns
    ADD CONSTRAINT order_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id);


--
-- Name: order_returns order_returns_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_returns
    ADD CONSTRAINT order_returns_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: order_returns order_returns_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_returns
    ADD CONSTRAINT order_returns_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_cancelled_by_fkey FOREIGN KEY (cancelled_by) REFERENCES public.profiles(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.profiles(id);


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: payments payments_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_id_fkey FOREIGN KEY (receipt_id) REFERENCES public.receipts(id) ON DELETE CASCADE;


--
-- Name: payments payments_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.profiles(id);


--
-- Name: pending_order_items pending_order_items_pending_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_order_items
    ADD CONSTRAINT pending_order_items_pending_id_fkey FOREIGN KEY (pending_id) REFERENCES public.pending_orders(id) ON DELETE CASCADE;


--
-- Name: pending_order_items pending_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_order_items
    ADD CONSTRAINT pending_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: pending_orders pending_orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_orders
    ADD CONSTRAINT pending_orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pending_orders pending_orders_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_orders
    ADD CONSTRAINT pending_orders_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.profiles(id);


--
-- Name: pending_orders pending_orders_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_orders
    ADD CONSTRAINT pending_orders_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.profiles(id);


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: receipts receipts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id);


--
-- Name: receipts receipts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: receipts receipts_reversed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_reversed_by_fkey FOREIGN KEY (reversed_by) REFERENCES public.profiles(id);


--
-- Name: refunds refunds_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id);


--
-- Name: refunds refunds_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: stock_in stock_in_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_in
    ADD CONSTRAINT stock_in_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id);


--
-- Name: stock_in stock_in_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_in
    ADD CONSTRAINT stock_in_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_movements stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(id);


--
-- Name: stock_movements stock_movements_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_pending_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pending_id_fkey FOREIGN KEY (pending_id) REFERENCES public.pending_orders(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: customers add customers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "add customers" ON public.customers FOR INSERT TO authenticated WITH CHECK (public.is_approved());


--
-- Name: products add products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "add products" ON public.products FOR INSERT TO authenticated WITH CHECK (public.is_approved());


--
-- Name: company_settings admins edit settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins edit settings" ON public.company_settings FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());


--
-- Name: company_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.company_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: products delete products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "delete products" ON public.products FOR DELETE TO authenticated USING (public.is_admin());


--
-- Name: customers edit customers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "edit customers" ON public.customers FOR UPDATE TO authenticated USING (public.is_approved()) WITH CHECK (public.is_approved());


--
-- Name: products edit products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "edit products" ON public.products FOR UPDATE TO authenticated USING (public.is_approved()) WITH CHECK (public.is_approved());


--
-- Name: login_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications mark own read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "mark own read" ON public.notifications FOR UPDATE TO authenticated USING ((user_id = auth.uid()));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: order_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions own devices; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own devices" ON public.push_subscriptions FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: notifications own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own notifications" ON public.notifications FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

--
-- Name: pending_order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pending_order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: pending_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pending_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: customers read customers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read customers" ON public.customers FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: order_items read order items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read order items" ON public.order_items FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: orders read orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read orders" ON public.orders FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: payments read payments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read payments" ON public.payments FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: pending_order_items read pending order items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read pending order items" ON public.pending_order_items FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: pending_orders read pending orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read pending orders" ON public.pending_orders FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: products read products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read products" ON public.products FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: profiles read profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read profiles" ON public.profiles FOR SELECT TO authenticated USING (((id = auth.uid()) OR public.is_approved()));


--
-- Name: receipts read receipts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read receipts" ON public.receipts FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: refunds read refunds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read refunds" ON public.refunds FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: order_returns read returns; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read returns" ON public.order_returns FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: company_settings read settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read settings" ON public.company_settings FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: stock_in read stock in; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read stock in" ON public.stock_in FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: stock_movements read stock movements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "read stock movements" ON public.stock_movements FOR SELECT TO authenticated USING (public.is_approved());


--
-- Name: receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_in record stock in; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "record stock in" ON public.stock_in FOR INSERT TO authenticated WITH CHECK (public.is_approved());


--
-- Name: refunds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.refunds ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions remove own devices; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "remove own devices" ON public.push_subscriptions FOR DELETE TO authenticated USING ((user_id = auth.uid()));


--
-- Name: stock_in; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_in ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: FUNCTION adjust_stock(p_product_id uuid, p_change integer, p_reason text, p_note text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.adjust_stock(p_product_id uuid, p_change integer, p_reason text, p_note text) TO anon;
GRANT ALL ON FUNCTION public.adjust_stock(p_product_id uuid, p_change integer, p_reason text, p_note text) TO authenticated;
GRANT ALL ON FUNCTION public.adjust_stock(p_product_id uuid, p_change integer, p_reason text, p_note text) TO service_role;


--
-- Name: FUNCTION allocate_credit(p_customer uuid, p_only_order uuid); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.allocate_credit(p_customer uuid, p_only_order uuid) FROM PUBLIC;
GRANT ALL ON FUNCTION public.allocate_credit(p_customer uuid, p_only_order uuid) TO service_role;


--
-- Name: FUNCTION apply_customer_credit(p_customer_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.apply_customer_credit(p_customer_id uuid) TO anon;
GRANT ALL ON FUNCTION public.apply_customer_credit(p_customer_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.apply_customer_credit(p_customer_id uuid) TO service_role;


--
-- Name: FUNCTION apply_stock_in(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.apply_stock_in() TO anon;
GRANT ALL ON FUNCTION public.apply_stock_in() TO authenticated;
GRANT ALL ON FUNCTION public.apply_stock_in() TO service_role;


--
-- Name: FUNCTION cancel_order(p_order_id uuid, p_reason text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.cancel_order(p_order_id uuid, p_reason text) TO anon;
GRANT ALL ON FUNCTION public.cancel_order(p_order_id uuid, p_reason text) TO authenticated;
GRANT ALL ON FUNCTION public.cancel_order(p_order_id uuid, p_reason text) TO service_role;


--
-- Name: FUNCTION check_order_lines(p_items jsonb, p_prices_required boolean); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.check_order_lines(p_items jsonb, p_prices_required boolean) TO anon;
GRANT ALL ON FUNCTION public.check_order_lines(p_items jsonb, p_prices_required boolean) TO authenticated;
GRANT ALL ON FUNCTION public.check_order_lines(p_items jsonb, p_prices_required boolean) TO service_role;


--
-- Name: FUNCTION create_opening_balance(p_customer_id uuid, p_amount numeric, p_as_of date, p_note text, p_due_date date); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.create_opening_balance(p_customer_id uuid, p_amount numeric, p_as_of date, p_note text, p_due_date date) TO anon;
GRANT ALL ON FUNCTION public.create_opening_balance(p_customer_id uuid, p_amount numeric, p_as_of date, p_note text, p_due_date date) TO authenticated;
GRANT ALL ON FUNCTION public.create_opening_balance(p_customer_id uuid, p_amount numeric, p_as_of date, p_note text, p_due_date date) TO service_role;


--
-- Name: FUNCTION create_order(p_customer_id uuid, p_items jsonb, p_notes text, p_amount_paid numeric, p_method text, p_due_date date, p_use_credit boolean, p_pending_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.create_order(p_customer_id uuid, p_items jsonb, p_notes text, p_amount_paid numeric, p_method text, p_due_date date, p_use_credit boolean, p_pending_id uuid) TO anon;
GRANT ALL ON FUNCTION public.create_order(p_customer_id uuid, p_items jsonb, p_notes text, p_amount_paid numeric, p_method text, p_due_date date, p_use_credit boolean, p_pending_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.create_order(p_customer_id uuid, p_items jsonb, p_notes text, p_amount_paid numeric, p_method text, p_due_date date, p_use_credit boolean, p_pending_id uuid) TO service_role;


--
-- Name: FUNCTION customer_credit_amount(p_customer uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.customer_credit_amount(p_customer uuid) TO anon;
GRANT ALL ON FUNCTION public.customer_credit_amount(p_customer uuid) TO authenticated;
GRANT ALL ON FUNCTION public.customer_credit_amount(p_customer uuid) TO service_role;


--
-- Name: FUNCTION customer_owed(p_customer uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.customer_owed(p_customer uuid) TO anon;
GRANT ALL ON FUNCTION public.customer_owed(p_customer uuid) TO authenticated;
GRANT ALL ON FUNCTION public.customer_owed(p_customer uuid) TO service_role;


--
-- Name: FUNCTION dashboard_stats(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.dashboard_stats() TO anon;
GRANT ALL ON FUNCTION public.dashboard_stats() TO authenticated;
GRANT ALL ON FUNCTION public.dashboard_stats() TO service_role;


--
-- Name: FUNCTION delete_pending_order(p_pending_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.delete_pending_order(p_pending_id uuid) TO anon;
GRANT ALL ON FUNCTION public.delete_pending_order(p_pending_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.delete_pending_order(p_pending_id uuid) TO service_role;


--
-- Name: FUNCTION email_for_login(p_username text, p_password text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.email_for_login(p_username text, p_password text) TO anon;
GRANT ALL ON FUNCTION public.email_for_login(p_username text, p_password text) TO authenticated;
GRANT ALL ON FUNCTION public.email_for_login(p_username text, p_password text) TO service_role;


--
-- Name: FUNCTION guard_product_changes(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.guard_product_changes() TO anon;
GRANT ALL ON FUNCTION public.guard_product_changes() TO authenticated;
GRANT ALL ON FUNCTION public.guard_product_changes() TO service_role;


--
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.handle_new_user() TO anon;
GRANT ALL ON FUNCTION public.handle_new_user() TO authenticated;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- Name: FUNCTION is_admin(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.is_admin() TO anon;
GRANT ALL ON FUNCTION public.is_admin() TO authenticated;
GRANT ALL ON FUNCTION public.is_admin() TO service_role;


--
-- Name: FUNCTION is_approved(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.is_approved() TO anon;
GRANT ALL ON FUNCTION public.is_approved() TO authenticated;
GRANT ALL ON FUNCTION public.is_approved() TO service_role;


--
-- Name: FUNCTION last_prices(p_customer_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.last_prices(p_customer_id uuid) TO anon;
GRANT ALL ON FUNCTION public.last_prices(p_customer_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.last_prices(p_customer_id uuid) TO service_role;


--
-- Name: FUNCTION log_stock_change(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.log_stock_change() TO anon;
GRANT ALL ON FUNCTION public.log_stock_change() TO authenticated;
GRANT ALL ON FUNCTION public.log_stock_change() TO service_role;


--
-- Name: FUNCTION mark_delivered(p_item_id uuid, p_qty integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.mark_delivered(p_item_id uuid, p_qty integer) TO anon;
GRANT ALL ON FUNCTION public.mark_delivered(p_item_id uuid, p_qty integer) TO authenticated;
GRANT ALL ON FUNCTION public.mark_delivered(p_item_id uuid, p_qty integer) TO service_role;


--
-- Name: FUNCTION my_stats(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.my_stats() TO anon;
GRANT ALL ON FUNCTION public.my_stats() TO authenticated;
GRANT ALL ON FUNCTION public.my_stats() TO service_role;


--
-- Name: FUNCTION pay_oldest_orders(p_receipt uuid, p_customer uuid, p_amount numeric, p_method text, p_note text, p_skip uuid); Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON FUNCTION public.pay_oldest_orders(p_receipt uuid, p_customer uuid, p_amount numeric, p_method text, p_note text, p_skip uuid) FROM PUBLIC;
GRANT ALL ON FUNCTION public.pay_oldest_orders(p_receipt uuid, p_customer uuid, p_amount numeric, p_method text, p_note text, p_skip uuid) TO service_role;


--
-- Name: FUNCTION push_notification(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.push_notification() TO anon;
GRANT ALL ON FUNCTION public.push_notification() TO authenticated;
GRANT ALL ON FUNCTION public.push_notification() TO service_role;


--
-- Name: FUNCTION record_customer_payment(p_customer_id uuid, p_amount numeric, p_method text, p_note text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.record_customer_payment(p_customer_id uuid, p_amount numeric, p_method text, p_note text) TO anon;
GRANT ALL ON FUNCTION public.record_customer_payment(p_customer_id uuid, p_amount numeric, p_method text, p_note text) TO authenticated;
GRANT ALL ON FUNCTION public.record_customer_payment(p_customer_id uuid, p_amount numeric, p_method text, p_note text) TO service_role;


--
-- Name: FUNCTION record_order_payment(p_order_id uuid, p_amount numeric, p_method text, p_note text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.record_order_payment(p_order_id uuid, p_amount numeric, p_method text, p_note text) TO anon;
GRANT ALL ON FUNCTION public.record_order_payment(p_order_id uuid, p_amount numeric, p_method text, p_note text) TO authenticated;
GRANT ALL ON FUNCTION public.record_order_payment(p_order_id uuid, p_amount numeric, p_method text, p_note text) TO service_role;


--
-- Name: FUNCTION return_items(p_order_id uuid, p_items jsonb, p_reason text, p_restock boolean, p_refund_method text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.return_items(p_order_id uuid, p_items jsonb, p_reason text, p_restock boolean, p_refund_method text) TO anon;
GRANT ALL ON FUNCTION public.return_items(p_order_id uuid, p_items jsonb, p_reason text, p_restock boolean, p_refund_method text) TO authenticated;
GRANT ALL ON FUNCTION public.return_items(p_order_id uuid, p_items jsonb, p_reason text, p_restock boolean, p_refund_method text) TO service_role;


--
-- Name: FUNCTION reverse_payment(p_payment_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.reverse_payment(p_payment_id uuid) TO anon;
GRANT ALL ON FUNCTION public.reverse_payment(p_payment_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.reverse_payment(p_payment_id uuid) TO service_role;


--
-- Name: FUNCTION reverse_receipt(p_receipt_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.reverse_receipt(p_receipt_id uuid) TO anon;
GRANT ALL ON FUNCTION public.reverse_receipt(p_receipt_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.reverse_receipt(p_receipt_id uuid) TO service_role;


--
-- Name: FUNCTION sales_by_day(p_days integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.sales_by_day(p_days integer) TO anon;
GRANT ALL ON FUNCTION public.sales_by_day(p_days integer) TO authenticated;
GRANT ALL ON FUNCTION public.sales_by_day(p_days integer) TO service_role;


--
-- Name: FUNCTION save_pending_order(p_customer_id uuid, p_items jsonb, p_notes text, p_pending_id uuid); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.save_pending_order(p_customer_id uuid, p_items jsonb, p_notes text, p_pending_id uuid) TO anon;
GRANT ALL ON FUNCTION public.save_pending_order(p_customer_id uuid, p_items jsonb, p_notes text, p_pending_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.save_pending_order(p_customer_id uuid, p_items jsonb, p_notes text, p_pending_id uuid) TO service_role;


--
-- Name: FUNCTION save_push_subscription(p_endpoint text, p_p256dh text, p_auth text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text) TO anon;
GRANT ALL ON FUNCTION public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text) TO authenticated;
GRANT ALL ON FUNCTION public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text) TO service_role;


--
-- Name: FUNCTION set_move(p_kind text, p_order uuid, p_note text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_move(p_kind text, p_order uuid, p_note text) TO anon;
GRANT ALL ON FUNCTION public.set_move(p_kind text, p_order uuid, p_note text) TO authenticated;
GRANT ALL ON FUNCTION public.set_move(p_kind text, p_order uuid, p_note text) TO service_role;


--
-- Name: FUNCTION set_move_pending(p_kind text, p_pending uuid, p_note text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_move_pending(p_kind text, p_pending uuid, p_note text) TO anon;
GRANT ALL ON FUNCTION public.set_move_pending(p_kind text, p_pending uuid, p_note text) TO authenticated;
GRANT ALL ON FUNCTION public.set_move_pending(p_kind text, p_pending uuid, p_note text) TO service_role;


--
-- Name: FUNCTION set_my_name(p_name text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_my_name(p_name text) TO anon;
GRANT ALL ON FUNCTION public.set_my_name(p_name text) TO authenticated;
GRANT ALL ON FUNCTION public.set_my_name(p_name text) TO service_role;


--
-- Name: FUNCTION set_my_username(p_username text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_my_username(p_username text) TO anon;
GRANT ALL ON FUNCTION public.set_my_username(p_username text) TO authenticated;
GRANT ALL ON FUNCTION public.set_my_username(p_username text) TO service_role;


--
-- Name: FUNCTION set_stock_in_user(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_stock_in_user() TO anon;
GRANT ALL ON FUNCTION public.set_stock_in_user() TO authenticated;
GRANT ALL ON FUNCTION public.set_stock_in_user() TO service_role;


--
-- Name: FUNCTION set_user_name(p_user uuid, p_name text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_user_name(p_user uuid, p_name text) TO anon;
GRANT ALL ON FUNCTION public.set_user_name(p_user uuid, p_name text) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_name(p_user uuid, p_name text) TO service_role;


--
-- Name: FUNCTION set_user_role(p_user uuid, p_role text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_user_role(p_user uuid, p_role text) TO anon;
GRANT ALL ON FUNCTION public.set_user_role(p_user uuid, p_role text) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_role(p_user uuid, p_role text) TO service_role;


--
-- Name: FUNCTION set_user_status(p_user uuid, p_status text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_user_status(p_user uuid, p_status text) TO anon;
GRANT ALL ON FUNCTION public.set_user_status(p_user uuid, p_status text) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_status(p_user uuid, p_status text) TO service_role;


--
-- Name: FUNCTION set_user_username(p_user uuid, p_username text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.set_user_username(p_user uuid, p_username text) TO anon;
GRANT ALL ON FUNCTION public.set_user_username(p_user uuid, p_username text) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_username(p_user uuid, p_username text) TO service_role;


--
-- Name: FUNCTION snapshot_item_product(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.snapshot_item_product() TO anon;
GRANT ALL ON FUNCTION public.snapshot_item_product() TO authenticated;
GRANT ALL ON FUNCTION public.snapshot_item_product() TO service_role;


--
-- Name: FUNCTION snapshot_order_customer(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.snapshot_order_customer() TO anon;
GRANT ALL ON FUNCTION public.snapshot_order_customer() TO authenticated;
GRANT ALL ON FUNCTION public.snapshot_order_customer() TO service_role;


--
-- Name: FUNCTION stamp_settings(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.stamp_settings() TO anon;
GRANT ALL ON FUNCTION public.stamp_settings() TO authenticated;
GRANT ALL ON FUNCTION public.stamp_settings() TO service_role;


--
-- Name: FUNCTION top_products(p_limit integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.top_products(p_limit integer) TO anon;
GRANT ALL ON FUNCTION public.top_products(p_limit integer) TO authenticated;
GRANT ALL ON FUNCTION public.top_products(p_limit integer) TO service_role;


--
-- Name: FUNCTION top_salespeople(p_limit integer); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.top_salespeople(p_limit integer) TO anon;
GRANT ALL ON FUNCTION public.top_salespeople(p_limit integer) TO authenticated;
GRANT ALL ON FUNCTION public.top_salespeople(p_limit integer) TO service_role;


--
-- Name: FUNCTION username_taken(p_username text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.username_taken(p_username text) TO anon;
GRANT ALL ON FUNCTION public.username_taken(p_username text) TO authenticated;
GRANT ALL ON FUNCTION public.username_taken(p_username text) TO service_role;


--
-- Name: FUNCTION valid_username(p_username text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.valid_username(p_username text) TO anon;
GRANT ALL ON FUNCTION public.valid_username(p_username text) TO authenticated;
GRANT ALL ON FUNCTION public.valid_username(p_username text) TO service_role;


--
-- Name: TABLE company_settings; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.company_settings TO anon;
GRANT ALL ON TABLE public.company_settings TO authenticated;
GRANT ALL ON TABLE public.company_settings TO service_role;


--
-- Name: TABLE customer_balances; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.customer_balances TO anon;
GRANT ALL ON TABLE public.customer_balances TO authenticated;
GRANT ALL ON TABLE public.customer_balances TO service_role;


--
-- Name: TABLE payments; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.payments TO anon;
GRANT ALL ON TABLE public.payments TO authenticated;
GRANT ALL ON TABLE public.payments TO service_role;


--
-- Name: TABLE receipts; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.receipts TO anon;
GRANT ALL ON TABLE public.receipts TO authenticated;
GRANT ALL ON TABLE public.receipts TO service_role;


--
-- Name: TABLE customer_credit; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.customer_credit TO anon;
GRANT ALL ON TABLE public.customer_credit TO authenticated;
GRANT ALL ON TABLE public.customer_credit TO service_role;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.customers TO anon;
GRANT ALL ON TABLE public.customers TO authenticated;
GRANT ALL ON TABLE public.customers TO service_role;


--
-- Name: TABLE login_attempts; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.login_attempts TO anon;
GRANT ALL ON TABLE public.login_attempts TO authenticated;
GRANT ALL ON TABLE public.login_attempts TO service_role;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.notifications TO anon;
GRANT ALL ON TABLE public.notifications TO authenticated;
GRANT ALL ON TABLE public.notifications TO service_role;


--
-- Name: TABLE order_items; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.order_items TO anon;
GRANT ALL ON TABLE public.order_items TO authenticated;
GRANT ALL ON TABLE public.order_items TO service_role;


--
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.orders TO anon;
GRANT ALL ON TABLE public.orders TO authenticated;
GRANT ALL ON TABLE public.orders TO service_role;


--
-- Name: TABLE refunds; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.refunds TO anon;
GRANT ALL ON TABLE public.refunds TO authenticated;
GRANT ALL ON TABLE public.refunds TO service_role;


--
-- Name: TABLE order_totals; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.order_totals TO anon;
GRANT ALL ON TABLE public.order_totals TO authenticated;
GRANT ALL ON TABLE public.order_totals TO service_role;


--
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;
GRANT ALL ON TABLE public.profiles TO service_role;


--
-- Name: TABLE order_list; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.order_list TO anon;
GRANT ALL ON TABLE public.order_list TO authenticated;
GRANT ALL ON TABLE public.order_list TO service_role;


--
-- Name: TABLE order_returns; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.order_returns TO anon;
GRANT ALL ON TABLE public.order_returns TO authenticated;
GRANT ALL ON TABLE public.order_returns TO service_role;


--
-- Name: SEQUENCE orders_order_number_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.orders_order_number_seq TO anon;
GRANT ALL ON SEQUENCE public.orders_order_number_seq TO authenticated;
GRANT ALL ON SEQUENCE public.orders_order_number_seq TO service_role;


--
-- Name: TABLE pending_order_items; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.pending_order_items TO anon;
GRANT ALL ON TABLE public.pending_order_items TO authenticated;
GRANT ALL ON TABLE public.pending_order_items TO service_role;


--
-- Name: TABLE pending_orders; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.pending_orders TO anon;
GRANT ALL ON TABLE public.pending_orders TO authenticated;
GRANT ALL ON TABLE public.pending_orders TO service_role;


--
-- Name: TABLE product_owed; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.product_owed TO anon;
GRANT ALL ON TABLE public.product_owed TO authenticated;
GRANT ALL ON TABLE public.product_owed TO service_role;


--
-- Name: TABLE products; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.products TO anon;
GRANT ALL ON TABLE public.products TO authenticated;
GRANT ALL ON TABLE public.products TO service_role;


--
-- Name: TABLE push_subscriptions; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.push_subscriptions TO anon;
GRANT ALL ON TABLE public.push_subscriptions TO authenticated;
GRANT ALL ON TABLE public.push_subscriptions TO service_role;


--
-- Name: SEQUENCE receipts_receipt_number_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.receipts_receipt_number_seq TO anon;
GRANT ALL ON SEQUENCE public.receipts_receipt_number_seq TO authenticated;
GRANT ALL ON SEQUENCE public.receipts_receipt_number_seq TO service_role;


--
-- Name: SEQUENCE refunds_refund_number_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.refunds_refund_number_seq TO anon;
GRANT ALL ON SEQUENCE public.refunds_refund_number_seq TO authenticated;
GRANT ALL ON SEQUENCE public.refunds_refund_number_seq TO service_role;


--
-- Name: TABLE stock_in; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.stock_in TO anon;
GRANT ALL ON TABLE public.stock_in TO authenticated;
GRANT ALL ON TABLE public.stock_in TO service_role;


--
-- Name: TABLE stock_movements; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON TABLE public.stock_movements TO anon;
GRANT ALL ON TABLE public.stock_movements TO authenticated;
GRANT ALL ON TABLE public.stock_movements TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--



--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: -
--



--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--



--
-- PostgreSQL database dump complete
--


