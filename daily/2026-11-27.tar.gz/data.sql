--
-- PostgreSQL database dump
--


-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.12 (Ubuntu 17.12-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, full_name, role, created_at, status, username) FROM stdin;
a6271f16-534a-4325-aee1-5ed0ab3eb261	Agyemang Casper	admin	2026-10-09 10:06:17.85286+00	approved	palatipus
34cb4aa6-890b-4397-bf22-95f48620affa	Sylvester Kuffour Paul	admin	2026-10-09 10:18:41.22666+00	approved	sly
82735742-c8fd-4042-b60f-67a9fca0d0ab	Kelvin Osei gyamfi kwaku	admin	2026-10-15 16:14:17.390092+00	approved	kelvin
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_settings (id, data, updated_by, updated_at) FROM stdin;
1	{"bank": {"name": "CAL BANK", "account": "1400004948868", "merchantNo": "0598591194", "accountName": "WORKING FOR GOD VENTURES"}, "name": "WORKING FOR GOD VENTURES", "email": "oseigyamfikelvinkwaku@gmail.com", "phone": "0549576787", "terms": ["Payment shall be made in accordance with the agreed terms. Cash customers are required to pay immediately unless otherwise agreed in writing. For credit customers, payment is due on or before the agreed due date.", "Customers are requested to inspect all goods upon delivery. Any shortages, damages or discrepancies should be reported within 12 hours of receipt.", "Please quote the invoice number in all payments and correspondence relating to this transaction. This invoice serves as evidence of the transaction and should be retained for your records.", "When mobile money, bank transfer or any other payment is made, please send a screenshot or take a picture of the slip and send it to this WhatsApp number 0549576787."], "address": ["Behind Roman Catholic Church, Bantama.", "Adjacent Atwima Kwawoma Rural Bank Ltd", "Closer to Race Course"], "tagline": "Mindray specialists  |  Lab equipment, reagents and training", "whatsapp": "0549576787", "defaultDueDays": null}	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:49:46.364673+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, email, location, created_at) FROM stdin;
258d7a7d-9240-4d4e-9204-2a31ea55792c	Sonoscan	\N	\N	\N	2026-10-15 13:55:39.263286+00
b5cdacf1-4a01-4164-bf28-6e3045fd1988	LEGACY HOSPITAL	\N	\N	\N	2026-10-19 08:48:38.269402+00
bf086b6d-d8ef-448e-981b-a3e3a25ed86b	Anita	\N	\N	\N	2026-10-19 09:47:16.733332+00
0110da44-7098-43e8-9695-0b5e9edcdbe1	Amedilab Health Services	\N	\N	\N	2026-10-22 10:36:44.788842+00
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_attempts (username, attempted_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_id, salesperson_id, notes, created_at, previous_balance, due_date, cancelled_at, cancelled_by, cancel_reason, customer_name, customer_phone, customer_location, opening_amount) FROM stdin;
b8dc1b57-18b7-4f58-a906-a6f699a11711	1	bf086b6d-d8ef-448e-981b-a3e3a25ed86b	34cb4aa6-890b-4397-bf22-95f48620affa	\N	2026-10-19 09:47:55.885325+00	0.00	\N	\N	\N	\N	Anita	\N	\N	0.00
a7444737-9725-4c82-a742-028e54a28d9c	2	0110da44-7098-43e8-9695-0b5e9edcdbe1	34cb4aa6-890b-4397-bf22-95f48620affa	\N	2026-10-22 10:40:19.005624+00	0.00	\N	\N	\N	\N	Amedilab Health Services	\N	\N	0.00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, message, order_id, is_read, created_at, link) FROM stdin;
ddb22b45-52b9-4c4a-93a8-6a1b1cad1d28	a6271f16-534a-4325-aee1-5ed0ab3eb261	EDTA Tubes is running low: 4 left	\N	t	2026-10-27 10:53:44.746208+00	/inventory?product=613b356c-997c-425c-98f3-876bb2203c6a
35891203-ddb1-42a2-a50d-e49d71c88ea1	a6271f16-534a-4325-aee1-5ed0ab3eb261	Alt is out of stock	\N	t	2026-10-27 11:08:10.948052+00	/inventory?product=ad538600-13a1-417b-93d5-18a7d808d596
e3d463fa-c520-4aec-91ef-382ff709d14d	a6271f16-534a-4325-aee1-5ed0ab3eb261	Kelvin Osei gyamfi kwaku signed up and is waiting for approval	\N	t	2026-10-15 16:14:17.390092+00	\N
57ca2276-7318-4ceb-9f94-f75b8881bcb8	34cb4aa6-890b-4397-bf22-95f48620affa	Kelvin Osei gyamfi kwaku signed up and is waiting for approval	\N	t	2026-10-15 16:14:17.390092+00	\N
4219aee0-e3bd-4d1e-9283-fa8ad22cda73	82735742-c8fd-4042-b60f-67a9fca0d0ab	Diff Lyse is running low: 5 left	\N	f	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
1fb181b8-b3e3-4663-bea9-a5af2590f795	a6271f16-534a-4325-aee1-5ed0ab3eb261	Diff Lyse is running low: 5 left	\N	t	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
b23e20ae-365a-4069-90f0-7a06477a43ff	a6271f16-534a-4325-aee1-5ed0ab3eb261	Test notification: you can ignore this	\N	t	2026-10-16 14:58:42.94597+00	\N
00a0193a-c097-4ce0-ba45-47b34fb6e7c1	34cb4aa6-890b-4397-bf22-95f48620affa	Diff Lyse is running low: 5 left	\N	t	2026-10-16 13:41:24.978977+00	/inventory?product=90cdf544-bf74-4d7c-9cef-c2e3148c29b2
5a908522-9442-4d32-bee5-46cf982bac4c	a6271f16-534a-4325-aee1-5ed0ab3eb261	Test notification: you can ignore this	\N	t	2026-10-16 15:00:17.696605+00	\N
c1076157-7f3f-4c3a-aa60-9ad91113e30c	a6271f16-534a-4325-aee1-5ed0ab3eb261	Test notification: you can ignore this	\N	t	2026-10-16 15:00:28.484751+00	\N
f1aa73f4-a432-4ef4-871a-d0db49c2bc52	82735742-c8fd-4042-b60f-67a9fca0d0ab	New order by Sylvester Kuffour Paul for Anita	b8dc1b57-18b7-4f58-a906-a6f699a11711	f	2026-10-19 09:47:55.885325+00	\N
c651f08e-6cd7-437c-a468-a2ba6852d149	34cb4aa6-890b-4397-bf22-95f48620affa	Centrifuge(6 Buckets) is out of stock	\N	f	2026-10-19 13:30:58.14399+00	/inventory?product=0a2d780b-6404-4826-a300-d6c89964ae40
dc3d3c81-53c8-4710-9e3e-dc0445d4c549	82735742-c8fd-4042-b60f-67a9fca0d0ab	Centrifuge(6 Buckets) is out of stock	\N	f	2026-10-19 13:30:58.14399+00	/inventory?product=0a2d780b-6404-4826-a300-d6c89964ae40
4df6d1de-c777-4354-898f-64f68e82f506	82735742-c8fd-4042-b60f-67a9fca0d0ab	Microscope is running low: 1 left	\N	f	2026-10-19 13:32:13.727513+00	/inventory?product=55170fd5-00ce-4241-9620-ee6dced18987
1b60c3c1-795c-42f3-9474-6114fcf68451	a6271f16-534a-4325-aee1-5ed0ab3eb261	Sylvester Kuffour Paul saved a pending order for Sonoscan: 1 price needed	\N	t	2026-10-19 09:47:07.157806+00	/orders/new?pending=87139906-c17e-49d6-9879-c6d400fa544d
5da84368-858f-42e4-9ad8-1308b8aabc5d	a6271f16-534a-4325-aee1-5ed0ab3eb261	New order by Sylvester Kuffour Paul for Anita	b8dc1b57-18b7-4f58-a906-a6f699a11711	t	2026-10-19 09:47:55.885325+00	\N
f8e017e0-ead2-4752-8997-ca990db72972	a6271f16-534a-4325-aee1-5ed0ab3eb261	Centrifuge(6 Buckets) is out of stock	\N	t	2026-10-19 13:30:58.14399+00	/inventory?product=0a2d780b-6404-4826-a300-d6c89964ae40
dab715e8-d3d1-4f06-8f59-c930cc358c2d	a6271f16-534a-4325-aee1-5ed0ab3eb261	Microscope is running low: 1 left	\N	t	2026-10-19 13:32:13.727513+00	/inventory?product=55170fd5-00ce-4241-9620-ee6dced18987
63f0d54d-603f-4b7f-a17e-14f8b0cb9d73	34cb4aa6-890b-4397-bf22-95f48620affa	Microscope is running low: 1 left	\N	t	2026-10-19 13:32:13.727513+00	/inventory?product=55170fd5-00ce-4241-9620-ee6dced18987
e6bd6059-97f9-408e-ac67-426b7034a41a	34cb4aa6-890b-4397-bf22-95f48620affa	TSH is running low: 5 left	\N	f	2026-10-20 15:14:27.141511+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
7fb725bd-b0d9-415e-81fd-3cd6dc228a8c	82735742-c8fd-4042-b60f-67a9fca0d0ab	TSH is running low: 5 left	\N	f	2026-10-20 15:14:27.141511+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
b17ebaf2-25dc-4a79-ac10-9174f4d0107d	82735742-c8fd-4042-b60f-67a9fca0d0ab	Sylvester Kuffour Paul saved a pending order for Sonoscan: 1 price needed	\N	t	2026-10-19 09:47:07.157806+00	/orders/new?pending=87139906-c17e-49d6-9879-c6d400fa544d
276cf29b-c321-4829-88fe-ad08d2b53d54	34cb4aa6-890b-4397-bf22-95f48620affa	Kelvin Osei gyamfi kwaku deleted your pending order for Sonoscan	\N	f	2026-10-22 05:15:34.939482+00	/orders
e78270d3-3382-4c95-8c7f-a7ce48945db9	82735742-c8fd-4042-b60f-67a9fca0d0ab	New order by Sylvester Kuffour Paul for Amedilab Health Services (balance GHS 7190.00)	a7444737-9725-4c82-a742-028e54a28d9c	t	2026-10-22 10:40:19.005624+00	\N
d98f16e4-88b2-49e0-b060-5d22218841eb	a6271f16-534a-4325-aee1-5ed0ab3eb261	TSH is running low: 5 left	\N	t	2026-10-20 15:14:27.141511+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
db508e19-257d-41e8-a59b-566ac23ae24a	a6271f16-534a-4325-aee1-5ed0ab3eb261	New order by Sylvester Kuffour Paul for Amedilab Health Services (balance GHS 7190.00)	a7444737-9725-4c82-a742-028e54a28d9c	t	2026-10-22 10:40:19.005624+00	\N
c3a4c79b-9848-4401-be23-4903418f50b6	34cb4aa6-890b-4397-bf22-95f48620affa	EDTA Tubes is running low: 4 left	\N	f	2026-10-27 10:53:44.746208+00	/inventory?product=613b356c-997c-425c-98f3-876bb2203c6a
68fce80c-9e11-4f0d-8cce-c49214e1047c	82735742-c8fd-4042-b60f-67a9fca0d0ab	EDTA Tubes is running low: 4 left	\N	f	2026-10-27 10:53:44.746208+00	/inventory?product=613b356c-997c-425c-98f3-876bb2203c6a
cea1559d-a43e-41b5-97ec-7665963c1d4a	34cb4aa6-890b-4397-bf22-95f48620affa	Alt is out of stock	\N	f	2026-10-27 11:08:10.948052+00	/inventory?product=ad538600-13a1-417b-93d5-18a7d808d596
6fdfaf8b-a260-49e6-982b-804d1194f135	82735742-c8fd-4042-b60f-67a9fca0d0ab	Alt is out of stock	\N	f	2026-10-27 11:08:10.948052+00	/inventory?product=ad538600-13a1-417b-93d5-18a7d808d596
23d19da9-c4da-4c4c-ae9a-74b67380c181	34cb4aa6-890b-4397-bf22-95f48620affa	ST200 is running low: 4 left	\N	f	2026-10-27 15:33:36.032046+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
5381b688-9b6c-4543-86bd-1e15e5b599bf	82735742-c8fd-4042-b60f-67a9fca0d0ab	ST200 is running low: 4 left	\N	f	2026-10-27 15:33:36.032046+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
86cdcaf1-49f8-4e65-a40f-dfc0c09ad0d0	a6271f16-534a-4325-aee1-5ed0ab3eb261	ST200 is running low: 4 left	\N	t	2026-10-27 15:33:36.032046+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
5de92c7d-8e45-41c9-bcfb-2858103f91ce	34cb4aa6-890b-4397-bf22-95f48620affa	FSH is running low: 5 left	\N	f	2026-10-27 16:08:14.582008+00	/inventory?product=4cd01e41-701c-48c4-991e-459cc8e31a3b
97923a38-19e2-4861-9b55-c9410ad653eb	82735742-c8fd-4042-b60f-67a9fca0d0ab	FSH is running low: 5 left	\N	f	2026-10-27 16:08:14.582008+00	/inventory?product=4cd01e41-701c-48c4-991e-459cc8e31a3b
ae07420a-5a53-49ac-a22d-5ca450afd1a5	34cb4aa6-890b-4397-bf22-95f48620affa	Progesterone  is running low: 5 left	\N	f	2026-10-27 16:08:51.548022+00	/inventory?product=5f6badbf-8cf8-4416-9bf4-873503e719c5
1d8b97ab-dfdd-4fff-9764-18df3afc3063	82735742-c8fd-4042-b60f-67a9fca0d0ab	Progesterone  is running low: 5 left	\N	f	2026-10-27 16:08:51.548022+00	/inventory?product=5f6badbf-8cf8-4416-9bf4-873503e719c5
00a34c76-643a-4fd7-b8b5-9a58b0712598	34cb4aa6-890b-4397-bf22-95f48620affa	GGT is running low: 5 left	\N	f	2026-10-28 09:44:35.756137+00	/inventory?product=d6d4fda9-6087-410a-8bc9-0a5622f40e32
2bdd157c-a511-4660-b76b-3aaca26a9c17	82735742-c8fd-4042-b60f-67a9fca0d0ab	GGT is running low: 5 left	\N	f	2026-10-28 09:44:35.756137+00	/inventory?product=d6d4fda9-6087-410a-8bc9-0a5622f40e32
9b089abb-3944-48fa-ac8c-74e019a96d3b	34cb4aa6-890b-4397-bf22-95f48620affa	ALP is running low: 5 left	\N	f	2026-10-28 09:44:55.720707+00	/inventory?product=cf5815de-94e6-426d-8eca-594e2ef0f803
1433c73f-ce73-4f67-87e9-d4434cb1713e	82735742-c8fd-4042-b60f-67a9fca0d0ab	ALP is running low: 5 left	\N	f	2026-10-28 09:44:55.720707+00	/inventory?product=cf5815de-94e6-426d-8eca-594e2ef0f803
8cd0fc81-465e-4c09-bd16-5fc04976f39d	a6271f16-534a-4325-aee1-5ed0ab3eb261	FSH is running low: 5 left	\N	t	2026-10-27 16:08:14.582008+00	/inventory?product=4cd01e41-701c-48c4-991e-459cc8e31a3b
953f1b96-89fd-4673-89f9-e609c56705cf	a6271f16-534a-4325-aee1-5ed0ab3eb261	Progesterone  is running low: 5 left	\N	t	2026-10-27 16:08:51.548022+00	/inventory?product=5f6badbf-8cf8-4416-9bf4-873503e719c5
18d73a4d-4e56-44ab-a91b-115ee3c57272	a6271f16-534a-4325-aee1-5ed0ab3eb261	GGT is running low: 5 left	\N	t	2026-10-28 09:44:35.756137+00	/inventory?product=d6d4fda9-6087-410a-8bc9-0a5622f40e32
eaf368a6-4702-4b44-9fd1-17e1c8d3dde2	a6271f16-534a-4325-aee1-5ed0ab3eb261	ALP is running low: 5 left	\N	t	2026-10-28 09:44:55.720707+00	/inventory?product=cf5815de-94e6-426d-8eca-594e2ef0f803
d31e7a6d-3c7a-4d9e-9d7a-bc407531c3f1	34cb4aa6-890b-4397-bf22-95f48620affa	HDL-C is running low: 5 left	\N	f	2026-11-03 08:28:03.136969+00	/inventory?product=2cf77d43-efc0-4773-9519-610d10df99b7
80c0e9b4-8b7a-46e4-8d2a-52bd77f63f36	82735742-c8fd-4042-b60f-67a9fca0d0ab	HDL-C is running low: 5 left	\N	f	2026-11-03 08:28:03.136969+00	/inventory?product=2cf77d43-efc0-4773-9519-610d10df99b7
cbe7d2bf-0fef-485f-84af-8f1a78bca19b	34cb4aa6-890b-4397-bf22-95f48620affa	HsCRP is running low: 2 left	\N	f	2026-11-03 08:44:57.369715+00	/inventory?product=79d3a498-b877-4953-9d58-d7593e7228b9
07076ead-4c00-49e9-8c92-48c05580c561	82735742-c8fd-4042-b60f-67a9fca0d0ab	HsCRP is running low: 2 left	\N	f	2026-11-03 08:44:57.369715+00	/inventory?product=79d3a498-b877-4953-9d58-d7593e7228b9
9d675783-d00a-4227-b6ed-c834e908ead5	34cb4aa6-890b-4397-bf22-95f48620affa	Urine Container is out of stock	\N	f	2026-11-03 09:37:27.93465+00	/inventory?product=f5cf61f8-72f0-4426-b0b3-2095ee7155b2
259d0a22-2f5c-470d-9a54-e1168cd93f53	82735742-c8fd-4042-b60f-67a9fca0d0ab	Urine Container is out of stock	\N	f	2026-11-03 09:37:27.93465+00	/inventory?product=f5cf61f8-72f0-4426-b0b3-2095ee7155b2
cdc929d6-063f-48b0-a15d-f078cf985cc2	34cb4aa6-890b-4397-bf22-95f48620affa	Hepatitis B is running low: 10 left	\N	f	2026-11-03 09:39:29.338279+00	/inventory?product=6e2e3bf7-34a4-4bfe-b707-1302a5e205ec
815da7f7-8004-4ab9-a72d-553f2e67005b	82735742-c8fd-4042-b60f-67a9fca0d0ab	Hepatitis B is running low: 10 left	\N	f	2026-11-03 09:39:29.338279+00	/inventory?product=6e2e3bf7-34a4-4bfe-b707-1302a5e205ec
90c4087c-9fc8-4450-8d53-c4e07ed667d9	34cb4aa6-890b-4397-bf22-95f48620affa	Combi10 is running low: 4 left	\N	f	2026-11-03 09:40:39.252461+00	/inventory?product=ec733761-dbcb-4ae3-839b-8f759f29057f
a9d9bc13-018f-4afe-9741-3925ee4b18dc	82735742-c8fd-4042-b60f-67a9fca0d0ab	Combi10 is running low: 4 left	\N	f	2026-11-03 09:40:39.252461+00	/inventory?product=ec733761-dbcb-4ae3-839b-8f759f29057f
98530635-60f4-4da2-98c5-3bff79f4df44	34cb4aa6-890b-4397-bf22-95f48620affa	Blue Pipette Tip is out of stock	\N	f	2026-11-03 09:43:49.411433+00	/inventory?product=2589ccdd-7774-4eb6-952f-aff007ddc585
1b09fcb7-b746-44bb-8765-dbeb13efbf82	82735742-c8fd-4042-b60f-67a9fca0d0ab	Blue Pipette Tip is out of stock	\N	f	2026-11-03 09:43:49.411433+00	/inventory?product=2589ccdd-7774-4eb6-952f-aff007ddc585
650d94ce-7589-43ac-a80f-7d147a353ddf	34cb4aa6-890b-4397-bf22-95f48620affa	Yellow Pipette Tips is out of stock	\N	f	2026-11-03 09:44:08.018343+00	/inventory?product=5325af28-0ff3-479d-ba25-2507b2dcb708
a1a0b7e8-9154-41c7-83e6-2303559718d6	82735742-c8fd-4042-b60f-67a9fca0d0ab	Yellow Pipette Tips is out of stock	\N	f	2026-11-03 09:44:08.018343+00	/inventory?product=5325af28-0ff3-479d-ba25-2507b2dcb708
1cab4257-0c7d-4850-9b2b-f7c7e42fb35a	34cb4aa6-890b-4397-bf22-95f48620affa	Prolactin is running low: 5 left	\N	f	2026-11-03 11:58:50.035415+00	/inventory?product=fda6810f-87ff-4863-9c2b-e0213ac55cc8
cf6a2bf6-3642-475f-94f1-d9f7da027022	82735742-c8fd-4042-b60f-67a9fca0d0ab	Prolactin is running low: 5 left	\N	f	2026-11-03 11:58:50.035415+00	/inventory?product=fda6810f-87ff-4863-9c2b-e0213ac55cc8
659fe127-a51a-49c4-a783-8aee33a60c4d	34cb4aa6-890b-4397-bf22-95f48620affa	Thermal Roll(S) is running low: 16 left	\N	f	2026-11-03 14:46:06.856441+00	/inventory?product=f1aabb46-04f7-4c4f-83c0-d532953304a1
d18f8b62-9f60-47f3-8ecd-38188a9f6f37	82735742-c8fd-4042-b60f-67a9fca0d0ab	Thermal Roll(S) is running low: 16 left	\N	f	2026-11-03 14:46:06.856441+00	/inventory?product=f1aabb46-04f7-4c4f-83c0-d532953304a1
419f7127-252f-4782-9804-234d8b9a2626	34cb4aa6-890b-4397-bf22-95f48620affa	Daily Cleaner is out of stock	\N	f	2026-11-03 14:57:12.934088+00	/inventory?product=598eb297-3ff5-47e5-8cb9-5904f6bbf516
4ffd5d34-36c7-47d4-8624-fc1454de4037	82735742-c8fd-4042-b60f-67a9fca0d0ab	Daily Cleaner is out of stock	\N	f	2026-11-03 14:57:12.934088+00	/inventory?product=598eb297-3ff5-47e5-8cb9-5904f6bbf516
eb7f45b3-bd98-4552-badd-41cd5d6f14e8	34cb4aa6-890b-4397-bf22-95f48620affa	Coded lyser is running low: 3 left	\N	f	2026-11-06 17:48:54.403613+00	/inventory?product=aa9ea515-00d3-406b-86ce-e0d78cdbba38
e2acabf5-f789-4f31-923e-181ca0ca7c88	82735742-c8fd-4042-b60f-67a9fca0d0ab	Coded lyser is running low: 3 left	\N	f	2026-11-06 17:48:54.403613+00	/inventory?product=aa9ea515-00d3-406b-86ce-e0d78cdbba38
9571ba60-f450-4cbb-817d-e9b2ed12e41d	34cb4aa6-890b-4397-bf22-95f48620affa	HBA1c is running low: 5 left	\N	f	2026-11-06 17:50:14.194908+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
2292c281-964e-4d80-87e6-d476fa4ee127	82735742-c8fd-4042-b60f-67a9fca0d0ab	HBA1c is running low: 5 left	\N	f	2026-11-06 17:50:14.194908+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
7e62ef7c-6197-4a3a-aead-bb53c83eaceb	34cb4aa6-890b-4397-bf22-95f48620affa	TSH is running low: 4 left	\N	f	2026-11-06 17:54:01.637191+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
1a012263-539c-438c-a6ed-b5307b80e8d5	82735742-c8fd-4042-b60f-67a9fca0d0ab	TSH is running low: 4 left	\N	f	2026-11-06 17:54:01.637191+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
7ef1b378-8270-4baf-ab70-ac2f1bb1b691	34cb4aa6-890b-4397-bf22-95f48620affa	ST200 is running low: 5 left	\N	f	2026-11-06 17:59:47.633478+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
2f559d3b-6d30-4fdf-8568-08dcafe45b42	82735742-c8fd-4042-b60f-67a9fca0d0ab	ST200 is running low: 5 left	\N	f	2026-11-06 17:59:47.633478+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
3f970684-45a1-4325-9e79-a16f27636625	34cb4aa6-890b-4397-bf22-95f48620affa	FT3 is running low: 10 left	\N	f	2026-11-09 13:30:02.926724+00	/inventory?product=62f9f784-9902-45e7-869e-0ce5e8cfdbd2
cdb63a61-fc71-4a38-856b-449f2560ee4a	82735742-c8fd-4042-b60f-67a9fca0d0ab	FT3 is running low: 10 left	\N	f	2026-11-09 13:30:02.926724+00	/inventory?product=62f9f784-9902-45e7-869e-0ce5e8cfdbd2
e538e7f6-39b1-4627-8a45-455d9e64880c	34cb4aa6-890b-4397-bf22-95f48620affa	LH is running low: 4 left	\N	f	2026-11-10 08:23:17.563955+00	/inventory?product=d95e9245-a421-4351-89a2-6c363c15c948
55d6c74a-3c22-4e1e-979e-4c75dc86fd7d	82735742-c8fd-4042-b60f-67a9fca0d0ab	LH is running low: 4 left	\N	f	2026-11-10 08:23:17.563955+00	/inventory?product=d95e9245-a421-4351-89a2-6c363c15c948
935872f3-355c-45b0-a9c5-52b4c13534fc	34cb4aa6-890b-4397-bf22-95f48620affa	Esr tubes is running low: 1 left	\N	f	2026-11-11 03:38:48.202575+00	/inventory?product=d4937cc1-d2c2-488f-bc93-36b8e0186036
400e6958-7f94-47c9-99da-cc8f3dee2579	82735742-c8fd-4042-b60f-67a9fca0d0ab	Esr tubes is running low: 1 left	\N	f	2026-11-11 03:38:48.202575+00	/inventory?product=d4937cc1-d2c2-488f-bc93-36b8e0186036
bb78f939-f1dd-41aa-90ba-e8425adb93da	a6271f16-534a-4325-aee1-5ed0ab3eb261	HDL-C is running low: 5 left	\N	t	2026-11-03 08:28:03.136969+00	/inventory?product=2cf77d43-efc0-4773-9519-610d10df99b7
4d11c347-dbc7-4388-8058-fad6249ae229	a6271f16-534a-4325-aee1-5ed0ab3eb261	HsCRP is running low: 2 left	\N	t	2026-11-03 08:44:57.369715+00	/inventory?product=79d3a498-b877-4953-9d58-d7593e7228b9
149f9f69-783c-4472-a850-b0a9ad78101d	a6271f16-534a-4325-aee1-5ed0ab3eb261	Urine Container is out of stock	\N	t	2026-11-03 09:37:27.93465+00	/inventory?product=f5cf61f8-72f0-4426-b0b3-2095ee7155b2
9be6a817-900f-4978-b344-b9dff9e75d8c	a6271f16-534a-4325-aee1-5ed0ab3eb261	Hepatitis B is running low: 10 left	\N	t	2026-11-03 09:39:29.338279+00	/inventory?product=6e2e3bf7-34a4-4bfe-b707-1302a5e205ec
e9d1c2d5-6374-44dd-91b8-8f9c88bcb86f	a6271f16-534a-4325-aee1-5ed0ab3eb261	Combi10 is running low: 4 left	\N	t	2026-11-03 09:40:39.252461+00	/inventory?product=ec733761-dbcb-4ae3-839b-8f759f29057f
ccbb8c74-2244-40d0-acec-f4a6cf5662f0	a6271f16-534a-4325-aee1-5ed0ab3eb261	Blue Pipette Tip is out of stock	\N	t	2026-11-03 09:43:49.411433+00	/inventory?product=2589ccdd-7774-4eb6-952f-aff007ddc585
62258db0-6c09-4203-8594-f63cdac4fc75	a6271f16-534a-4325-aee1-5ed0ab3eb261	Yellow Pipette Tips is out of stock	\N	t	2026-11-03 09:44:08.018343+00	/inventory?product=5325af28-0ff3-479d-ba25-2507b2dcb708
34e811b3-6e8c-45e0-b2de-ef438b1aa5bf	a6271f16-534a-4325-aee1-5ed0ab3eb261	Prolactin is running low: 5 left	\N	t	2026-11-03 11:58:50.035415+00	/inventory?product=fda6810f-87ff-4863-9c2b-e0213ac55cc8
35bf5115-2d3f-413a-b344-192a52917cf2	a6271f16-534a-4325-aee1-5ed0ab3eb261	Thermal Roll(S) is running low: 16 left	\N	t	2026-11-03 14:46:06.856441+00	/inventory?product=f1aabb46-04f7-4c4f-83c0-d532953304a1
25847a9f-581f-4e56-b787-135f4ff45369	a6271f16-534a-4325-aee1-5ed0ab3eb261	Daily Cleaner is out of stock	\N	t	2026-11-03 14:57:12.934088+00	/inventory?product=598eb297-3ff5-47e5-8cb9-5904f6bbf516
d3eb7db8-30f7-425b-8acc-c3bee8e7c993	a6271f16-534a-4325-aee1-5ed0ab3eb261	Coded lyser is running low: 3 left	\N	t	2026-11-06 17:48:54.403613+00	/inventory?product=aa9ea515-00d3-406b-86ce-e0d78cdbba38
a4ac8efa-55b4-4b72-89d4-717b85376d20	a6271f16-534a-4325-aee1-5ed0ab3eb261	HBA1c is running low: 5 left	\N	t	2026-11-06 17:50:14.194908+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
357ac6b4-0801-4fde-b98d-4431db755472	a6271f16-534a-4325-aee1-5ed0ab3eb261	TSH is running low: 4 left	\N	t	2026-11-06 17:54:01.637191+00	/inventory?product=12524346-ae4c-414d-a09c-d1fd4640cb50
85d4cb7b-6a17-4878-b295-f07083f9d826	a6271f16-534a-4325-aee1-5ed0ab3eb261	ST200 is running low: 5 left	\N	t	2026-11-06 17:59:47.633478+00	/inventory?product=0ded23de-1d23-4279-b783-1e5c5a59ca5d
b3bb7a42-6e89-482d-b1e4-9abb1671dc0d	a6271f16-534a-4325-aee1-5ed0ab3eb261	FT3 is running low: 10 left	\N	t	2026-11-09 13:30:02.926724+00	/inventory?product=62f9f784-9902-45e7-869e-0ce5e8cfdbd2
40c84184-879f-42bb-9d78-459743774edc	a6271f16-534a-4325-aee1-5ed0ab3eb261	LH is running low: 4 left	\N	t	2026-11-10 08:23:17.563955+00	/inventory?product=d95e9245-a421-4351-89a2-6c363c15c948
b8cc2359-ec0c-45ac-8df8-506cd6d08b33	a6271f16-534a-4325-aee1-5ed0ab3eb261	Esr tubes is running low: 1 left	\N	t	2026-11-11 03:38:48.202575+00	/inventory?product=d4937cc1-d2c2-488f-bc93-36b8e0186036
810a2ec6-ed67-4326-b789-02887a6acf65	34cb4aa6-890b-4397-bf22-95f48620affa	Total psa is running low: 3 left	\N	f	2026-11-13 13:58:59.628317+00	/inventory?product=ee10fbe5-4a96-4440-a3fb-b29fa0de930b
dc04d236-7551-43fa-8fb9-aa2b8d33be35	82735742-c8fd-4042-b60f-67a9fca0d0ab	Total psa is running low: 3 left	\N	f	2026-11-13 13:58:59.628317+00	/inventory?product=ee10fbe5-4a96-4440-a3fb-b29fa0de930b
a1ca07b3-2c08-47b9-9f1e-fd62c8524fe0	34cb4aa6-890b-4397-bf22-95f48620affa	TSH is running low: 2 left	\N	f	2026-11-13 13:59:17.034338+00	/inventory?product=bd357ee5-7fff-4f95-8ca9-144fc25b9d4d
f042aa88-6350-415d-b0fb-ee6d5c125f7a	82735742-c8fd-4042-b60f-67a9fca0d0ab	TSH is running low: 2 left	\N	f	2026-11-13 13:59:17.034338+00	/inventory?product=bd357ee5-7fff-4f95-8ca9-144fc25b9d4d
2fa1e846-4536-4aef-a830-f599ffcfcd55	34cb4aa6-890b-4397-bf22-95f48620affa	HBA1c is out of stock	\N	f	2026-11-13 19:01:33.312275+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
6ce8a45e-19a3-48fb-96e0-0f0d8a43a171	82735742-c8fd-4042-b60f-67a9fca0d0ab	HBA1c is out of stock	\N	f	2026-11-13 19:01:33.312275+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
aadc1539-18f1-466f-893c-ff713bc31109	34cb4aa6-890b-4397-bf22-95f48620affa	FSH is running low: 5 left	\N	f	2026-11-13 19:05:13.379989+00	/inventory?product=fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65
90a15558-7799-47d9-b2cd-9a914e5dc09d	82735742-c8fd-4042-b60f-67a9fca0d0ab	FSH is running low: 5 left	\N	f	2026-11-13 19:05:13.379989+00	/inventory?product=fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65
b0c8fe89-599a-43d2-b6c1-fc1be5520855	34cb4aa6-890b-4397-bf22-95f48620affa	Syphilis is out of stock	\N	f	2026-11-16 17:54:26.019448+00	/inventory?product=0f537939-ec3d-4520-8ec6-450b21480858
c95a0050-8a67-4968-b092-42f0e9711230	82735742-c8fd-4042-b60f-67a9fca0d0ab	Syphilis is out of stock	\N	f	2026-11-16 17:54:26.019448+00	/inventory?product=0f537939-ec3d-4520-8ec6-450b21480858
c260918b-16f6-4bcb-95b0-df5700d39222	34cb4aa6-890b-4397-bf22-95f48620affa	Hba1c  is running low: 2 left	\N	f	2026-11-18 07:07:31.021942+00	/inventory?product=12a3cecf-0723-4dac-8edc-c61f04338e8d
71c5e21c-d912-415a-bd4a-6fe660b9b3b0	82735742-c8fd-4042-b60f-67a9fca0d0ab	Hba1c  is running low: 2 left	\N	f	2026-11-18 07:07:31.021942+00	/inventory?product=12a3cecf-0723-4dac-8edc-c61f04338e8d
8b241613-74c5-456f-bfdc-fa0ac7da3926	34cb4aa6-890b-4397-bf22-95f48620affa	Hepatitis C is running low: 10 left	\N	f	2026-11-18 07:10:58.364919+00	/inventory?product=ce41fcc9-e4f2-4e94-b12f-2220c1ee6297
3cd98768-04ac-4dcc-b41a-d8c1ff85e9e4	82735742-c8fd-4042-b60f-67a9fca0d0ab	Hepatitis C is running low: 10 left	\N	f	2026-11-18 07:10:58.364919+00	/inventory?product=ce41fcc9-e4f2-4e94-b12f-2220c1ee6297
2ddc2f8c-8dc5-4516-b4f9-957345633b31	a6271f16-534a-4325-aee1-5ed0ab3eb261	Total psa is running low: 3 left	\N	t	2026-11-13 13:58:59.628317+00	/inventory?product=ee10fbe5-4a96-4440-a3fb-b29fa0de930b
a0ac3d35-232b-4de9-9d28-6c9389c89196	a6271f16-534a-4325-aee1-5ed0ab3eb261	TSH is running low: 2 left	\N	t	2026-11-13 13:59:17.034338+00	/inventory?product=bd357ee5-7fff-4f95-8ca9-144fc25b9d4d
38cc81e9-5aad-48e6-ab43-bc4f7dda958d	a6271f16-534a-4325-aee1-5ed0ab3eb261	HBA1c is out of stock	\N	t	2026-11-13 19:01:33.312275+00	/inventory?product=dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a
47b3f211-0930-41ed-a0f5-0e7e9b87ff6e	a6271f16-534a-4325-aee1-5ed0ab3eb261	FSH is running low: 5 left	\N	t	2026-11-13 19:05:13.379989+00	/inventory?product=fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65
40f5500b-939f-4ce3-bc96-3772d7eab3d7	a6271f16-534a-4325-aee1-5ed0ab3eb261	Syphilis is out of stock	\N	t	2026-11-16 17:54:26.019448+00	/inventory?product=0f537939-ec3d-4520-8ec6-450b21480858
99c5c2a1-9f31-4193-86ce-4418ba35e195	a6271f16-534a-4325-aee1-5ed0ab3eb261	Hba1c  is running low: 2 left	\N	t	2026-11-18 07:07:31.021942+00	/inventory?product=12a3cecf-0723-4dac-8edc-c61f04338e8d
da7851de-e811-4d93-a731-f935a2adfedc	a6271f16-534a-4325-aee1-5ed0ab3eb261	Hepatitis C is running low: 10 left	\N	t	2026-11-18 07:10:58.364919+00	/inventory?product=ce41fcc9-e4f2-4e94-b12f-2220c1ee6297
b468439d-650c-4365-b7d3-45c9d9f3dbbf	a6271f16-534a-4325-aee1-5ed0ab3eb261	G26 is running low: 5 left	\N	f	2026-11-21 13:10:24.633024+00	/inventory?product=9db7aae9-12d8-4716-aff7-0532026f939a
6560b345-00b4-4cf7-9601-f9fa52898ec8	34cb4aa6-890b-4397-bf22-95f48620affa	G26 is running low: 5 left	\N	f	2026-11-21 13:10:24.633024+00	/inventory?product=9db7aae9-12d8-4716-aff7-0532026f939a
bbb465c9-2ca9-4a77-8d5d-36d52aeb7d76	82735742-c8fd-4042-b60f-67a9fca0d0ab	G26 is running low: 5 left	\N	f	2026-11-21 13:10:24.633024+00	/inventory?product=9db7aae9-12d8-4716-aff7-0532026f939a
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, category, brand, description, image_url, stock_qty, reorder_level, is_active, created_at) FROM stdin;
a9061735-ec3b-4533-8124-e44acec27679	MALB	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/eb37311f-6102-498f-acb9-cdf7785def05.jpeg	1	5	t	2026-10-15 10:52:15.857138+00
51291b09-5c9c-4ece-b5ab-caab1507e9e2	CKMB	reagent	Mindray	CK-MB reagent is an in-vitro diagnostic test kit used to quantitatively measure the activity or concentration of Creatine Kinase-MB (CK-MB) in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e164c06c-5d42-4653-a27b-d0db49fe396c.png	0	5	t	2026-10-15 10:25:58.340328+00
9c309e3f-ca58-4ed7-b6f8-1ff19b498864	Glucose	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/3687d599-a3c0-480b-90c7-c669b462d48f.jpeg	7	5	t	2026-10-15 10:33:13.16359+00
c8247369-36e0-4af0-99cc-13be486f3c9d	Creatinine	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/345c7fc7-e835-4aa0-99f9-ea41b02baba3.jpeg	37	5	t	2026-10-15 10:45:29.514277+00
bab661ed-e425-4095-a183-0c8b35a9a73e	Control Level 2	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd342f6a-ec69-4180-aa68-c3c5fdf52b1d.jpeg	17	5	t	2026-10-15 11:05:56.83578+00
e32d59af-01ec-496c-9be5-ae5285d46a1a	LDL-C	reagent	Mindray	LDL cholesterol reagent is a two-part clinical chemistry diagnostic kit used for the direct, quantitative measurement of low-density lipoprotein cholesterol (LDL-C) in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/83e107d1-96c6-41c8-8276-e407d23abb9a.jpeg	1	5	t	2026-10-15 10:28:01.36808+00
427a9551-fb8c-45c7-9076-19c9ee015002	Magnesium	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/295f9d3e-7d85-4230-8819-e9f716a65e70.jpeg	4	5	t	2026-10-15 10:32:06.816804+00
5a58c58c-8ed5-4082-a9e3-3d91b026c57d	Calcium	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0fdada34-3160-42c0-a188-fbcaac990a59.jpeg	1	5	t	2026-10-15 10:39:35.551033+00
171c693e-768a-4e98-9fa7-b78f91a85944	Triglyceride	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1c3bf861-48f5-49b6-adc3-e073bc8d225a.png	16	5	t	2026-10-15 10:48:04.076138+00
ea5ebf85-f433-452c-ba48-3f8c921b68c0	Control Level 1	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/836ae23d-374d-46f5-82b5-9a6391ea666c.jpeg	19	5	t	2026-10-15 11:08:04.639296+00
ead2b374-e435-4025-bead-d804071dda77	AST	reagent	Mindray	Aspartate Aminotransferase (historically known as SGOT), a crucial enzyme biomarker used to evaluate liver function, cardiac injury, and muscle diseases.	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9db64f89-1cd7-45fc-ad63-30ad61413d94.jpeg	22	5	t	2026-10-12 08:28:02.964028+00
ee6fe6e3-87aa-4930-8a88-97f801e23fe0	Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6292a22e-2704-4beb-a6ad-96cb31ee59e7.jpeg	20	5	t	2026-10-15 11:09:41.606059+00
9ff4f240-9f00-460f-87f1-e745c6647e36	ALT	reagent	Mindray	ALT (Alanine Aminotransferase / GPT) reagent is an in vitro diagnostic chemical kit used to measure the activity of the ALT enzyme in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/22b5bcdb-27b8-4824-9673-a35f79076567.jpeg	16	5	t	2026-10-15 10:20:54.41821+00
280a9428-5bc6-41a2-beee-924f8d94d88f	Urea	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f690d882-8cf3-4823-a04d-453d52eb50b1.jpeg	27	5	t	2026-10-15 10:40:47.423101+00
421af267-9183-4ddb-a550-00597fb5a6f0	Uric Acid	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/82fc7522-59c3-48d3-b547-53493a046991.jpeg	18	5	t	2026-10-15 11:19:09.233448+00
91abfef3-d9b8-40d2-9109-a66e97f2607c	TBil	reagent	Mindray	Bil-T stands for Total Bilirubin (T-Bil), an in-vitro diagnostic clinical chemistry reagent used to measure total bilirubin levels in serum and plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7c5f0487-98ff-49b4-8331-70286a3036e8.jpeg	33	5	t	2026-10-15 10:23:13.086882+00
81ef7ace-0699-42db-85ba-4c050a08a008	LDH	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8597a079-adbb-4fd4-93d2-ffa486624ad6.jpeg	6	5	t	2026-10-15 10:44:07.506625+00
d6d4fda9-6087-410a-8bc9-0a5622f40e32	GGT	reagent	Mindray	A GGT (Gamma-Glutamyltransferase) reagent is an in vitro diagnostic chemical kit used in clinical chemistry analyzers to quantitatively measure GGT enzyme activity in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/92faba04-454d-4ac6-afb1-4041cffb953e.jpeg	12	5	t	2026-10-15 10:16:43.503611+00
cb424877-c00e-41ba-a9ab-94854c930087	Albumin	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/87cb2f1c-ef9d-49a1-944b-4fdd6f88e1b8.jpeg	11	5	t	2026-10-15 10:50:01.478552+00
a3bcccdf-2488-4ee9-a784-1ece4fab3df0	Total Protein(TP)	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8f5ceece-e525-4358-8688-d87870719f26.jpeg	11	5	t	2026-10-15 10:49:12.545901+00
2cf77d43-efc0-4773-9519-610d10df99b7	HDL-C	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ffb2009d-575c-4127-83e3-b093d6c730d6.jpeg	67	5	t	2026-10-15 10:46:06.291342+00
dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	DBil	reagent	Mindray	Direct Bilirubin (Bil-D / D-Bil) is an in-vitro diagnostic (IVD) clinical chemistry reagent used for the quantitative determination of direct (conjugated) bilirubin in human serum or plasma	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/616cb355-313a-4d3a-8bac-d66529963d59.jpeg	28	5	t	2026-10-15 10:24:21.942008+00
6452048e-904a-481d-9879-dfbc9b3b89ba	Phosphorus	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/af0bf0af-12c2-484c-8a35-8e1578136f5a.jpeg	1	5	t	2026-10-15 10:38:05.678202+00
fab99f9a-b0b2-4e61-989f-5a2da8585cb8	Enzyme Detergent	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/dde4356d-76c4-41c5-bcd2-ee009bb86270.jpeg	1	5	t	2026-10-15 11:14:03.335102+00
3e76ff9b-1c77-4346-891b-0123b161eac8	Hematology Control	reagent	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/811ce2b4-0ae0-4fc9-a81c-5bb06c3b1ca9.jpeg	1	5	t	2026-10-15 11:16:32.379791+00
653d76e0-0733-41e3-8620-8901b926557f	Electrode Suit	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b22b54d8-44b7-4c8b-968a-748176854f00.jpeg	1	5	t	2026-10-15 11:18:02.472926+00
6d4f3554-2ee0-412a-af30-471500879cbf	TC	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6cec0cf9-407b-4a80-aaa2-f0cc6e81090b.jpeg	36	5	t	2026-10-15 10:46:53.682468+00
64b67e4d-cc43-47ca-87aa-5ba976f98625	Elical 2	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b288b5c7-c099-4298-9d7f-03f0175384bb.jpeg	4	5	t	2026-10-15 11:21:59.38244+00
5f57a013-29c1-4526-b33a-dee64e43db66	Elitrol 1	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6d1ea94c-542f-49c6-b117-7cd7800dc850.jpeg	7	5	t	2026-10-15 11:23:13.456895+00
bc6e03e2-4719-41ca-ae33-56363faf99a3	Elitrol 2	reagent	Elitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/873f44d3-d4d6-4891-9457-4144b1c744e3.jpeg	3	5	t	2026-10-15 11:24:21.386418+00
7fecdac8-2555-4a55-972b-e44c988f2e3b	E2	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ad44d0e6-462d-4247-baf5-cb683e45f1df.jpeg	4	5	t	2026-10-15 11:53:17.443733+00
c4ada7ad-90dc-4f0b-80c8-255fb280929f	Autocal	reagent	Human	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f75b1c6d-1c1b-4db4-878b-fe4df48798aa.jpeg	1	5	t	2026-10-15 11:35:09.29032+00
5dd86b23-1a0f-4610-b26f-1844b931e8cb	Cholesterol Standard	reagent	SDi	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bc770405-d8e7-4066-bbd9-af49d1f9f074.jpeg	1	5	t	2026-10-15 11:37:32.433661+00
d5ef0c98-1636-44ab-beb9-00c32af409e6	Prolactin	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/15357b8c-033e-4751-84a0-f65670e68bee.jpeg	10	5	t	2026-10-15 11:55:32.86325+00
c4be0085-5b40-4025-8c3b-daaa440d0605	Creatinine 	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b8052c19-11f1-4ee4-80c2-1364750e2e56.png	1	5	t	2026-10-15 11:38:28.437416+00
2b78a00f-31f9-49df-bbc8-6a974284d9b3	Albumin	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/329faa94-6d75-4fe8-8a68-cccf49ecb313.jpeg	1	5	t	2026-10-15 11:41:15.165061+00
1bbd62da-cf4f-473a-a6e4-1b76dae811b5	CKMB Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e622683b-d744-49e6-8bdc-c63a8d7854ed.jpeg	1	5	t	2026-10-15 11:26:49.872566+00
c7d35921-00d7-4dd9-99f3-9d97185c8190	ALP	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/77354658-3bb9-49c4-bb9a-206f45e1ac78.jpeg	1	5	t	2026-10-15 11:43:38.73796+00
5dae3134-fa21-4b2f-8ddf-a1570bd60b39	Urea/Bun	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7dd08043-d5f4-4242-8d68-b9f748323ac7.jpeg	1	5	t	2026-10-15 11:44:09.315065+00
04e87bfa-87b9-4bb3-ba33-679389a8fac5	GGT	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b6aeeb30-10b9-4d4e-af07-1c4fdd0749e3.jpeg	1	5	t	2026-10-15 11:44:59.161149+00
2a93e8fb-51d0-4098-8240-98a251b14f1d	ALT	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f8b2d255-dcea-4e9d-8da7-4bec720ce300.jpeg	1	5	t	2026-10-15 11:45:30.890209+00
d95e9245-a421-4351-89a2-6c363c15c948	LH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4f1c2bf3-5089-4fa9-813c-83f4dcf73721.jpeg	4	5	t	2026-10-15 11:52:23.198079+00
4cd01e41-701c-48c4-991e-459cc8e31a3b	FSH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4fab4780-c3cc-49c0-b847-fd543436edfd.jpeg	2	5	t	2026-10-15 11:54:55.980319+00
5f6badbf-8cf8-4416-9bf4-873503e719c5	Progesterone 	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/16240a74-c945-4579-83b2-a4d541419ad1.jpeg	4	5	t	2026-10-15 11:53:40.083308+00
f2b1be08-5c83-4eda-8b9f-6ea582926dc1	ALP	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/01fa7b0b-976c-4ce0-ba07-4c34717c1247.jpeg	0	5	t	2026-10-15 12:26:16.162886+00
cab8db31-f31f-433f-8bf2-8f551509c2f7	Testosterone	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/471288f5-74d7-4a75-81a0-d930757b9225.jpeg	4	5	t	2026-10-15 11:51:30.001827+00
b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	FT4	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b3d6505d-490d-4dd7-9bbc-3fb90ff6e304.jpeg	6	5	t	2026-10-15 11:55:51.883816+00
051566a2-cdd1-4edc-b86b-afc306c0f1ef	Ozocal	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/aabad715-3aa1-4354-a8b3-6874fb12c5e9.jpeg	0	5	t	2026-10-15 12:23:48.318938+00
3c9fc04b-2f30-484a-9889-9236bd4342a0	Urea	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a349e43d-9c73-4d8f-a9ca-8fc5c65266f4.jpeg	0	5	t	2026-10-15 12:28:35.743476+00
461e45a1-6171-4515-9ada-d619ef45641b	UTI	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7a768418-4676-40bf-8f55-6ae97e03a5a4.jpeg	0	5	t	2026-10-15 12:04:29.199874+00
65f2bdb9-292e-4f42-87af-ba69db497a1d	Gram Negative	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd4fd3fc-acdc-423f-90ec-ce2546c984ab.jpeg	2	5	t	2026-10-15 12:02:36.016637+00
308fcffa-e9b6-4762-a000-74f95c9ca638	HCG	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/39e87f1e-1860-4e1d-97d6-847bb254b511.jpeg	1	5	t	2026-10-15 11:53:57.803628+00
8e99c78f-3a46-4b61-84cb-e621621ccb57	Albumin	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c2d1daa0-0133-4dc7-98b8-20662b4f6534.jpeg	0	5	t	2026-10-15 12:28:04.131114+00
dd3669d4-2f57-453d-a7b6-aa21012d7813	CK(Nac Activated)	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5c0d59f7-85dd-48a6-b8a2-4f7f943e310b.jpeg	12	5	t	2026-10-15 12:16:49.385651+00
c4e57f6d-25dc-4abf-8212-37351a30f621	Ozopath	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/165f38e1-a210-4b0e-b479-b571e5e77613.jpeg	6	5	t	2026-10-15 12:13:15.226947+00
2a0b04c3-f851-4a67-9850-2fbf78c5e078	Grouping A	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b99c17cb-260e-4f7f-aef6-08578a73f092.jpeg	44	5	t	2026-10-15 12:08:22.962533+00
34de459c-89d8-4821-9511-5b271b020f1f	AST	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/34c388fa-c5fd-4cda-9d3e-eb3034f2338f.jpeg	0	5	t	2026-10-15 12:26:58.944082+00
2ff86e38-152d-49ab-801f-dbc3b8f682ac	Ozonorm	reagent	MEDSOURCE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fa6ef02f-5fd9-4331-ad30-cb5a22571da7.jpeg	21	5	t	2026-10-15 12:11:39.678558+00
b9b11539-9378-401d-b02f-1a6c57468a00	FT3	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/69b801fa-a2a9-40a6-b5ea-9b91a10f3f6e.jpeg	7	5	t	2026-10-15 11:52:46.678044+00
6c0ed636-bee3-4945-ba22-9947e85b0e8a	Cystatin C Calibrator	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/345c5f22-58e5-4036-bcd9-d779eb5c3d44.jpeg	13	5	t	2026-10-15 11:30:27.503076+00
659be18d-7cb2-47fa-a814-6d48cc07b97b	Gram Positive	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ee02392c-b3aa-4dbc-9e77-eb4607e195e8.jpeg	2	5	t	2026-10-15 12:00:46.063897+00
bf552471-6e68-44ee-87c9-d9fd808c3f05	BilT/BilD	reagent	Cromatest	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b1dfb0c7-99f9-466a-b522-f48e41bb0cf8.jpeg	1	5	t	2026-10-15 11:43:07.458915+00
1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	Chemistry Lamp(Fully Auto)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b88bbb13-1bd5-454b-9c84-5f6749f3d4ee.png	14	5	t	2026-10-15 12:58:48.633398+00
322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	Total Protein(TP)	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9329c5a3-a57a-424a-b4df-2ced9d595221.jpeg	0	5	t	2026-10-15 12:29:23.422761+00
056fe8d8-9df5-4505-9a85-faaaf1cd5377	HDL-C	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4fb75d45-d405-4e8e-84a8-e5e5a3b12ba2.jpeg	0	5	t	2026-10-15 12:29:03.562521+00
cdfc7193-716c-401e-987e-ce20381b3e44	GGT	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f319eb09-e721-4c59-ab9c-b1c2d4740dd0.jpeg	0	5	t	2026-10-15 12:30:56.094711+00
a1d9955d-4411-4f64-9dd7-b460068d52bc	DBil	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/52869e47-4ad6-43ad-b165-9ab935a11c62.jpeg	1	5	t	2026-10-15 12:32:10.977593+00
59c06c74-f342-4be2-bc93-547b7f242c03	Macconkey Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/63b57424-6978-435a-90b8-32f7ca429438.jpeg	0	5	t	2026-10-15 13:20:57.898734+00
cba33b9f-880c-42fa-b4ff-bf55a415bfb7	Creatinine	reagent	ULTRACARE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8a8e5059-117c-4423-823c-a0019ae164fe.jpeg	2	5	t	2026-10-15 12:36:17.032999+00
d4790878-c6c0-4c47-8c42-d8fdee4727d0	Grouping Sera Set	reagent	Spectrum	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2408cb39-904d-462d-9291-0a499011639a.jpeg	0	5	t	2026-10-15 12:38:22.582866+00
ad8ca44c-84e8-47a9-869a-0cb70f002019	WBC Light 	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cd31c53d-2187-4c2d-9eba-79ea0303357c.jpeg	7	5	t	2026-10-15 12:52:17.270969+00
e43b07dc-3e00-442b-8ab0-1b78e55d200e	3-Way Valve	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/493a6ee0-3281-4609-b7e7-18b460629946.jpeg	6	5	t	2026-10-15 12:40:40.013172+00
26d5d1c1-9d87-4970-97e6-57791b50c3df	2-Way Valve	equipment	 Mindray Spare Parts	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/f40acb22-0800-4d58-bce1-93c93fa7b22f.jpeg	7	5	t	2026-10-15 12:42:32.330621+00
f6f3649f-2f07-4c67-9943-5ab1429892e6	Isolation Chamber	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/11dc3879-5fa1-44bf-bb70-648fdfa1ce50.jpeg	9	5	t	2026-10-15 12:43:56.289868+00
99777cff-18a4-4e87-bc75-988d35589c33	BS240 Cuvette	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/dfa30f3e-d5b1-4578-a73c-9fe563bbe894.jpeg	15	5	t	2026-10-15 13:14:56.820657+00
1c945adf-e636-446a-a0a9-1f3a712271c9	WBC Chamber	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e15ab3d2-cc99-4ebe-ac56-280b0395263c.jpeg	2	5	t	2026-10-15 12:48:13.87597+00
60c5327c-1e65-45be-8e6c-d466d560f1f4	Horizontal Belt	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5ec5fb90-3365-4e90-a3ed-1c8d4fa2966b.webp	2	5	t	2026-10-15 12:50:13.590666+00
14192d9b-42e4-43bf-b319-4cd7584aa3d8	Rotation Motor(Down)	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d9880cdb-f84f-4d8c-94ab-99e3a65dc076.jpeg	1	5	t	2026-10-15 12:54:00.739905+00
cfbd97f4-63db-4d59-a335-c37e37750f8a	BC3000 Plus Screen	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9c293620-7846-4da3-a3f6-277426a97cea.webp	1	5	t	2026-10-15 13:19:09.946796+00
def0af54-5508-4904-8e51-c0dbf72a1618	BS230 Probe(Short)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/748a70f5-5121-4ccc-85e1-a079c9bb57b6.png	17	5	t	2026-10-15 12:56:47.007313+00
576cd245-ef27-4989-8960-f52085ab307d	LMS Board	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b3205f97-ed6b-47dc-84e1-46bcc43980b5.jpeg	3	5	t	2026-10-15 12:46:22.049323+00
491bd73e-fc85-400e-beb7-c0f433899ed8	Chemistry Lamp(Semi Auto)	equipment	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9e21c5ff-ba7b-4949-8235-844f04ec8db1.jpeg	1	5	t	2026-10-15 13:01:16.308434+00
acf4c443-9c3c-4c75-8886-738a9765d34a	BS 230/240 Power Pack	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fc2f4254-a330-4567-b446-3654e95216e7.webp	1	5	t	2026-10-15 13:03:01.065156+00
98816970-f9e2-4868-a95b-873475f0db3e	Screen	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/89bf9900-9b7f-4684-b1ec-384716e4e11e.jpeg	3	5	t	2026-10-15 13:04:33.597861+00
61dec910-f577-481c-93ef-f832bcec3d9f	Glass Syringe	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8ed14000-34bd-4a79-9cbb-0b92f20e1d04.jpeg	3	5	t	2026-10-15 13:06:52.164946+00
7fed6899-c746-49a4-a2da-cf871ceb495f	BC10 SD Card	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b2e86634-e1d4-45d8-ac87-3706ed7fab60.jpeg	4	5	t	2026-10-15 13:08:35.460079+00
5b736c5f-3c02-4672-8497-7dfc17b49a80	BC20 SD Card	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b4916a0c-f0a4-422d-8a8c-3eb6e7a32aad.webp	2	5	t	2026-10-15 13:09:18.70207+00
313c3a6a-b5bd-4b67-b3bb-9552f7207c59	Dry Block	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6e59c693-cc5b-4f83-9eef-75f2173ee28e.jpeg	1	5	t	2026-10-15 13:11:04.011164+00
05e53106-69b8-4682-a6be-b6de4bd64000	BS200 Cuvette	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0484674f-9272-4680-bb9c-46d0b07d14e0.jpeg	10	5	t	2026-10-15 13:13:11.96915+00
75adac4f-8200-439b-8426-0d1986416946	TC	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2e7b9220-6fa7-45d2-9b16-73cbc212935c.jpeg	0	5	t	2026-10-15 12:29:55.829469+00
d4185435-b8a9-48bf-b7b1-7446245b35ab	Probe Wipe	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/492547c1-cf57-4cb7-80aa-52fd6c993c3b.webp	1	5	t	2026-10-15 13:16:02.147787+00
50ab9fee-98df-4ae0-ac78-4cbbc592272d	BS240 Probe(Long)	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d1ae9474-e65d-4d8a-8211-e08bd96ca2a6.jpeg	9	5	t	2026-10-15 12:55:28.477615+00
190becce-9184-429f-b602-55c7beecea24	TBil	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/395e2639-764c-421d-ae70-5d21188abf80.jpeg	0	5	t	2026-10-15 12:31:40.4401+00
5ebb6d12-aa2b-4275-b322-949e5e7cc086	Sodium Meta Bisulphite	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fb29e44d-d6a2-49fc-895f-da320ce683ee.jpeg	1	5	t	2026-10-15 13:21:56.972558+00
757ad4e5-8fd5-41a8-8141-bc0909726064	Triglyceride	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/0997b9b5-230a-41e9-8053-944b7040a41b.jpeg	0	5	t	2026-10-15 12:30:36.04525+00
d64307a7-c776-44e1-9823-0a94a43d9fcd	Creatinine	reagent	Inolitech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2abcb458-e334-4f8e-a602-e08dc45baea3.jpeg	1	5	t	2026-10-15 12:31:15.978286+00
0f537939-ec3d-4520-8ec6-450b21480858	Syphilis	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6aacc74d-9eb3-4990-be07-2dda8f130d0d.jpeg	0	10	t	2026-10-16 08:47:32.029569+00
41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	Simon Citrate Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b199c36d-f13a-4075-b76f-4e226018266a.jpeg	0	5	t	2026-10-15 13:23:28.868665+00
56cdbdf2-3b93-46e7-9f90-83373145f827	Cotton	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e2baff53-5ed1-4b3f-9896-45cd9aa60f98.webp	17	5	t	2026-10-16 09:29:57.986665+00
371b2c03-2b4b-4a87-87f4-bd2694338ef5	Finecare Analyser	equipment	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/834753e8-fad3-4fc3-bee6-8a61c16ff2ad.jpeg	3	5	t	2026-10-15 13:28:49.684437+00
daea334f-45d9-498f-91c5-c57769160d0b	M30 Lyse	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ab2654d1-ae23-406d-ba4a-92619de13d22.webp	1	2	t	2026-10-16 08:52:43.962901+00
1cfbbd77-1dd6-41ac-b603-35af72ec737d	AMH	reagent	AccuBind	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a8bcf332-eb0f-47b5-9a09-c51855c2141d.jpeg	1	5	t	2026-10-15 13:40:16.721556+00
b5fe9c12-b945-4aec-9049-39a8b9159733	Plain Tubes	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6ed29b75-e1ba-4255-aa49-08e51d9abb58.jpeg	12	3	t	2026-10-16 09:13:17.782818+00
0ded23de-1d23-4279-b783-1e5c5a59ca5d	ST200	reagent	Sensacore	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/cab3000f-9772-40bb-8a16-ce3af608a899.webp	5	5	t	2026-10-16 09:12:15.679565+00
feed7224-1883-4dbb-87e9-244150e61d54	Diluent RD7	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/de27ad58-790e-4ab3-b7ef-bcc90c254716.jpeg	1	3	t	2026-10-16 08:32:56.896099+00
c02fa806-d252-4315-b4ae-b1ea0846c420	Typhoid	consumable	AlphaPharma	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/86002c5c-7e06-4388-b7f6-1b3562b487dc.jpeg	11	5	t	2026-10-16 09:08:25.374923+00
731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	Diluent LD3	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ffd133e9-40d7-4a10-8463-18bcd22fe05f.webp	2	5	t	2026-10-16 08:39:52.303641+00
318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	Diluent Rayto	reagent	Rayto	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5d08e738-b7f2-4f75-85b6-4783a45c7b38.webp	26	5	t	2026-10-16 08:36:46.655981+00
ed335ad7-006a-4922-ad15-53f8faa37e4a	Rinse Labnovation	reagent	Labnovation	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d392786d-93f6-48c5-ab64-ba7357d2caab.jpeg	1	10	t	2026-10-16 08:42:14.12979+00
613b356c-997c-425c-98f3-876bb2203c6a	EDTA Tubes	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e541cc26-1b2f-445b-a840-017594025936.jpeg	12	5	t	2026-10-16 09:09:58.903264+00
9b21331b-4332-4cbc-97d3-33ed2ecc6acc	LD Lyse	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c550254a-ca93-43eb-835c-2db29b483c7a.webp	0	5	t	2026-10-16 08:55:51.388516+00
d3992ca7-83aa-453b-a8d0-21d9644f6782	Timer	equipment	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4460ebbe-7f9d-43db-bd43-2230a37ef5f6.jpeg	122	10	t	2026-10-16 08:50:50.996832+00
a7206327-20b6-44b6-b489-d2f563ee49b2	Diluent Sysmex	reagent	Sysmex	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a93a55a6-7b5d-47f3-b5ac-d3cbac308e47.jpeg	1	3	t	2026-10-16 08:27:37.330217+00
fa3c9366-9b08-440c-8725-c5180ae578ee	Diluent Labnovation	reagent	Labnovation	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/adfbdb3b-9e28-4e6d-acdf-128df19a603e.webp	29	20	t	2026-10-16 08:25:55.12292+00
d359c066-20dd-4f17-baed-699c38753958	Rinse Cleaning Solution	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1dad73c3-066c-44b0-9d16-e4577b148f2c.jpeg	0	1	t	2026-10-16 08:45:26.847628+00
3572f4d3-23dc-405a-a94e-3fa793df5fee	Glass Slides	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/ac277b36-a9a3-4452-97ee-356173973dda.webp	36	5	t	2026-10-16 09:14:51.418808+00
9db7aae9-12d8-4716-aff7-0532026f939a	G26	consumable	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/55ff0958-801d-4cd6-a9eb-bf6b2fa37004.jpeg	2	5	t	2026-10-15 13:25:46.459532+00
ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	Hepatitis C	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fd7fac19-fb54-418c-b320-80fabec6a4d2.jpeg	10	10	t	2026-10-16 09:03:08.27778+00
ec733761-dbcb-4ae3-839b-8f759f29057f	Combi10	consumable	URIT	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7b2c9fb5-34fa-4000-9cd4-f3b87707e619.jpeg	4	5	t	2026-10-15 13:27:29.754352+00
b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	Plaster	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c6807a0f-453f-4557-ac6d-39457eb07fb7.jpeg	58	10	t	2026-10-16 09:16:58.262674+00
b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	Diluent Coded	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a4aa65ac-3f1b-4378-a2a3-c1a0e5774fa5.jpeg	721	10	t	2026-10-16 09:01:30.30164+00
ef7a13be-5ef7-4044-a641-60561d491a66	Digital Clock	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/7b8a1732-4bdb-4233-8ca0-7a1119443d3c.webp	1	3	t	2026-10-16 09:19:36.24207+00
28103a7e-6f63-430a-bac2-a8c6eef4b4e5	Distilled Water Plant	equipment	BIOBASE	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9e57ee15-40a6-469f-bde4-b24c16715042.webp	4	2	t	2026-10-16 09:22:28.994901+00
9b2a4a10-c691-4cdf-957e-78ec49a74c7d	Blood Collection Needle	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9ba1a7ea-2773-4489-a340-83c53febb763.jpeg	3	5	t	2026-10-16 09:26:12.00105+00
bb775507-b788-41fb-ba00-660b1911bba2	Gloves	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/37a58f7c-8369-402f-a8d7-bf4be48e66d7.jpeg	1	5	t	2026-10-16 09:15:32.241793+00
950d3492-cf9e-4b6d-b6bf-eaa830f709a9	HIV	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8d0d3e6f-72b7-42c3-ad92-a20d4799ec23.jpeg	54	10	t	2026-10-16 08:48:40.823035+00
4fd457b6-2f0f-4771-b8fd-d54283355d9a	CLED Agar	reagent	BIOMARK	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/fd80776a-b087-4d65-87a0-b42163794cfd.jpeg	0	5	t	2026-10-15 13:23:58.187924+00
6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	Hepatitis B	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d02b40b7-d3a8-4f59-b0d0-91855d1b06fc.jpeg	10	10	t	2026-10-16 09:03:59.343538+00
1d462684-8f12-4d3c-8828-8b4f20f01e28	Gauze Roll	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/edfb5b2a-4f42-4c72-be5a-f39a0e6cc9c4.jpeg	6	2	t	2026-10-16 09:31:09.622411+00
fda6810f-87ff-4863-9c2b-e0213ac55cc8	Prolactin	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1b552d75-f0b1-4690-8501-77cabf663120.jpeg	21	5	t	2026-10-16 09:57:20.971802+00
63e1b692-a6ed-4edf-8373-9349000b5f5e	Blood Lancets	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/be51b8d6-7cb5-429a-98af-73ae73565d8c.jpeg	2	2	t	2026-10-16 09:34:48.329147+00
f697ee81-89c0-4297-a5de-62ac36f325b5	Immersion Oil	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1280c3a6-5c3c-4718-8b04-f1a474e2808e.jpeg	1	2	t	2026-10-16 09:36:02.620856+00
f5cf61f8-72f0-4426-b0b3-2095ee7155b2	Urine Container	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/76e285ff-81bb-4102-99ba-1b67a43c04d5.jpeg	200	20	t	2026-10-16 09:36:58.270311+00
42433484-7a92-4459-9509-536e55910c3f	Glucose Lifecheck	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd96c3b0-ffc5-4554-bd67-4e23c8e0b3d2.jpeg	3	2	t	2026-10-16 09:38:20.33844+00
9d3efcc1-82a7-4697-9aca-9c11c4a31037	Sample Cup	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e9f22a17-8939-49b9-9b98-d8d649b25db3.jpeg	2500	1000	t	2026-10-16 09:39:50.54201+00
b50611fb-eeca-4b74-a02a-91e2ea2d9846	Testo	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2832fed3-2973-48d8-a784-36436e253324.png	6	5	t	2026-10-16 09:43:20.35562+00
923b5487-1db2-46d0-a0a3-3af4a83830e6	BC10	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/45325985-46bf-447c-b5f4-dc56bcc011fc.jpeg	0	1	t	2026-10-16 10:17:57.03059+00
e1d8a6b9-b965-479f-a777-f85b0df18c59	CRP	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d267cc87-e77f-4cf5-a674-a80aa76fd008.jpeg	19	5	t	2026-10-16 09:49:34.303106+00
55170fd5-00ce-4241-9620-ee6dced18987	Microscope	equipment	Olympus	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/571d8795-4398-47d7-a26c-f1dfba2f7662.jpeg	0	1	t	2026-10-16 10:21:26.648637+00
48c8796e-48a2-4355-b4e7-16bce21b2710	Thermal Roll(L)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bf7ddf2f-ecb7-41ca-8466-632d794e7762.jpeg	23	15	t	2026-10-16 10:10:01.670009+00
d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	T3	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/75b55605-e91a-4f2b-acea-1a78c752e68d.jpeg	2	5	t	2026-10-16 09:48:14.748224+00
9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	Progesterone	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd484306-e6ad-4611-bbc0-1fa82648914a.jpeg	5	5	t	2026-10-16 09:54:34.910399+00
0a2d780b-6404-4826-a300-d6c89964ae40	Centrifuge(6 Buckets)	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e2a3f529-7f31-490e-91c8-000f11ecab9a.jpeg	1	1	t	2026-10-16 10:22:32.887025+00
6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	Alcohol	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/d17345df-164f-485d-945a-fa7110bd149e.jpeg	32	5	t	2026-10-16 10:06:34.670938+00
fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	FSH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/35a4f591-54df-49e2-ba98-152b496dcf72.jpeg	15	5	t	2026-10-16 10:02:03.55059+00
f837a23f-6bcd-4d96-9291-bba4d69caf3c	Diluent	reagent	SGBiotech	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c51aa2e9-4ffd-4313-874b-2c795379939e.jpeg	1	5	t	2026-10-16 10:12:37.05425+00
b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	AMH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/c4fe179b-b035-475e-ac28-e39d22004551.jpeg	7	5	t	2026-10-16 09:57:59.719297+00
38150feb-b79b-45e8-b451-9a1aeb96af06	FPSA	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/1d1b888e-4f43-427b-8eea-baf9a58cea8d.jpeg	1	5	t	2026-10-16 09:59:47.395531+00
f1aabb46-04f7-4c4f-83c0-d532953304a1	Thermal Roll(S)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/13e40071-2f9c-4f33-8b7f-4ce8a303bfa2.jpeg	16	20	t	2026-10-16 10:09:21.671484+00
f5336cfc-123e-412b-9128-4aab6543591c	LH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a02bcbc6-7ea4-418d-81be-da47e478f6c2.jpeg	15	5	t	2026-10-16 10:00:46.965689+00
2f1bb631-b9aa-435b-9217-341aa3fe9ada	CKMB	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/a02fbb2a-3440-4241-9b21-7e006e6cb78e.jpeg	9	5	t	2026-10-16 09:45:22.926005+00
1df32cc2-2332-4453-9847-ad60db9ed220	D Dimer	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/5160affc-ffbc-490c-b729-380a9a758233.png	13	5	t	2026-10-16 09:47:19.99488+00
154fbfed-8711-471d-badf-6bad744ce246	E2	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/000aa272-0fcc-4016-bf5a-c4cb9a2d3e95.jpeg	6	5	t	2026-10-16 09:44:28.314387+00
62f9f784-9902-45e7-869e-0ce5e8cfdbd2	FT3	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/01174130-8fee-4aa4-b33a-979d4f79bcfa.png	8	10	t	2026-10-16 09:41:42.498779+00
507af4d6-75cf-43f6-a30a-3c118c7cd48a	PSA	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/08e05e01-4e0a-41f8-a453-193416dc5cee.jpeg	38	20	t	2026-10-16 10:01:18.971392+00
4a0b448d-3fb8-4474-a9d9-267f5319518f	Pulse Oximeter	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/9139ce19-67bf-4dd8-a07a-fadd10e4c8b8.jpeg	4	1	t	2026-10-16 09:32:44.595849+00
ba28ef00-70b2-4902-94ff-cd4545a1e506	BS240	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/46221dae-d44c-4889-9021-35a00d1d92a7.jpeg	1	2	t	2026-10-16 10:19:16.954194+00
79f46b6a-9be6-4131-a71b-79f864b7efe6	BC3000 Plus	equipment	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4ecf548c-0fe7-43af-a903-25f70b475ec2.jpeg	1	1	t	2026-10-16 10:20:19.642464+00
6faff9cb-851d-4fcc-8478-a18c83228de5	SensaStat Control	reagent	Sensacore	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/13a517d7-53d3-4789-9458-7120c1240df6.jpeg	3	5	t	2026-10-16 10:15:46.80767+00
7640cb52-77e0-4374-a235-bdb6e0d41503	cTnI(Troponin)	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/898724f0-9188-4c3a-8666-e455fefe5a33.jpeg	0	5	t	2026-10-16 09:53:13.007561+00
0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	Cuvettes	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/44dd0101-d5e7-4ef4-90d5-404d99b28aa7.jpeg	2	1	t	2026-10-16 13:47:45.587613+00
2d096f70-6b8d-4a45-a9b9-0388c96a945d	Vaginal Speculum	equipment	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/eb788796-ce5f-4f4e-a62f-72ea063fd46c.jpeg	1	1	t	2026-10-16 10:32:26.400738+00
9cbfc261-d617-42b5-be18-97be0da5540b	Biosphere Filter Tip	consumable	Biosphere	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/05803019-914f-4793-aa73-e255911cafe5.jpeg	85	20	t	2026-10-16 10:36:37.7346+00
5a072e55-b0c1-4102-9b9f-6e786d9a2343	EZ Cleaning Solution	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/40b6462e-bd65-4d9e-a2c0-4d6d378a9044.jpeg	18	5	t	2026-10-16 10:46:42.942043+00
2506f42e-d3d7-41f8-ab97-0473118c3630	Gonorrhoea	consumable	Micropoint	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bd02e44a-550b-4b5a-a6d7-67c48dbaa50c.webp	5	5	t	2026-10-16 10:51:15.165475+00
49147609-1a68-4612-a2a5-3845b60a2d38	Swab Stick	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/47dfe762-a91a-4303-a039-920b19a98fdb.webp	50	10	t	2026-10-16 10:52:17.761104+00
5325af28-0ff3-479d-ba25-2507b2dcb708	Yellow Pipette Tips	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/4de827a3-9655-4d98-a76e-8bea70c7a5c7.jpeg	0	100	t	2026-10-16 10:55:18.840108+00
90cdf544-bf74-4d7c-9cef-c2e3148c29b2	Diff Lyse	reagent	XKivd	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b236ab29-0f9a-4fd3-ae93-5524b454a095.jpeg	2	5	t	2026-10-16 10:26:04.341785+00
94d568da-7421-440c-839d-30290b500f97	Giemsa Stain	reagent	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/8d068387-d7e4-4726-9279-02cd808d19d1.jpeg	1	5	t	2026-10-16 10:49:16.699959+00
3790e5e0-27aa-46dc-83bf-2e2fc39ed784	Afp	consumable	Wondfo	Finecare 	\N	6	5	t	2026-11-02 09:05:48.061355+00
47a585ae-b9a1-44d5-bb04-776aff161924	Hba1c Calibrator	reagent	\N	\N	\N	10	5	t	2026-11-03 08:37:44.85795+00
571fa9c2-9b3f-4171-aebe-a02e9a9e79db	Sysmex Lyse(Stromatolyser)	reagent	Sysmex	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/00927b2a-a139-4571-9e31-6a011521583d.png	1	5	t	2026-10-16 11:21:30.025681+00
561a9cbb-7026-4bed-becc-73e235cb6f79	Ferritin	reagent	Mindray 	\N	\N	0	2	t	2026-10-27 11:10:20.25297+00
dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	HBA1c	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/51f40454-d4bf-4fa9-8bbc-47698e8c9540.jpeg	40	10	t	2026-10-16 09:46:31.419933+00
e059c881-7d54-4209-b77c-89e0aa17f462	Hepatitis B profile 	reagent	\N	\N	\N	0	2	t	2026-11-02 09:04:38.727546+00
ad538600-13a1-417b-93d5-18a7d808d596	Alt	reagent	Medsource/ Inolitech 	Reagent chemistry 	\N	0	2	t	2026-10-21 11:19:52.593795+00
f1bd219d-1c82-4b0e-9f30-0d6518f99b92	Ozonorm	reagent	Liquizone	Control	\N	21	5	f	2026-10-21 09:05:11.203931+00
697b3608-ae6b-4cc2-bf54-4826386e5ba1	Ozopath	reagent	Liquizone	Control 	\N	6	5	f	2026-10-21 09:05:44.59478+00
bd357ee5-7fff-4f95-8ca9-144fc25b9d4d	TSH	reagent	Accubind	\N	\N	2	5	t	2026-10-27 15:08:09.856872+00
b5b29294-5106-401e-92fc-82cb7cdf4e20	Tris buffer	reagent	\N	\N	\N	0	2	t	2026-10-21 09:10:25.579998+00
929c42a1-1e18-4063-9cf4-f75586cdd858	Hand Tally Counter	consumable	\N	\N	\N	0	5	t	2026-10-19 08:55:32.129215+00
0eaebabc-c4c6-414f-9b9f-adc3f94f66da	Cellulose acetate paper 	consumable	\N	Electrophoresis 	\N	1	2	t	2026-10-21 09:09:31.281779+00
12524346-ae4c-414d-a09c-d1fd4640cb50	TSH	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/6a87e591-b3db-4322-bb05-b4ded6815a0a.jpeg	24	5	t	2026-10-16 09:55:56.319837+00
9977e869-da83-4601-bee1-77d5e29f1ed5	Probe cleanser 	reagent	\N	\N	\N	7	5	t	2026-10-27 11:09:57.201049+00
17c581bc-76b8-4beb-8a2c-e00047754559	Ft4	consumable	Finecare	Wondfo	\N	13	5	t	2026-10-20 15:17:23.701015+00
328cc8a1-848e-4c8b-ad40-4a6fe279bcc2	Syringe(10 CC)	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/034cfa1c-9ced-4290-b507-504803b45ca2.jpeg	2	5	t	2026-10-16 11:07:28.937316+00
28ae0672-5605-420e-b7d5-2143099672a3	CA125	consumable	Wondfo	Finecare	\N	5	2	t	2026-11-02 09:06:34.451154+00
598eb297-3ff5-47e5-8cb9-5904f6bbf516	Daily Cleaner	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/22719fb3-a7e9-43e2-8c66-476a65c5969e.jpeg	61	15	t	2026-10-16 11:00:04.733017+00
467055cd-1828-456d-a743-8a6f62e4ce28	Hepatitis 	consumable	Evancare	\N	\N	8	5	t	2026-11-03 08:22:29.313099+00
9b2e77d6-dfee-4a2a-83b0-1224f12875ef	LH Lyse	reagent	XKivd	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/2c4f5ca0-6974-4c3b-b1f5-388fc91640d0.webp	82	20	t	2026-10-16 11:10:03.48905+00
caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	Beta HCG	consumable	Wondfo	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/bbf9de8a-24ac-446c-b5ed-c8e49cb3e1aa.jpeg	12	5	t	2026-10-16 09:51:14.035901+00
dc70ad7e-0402-4c06-84fe-4beb2fa3a36f	Dp 10	equipment	Mindray	\N	\N	0	1	t	2026-11-03 08:26:25.899895+00
8baabf93-fdc9-41ba-b8d9-799e11986431	BS 120 probe board	equipment	Mindray	\N	\N	1	1	t	2026-11-03 08:23:16.088606+00
c73c4429-709a-4c4c-9071-5b1e701f82cf	Pinch valve	equipment	Mindray	\N	\N	6	5	t	2026-11-03 08:23:50.492528+00
12c37938-1696-4321-ae41-c4472ba319a1	RBC chamber	equipment	Mindray	\N	\N	2	1	t	2026-11-03 08:25:35.972902+00
2589ccdd-7774-4eb6-952f-aff007ddc585	Blue Pipette Tip	consumable	\N	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/510c81df-a2f7-498d-814a-63a3932f6d52.jpeg	0	100	t	2026-10-16 10:54:20.298889+00
211da3c4-b29c-4795-8bf3-946c364d239f	HIV Determine	consumable	Determine 	\N	\N	7	5	t	2026-11-02 09:00:04.399218+00
52a235f2-a6a7-446a-b0ff-bdf02a6db56a	Cystatin C control 	reagent	\N	\N	\N	12	5	t	2026-11-03 08:36:46.928106+00
a552e2f5-77c6-4565-b54b-e657f0b975e4	HsCrp Calibrator	reagent	\N	\N	\N	12	5	t	2026-11-03 08:37:24.360552+00
12a3cecf-0723-4dac-8edc-c61f04338e8d	Hba1c 	reagent	Mindray	Chemistry reagent	\N	2	2	t	2026-11-03 09:23:50.279625+00
e958369c-dad7-4aff-affb-4f37609e2b25	G6PD control 	reagent	\N	\N	\N	18	5	t	2026-11-03 08:38:13.932518+00
79d3a498-b877-4953-9d58-d7593e7228b9	HsCRP	reagent	Mindray	\N	\N	2	2	t	2026-11-03 08:43:59.255788+00
b5f0a744-b1ac-449a-9b48-4e01ef12dd65	G6PD	reagent	Mindray 	146626006	\N	3	2	t	2026-11-03 08:46:32.79554+00
fe9b3591-df32-4986-b2ff-53f59d5322a8	Cystatin C	reagent	Mindray 	147226002	\N	2	2	t	2026-11-03 08:47:00.828341+00
1ccc204f-d62c-4f56-9a6b-39281f24d1e6	CD80 Detergent	reagent	Mindray	\N	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/b07e3cd1-762a-4759-87d8-c059197be874.jpeg	15	5	t	2026-10-16 10:29:18.587449+00
ee10fbe5-4a96-4440-a3fb-b29fa0de930b	Total psa	reagent	Accubind	\N	\N	1	5	t	2026-10-27 15:10:20.469899+00
37d50b0d-a5fb-4240-81f3-f704b905cefd	Gel tubes	consumable	\N	\N	\N	12	5	t	2026-11-03 10:26:21.832477+00
92a3d14a-f626-4345-8abe-6e843aeb7428	Syringe 2Cc	consumable	2ml	\N	\N	10	5	t	2026-11-03 10:26:46.588933+00
3a99f833-4946-4e84-9fc8-4e6e9355dc49	Pregnancy Kits	consumable	Hightop	\N	\N	15	5	t	2026-11-03 10:27:34.425865+00
74666bf3-cbf4-4bca-99d1-5cfda8c5ab88	Cell cleaning solution / Sysmex cleanser	reagent	Xkid	Sysmex	\N	10	5	t	2026-11-09 13:16:04.920889+00
75ffd9c4-f52f-4312-8858-63386f191793	Diluent 5 parts	reagent	BC52	Five parts	\N	1	2	t	2026-11-09 13:26:54.411687+00
23f521a0-b968-4fa8-9de0-4e3668bb8e0a	Coverslip	consumable	\N	\N	\N	9	5	t	2026-11-11 03:36:29.37547+00
229a0575-21db-4b59-ad3b-847e58391d35	Pregnancy kits	consumable	\N	Blood	\N	2	1	t	2026-11-11 03:37:26.740606+00
d4937cc1-d2c2-488f-bc93-36b8e0186036	Esr tubes	consumable	\N	\N	\N	1	1	t	2026-11-11 03:38:34.241678+00
92d9c316-0bc5-45c9-904d-706f232663f7	CEA	consumable	Wondfo	\N	\N	1	2	t	2026-11-13 19:06:28.683845+00
aa9ea515-00d3-406b-86ce-e0d78cdbba38	Coded lyser	reagent	Mindray	\N	\N	15	5	t	2026-11-03 14:47:12.838474+00
cf5815de-94e6-426d-8eca-594e2ef0f803	ALP	reagent	Mindray	Alkaline Phosphatase (ALP) Reagents are liquid, ready-to-use in-vitro diagnostic kits designed for clinical chemistry analysis of liver and bone function on Mindray BS-series automatic and semi-automatic analyzers	https://vwnytyrujcugvpffdshe.supabase.co/storage/v1/object/public/product-images/e742cc1b-aab1-4d29-8901-3cc6daff0668.png	15	5	t	2026-10-15 10:18:36.162278+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, qty, price, pending_qty, delivered_at, product_name) FROM stdin;
cf88fd16-882a-4c97-9946-baebaeec8e68	b8dc1b57-18b7-4f58-a906-a6f699a11711	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	5	380.00	0	\N	HIV
68f7e64a-4f4c-49e0-8118-b34388a7546a	a7444737-9725-4c82-a742-028e54a28d9c	154fbfed-8711-471d-badf-6bad744ce246	2	980.00	0	\N	E2
c46cf86b-0ebd-4c72-bd61-252bd188e77f	a7444737-9725-4c82-a742-028e54a28d9c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	2	840.00	0	\N	PSA
7dbe380d-d578-4130-8d3f-0d3218445360	a7444737-9725-4c82-a742-028e54a28d9c	12524346-ae4c-414d-a09c-d1fd4640cb50	1	890.00	0	\N	TSH
85b55316-d386-428e-b903-064b6af26a36	a7444737-9725-4c82-a742-028e54a28d9c	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	1	980.00	0	\N	Beta HCG
73d0eb2d-aacc-4b1b-92e3-19a6891bc084	a7444737-9725-4c82-a742-028e54a28d9c	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	2	840.00	0	\N	HBA1c
\.


--
-- Data for Name: order_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_returns (id, order_id, item_id, owed_removed, returned, restocked, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipts (id, receipt_number, customer_id, amount, method, note, balance_after, created_by, created_at, reversed_at, reversed_by, reversed_lines, credit_after) FROM stdin;
ee0c75e3-6de6-44a0-a12b-f4fde31eef17	1	bf086b6d-d8ef-448e-981b-a3e3a25ed86b	1900.00	cash	\N	0.00	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 09:47:55.885325+00	\N	\N	\N	0.00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, order_id, amount, method, note, paid_at, recorded_by, receipt_id) FROM stdin;
b6e6809a-7353-440c-95dd-1d22856e3c28	b8dc1b57-18b7-4f58-a906-a6f699a11711	1900.00	cash	\N	2026-10-19 09:47:55.885325+00	34cb4aa6-890b-4397-bf22-95f48620affa	ee0c75e3-6de6-44a0-a12b-f4fde31eef17
\.


--
-- Data for Name: pending_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_orders (id, customer_id, salesperson_id, notes, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: pending_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_order_items (id, pending_id, "position", product_id, name, qty, price, held_qty) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, created_at) FROM stdin;
ca75deab-00dc-490a-ba3c-06c8bf0c6ac3	a6271f16-534a-4325-aee1-5ed0ab3eb261	https://web.push.apple.com/QFMu5hVnH9vlm1yQMCWRTQ1rnB3xkpCYQcMqCp72VZhuyMi8EVXENP2nOIt4W3bz-qX-VYX4y2OHOCBpL934Wg9uMA-Uc5dvgQTbIXK9MGzuEeFqnRk-cR6CPdqp-_MIS1Wq71skGvCr1rbWxPN1alkXmum8aJGhk2UT8ADuH3g	BN939MYPpA6Xz5qAmCeYUSXUo7KPjtbub9KfyEWktdLDUcKS5yYdBTycLEuvCk52AqytIQ24M7r6JUjx_8X0lCc	pVpvzZ00jJm_m_QxXGLl9g	2026-10-13 07:06:59.034663+00
844239ca-f5d9-459a-bc8f-e2cfea9141c9	a6271f16-534a-4325-aee1-5ed0ab3eb261	https://web.push.apple.com/QLTGuTDEVyWbvoFTbRHShbHZk9Cr6ICSC3tRx3D36ulZ57YQ5SEMB1KngBdvQfwRDpAcW9RheoAepaJPJGoliEjBid73BNfHvkazMuhY9ju3KNwgLqYamEaHtzD1ogXKjUqFDnDWXPhsVKyUep6vSkBVjlLwL8xyplVeYv_XP8Q	BNHLV8P0adhsbkHVl_6IM1kCXQemL_TyMpJl0OXaxlkPDkMxnboNLRu8gfrHxai5M_dKomjhJUlzSkloiL95glU	5PalugZEyVw03UuUZrbPxA	2026-10-22 11:40:25.91643+00
3d0d9c06-7407-470a-b9c8-9f2279ab4b8b	82735742-c8fd-4042-b60f-67a9fca0d0ab	https://web.push.apple.com/QGOmkhvwkNrn81coeFec78B_C8OY9x2_IJ_qNP5x81cSxrhUar5Ku-dU9FCuOmy1X-7nQvuY5h3pKgVPv5qpY3Kiy73SNppYfwut7nVJcXBxb3U-ePtw4clrbQM7qHD7FYnuNIvFpreYpOb68ji7zrV68Kl6YGq0WBr9pJ3PHZc	BIHwtjIzxXF-IazabDOvOjAYALa0IvNu6DtRiSWKT3HkmEdc9YLLO5P85Ix7RoS2Td00SR-V2mJ3oTsl7zwZjIM	9c06H8qraEx2XQ1D4OyYzA	2026-10-16 11:18:28.120438+00
5bd3e183-1e15-4e98-acca-f0eb8c96d4e8	34cb4aa6-890b-4397-bf22-95f48620affa	https://web.push.apple.com/QIbsVavBxNfvkhKIAdG0pw1pXpnn5fBDlAK891l0y7OKoR1XpptcRfxjnB6a0sbAw0iWapaHUmM_SJD5JSFXDXDJthSS47Y9yFIVkHvMyrgFGMLAWYjDkN_PhzUsJl7PYeJb1lki71LHllQVF5bsZsdZ0mPzp80dU7ZKU9s8AGg	BBHoQ3_4OCcVfYGeWETF_kmhV3KgE7RWmjZufpkvuCTVvKL9Xzy-cBTlBmtKvrI5IDGW07KgL02MtEWyIPwUEFA	l6GKIJqvHDraBMBgXTIDKg	2026-10-16 11:19:40.582574+00
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refunds (id, order_id, amount, method, note, created_by, created_at, refund_number) FROM stdin;
\.


--
-- Data for Name: stock_in; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_in (id, product_id, qty, supplier, received_at, created_by) FROM stdin;
79186191-7a0c-4466-9547-70f1fea1cf12	ead2b374-e435-4025-bead-d804071dda77	3	Opening stock	2026-10-12	a6271f16-534a-4325-aee1-5ed0ab3eb261
4c7c3454-e9c0-45c9-8317-c18d45cbdba4	d6d4fda9-6087-410a-8bc9-0a5622f40e32	8	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3ecfead-aba0-4128-9609-00c16c978de2	cf5815de-94e6-426d-8eca-594e2ef0f803	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
05af52c0-8ccd-46ff-9890-2952bf0ae825	9ff4f240-9f00-460f-87f1-e745c6647e36	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a50cd550-1894-485a-aeea-b3bd16e2edc7	91abfef3-d9b8-40d2-9109-a66e97f2607c	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
072e774b-1b90-41b9-861f-98cf5f1aa622	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
324b646c-05ea-42a7-b70d-19a43fe0d773	51291b09-5c9c-4ece-b5ab-caab1507e9e2	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3be614ba-751b-47ea-adf9-36d933870266	e32d59af-01ec-496c-9be5-ae5285d46a1a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
39806749-2dba-4395-9c80-89c0c3f3a7b1	427a9551-fb8c-45c7-9076-19c9ee015002	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4865b5f4-bb47-48fd-9249-bbf82bc118a5	9c309e3f-ca58-4ed7-b6f8-1ff19b498864	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
500c027a-40ff-400b-bd5e-d5539195b3e4	6452048e-904a-481d-9879-dfbc9b3b89ba	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
92b8d883-0172-4f69-af29-10c9f3e30c66	5a58c58c-8ed5-4082-a9e3-3d91b026c57d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
dc40bc9d-7e92-4956-8bc3-185dd104449b	280a9428-5bc6-41a2-beee-924f8d94d88f	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0fb4a605-0a89-48a1-bcb4-be2b30392192	81ef7ace-0699-42db-85ba-4c050a08a008	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
17d49884-19e2-4e49-9b01-8b5835fef790	c8247369-36e0-4af0-99cc-13be486f3c9d	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
971cc0ca-6a10-4f62-ad7a-a26d8dc8019c	2cf77d43-efc0-4773-9519-610d10df99b7	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9a4c5e3e-5fde-4113-b0f0-cff92f129de5	6d4f3554-2ee0-412a-af30-471500879cbf	10	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e2f03c72-0f04-4e76-ba87-606d83e34527	171c693e-768a-4e98-9fa7-b78f91a85944	5	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
d06341fd-3a82-46f0-a2a8-17dc78af33ff	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b0427d72-4f00-401c-934e-99a24062b261	cb424877-c00e-41ba-a9ab-94854c930087	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2f45e64e-3eae-42aa-afeb-6c5714144b1a	a9061735-ec3b-4533-8124-e44acec27679	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
84ce8bfb-4b7d-4844-b26b-bc9b5356a71f	bab661ed-e425-4095-a183-0c8b35a9a73e	20	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2848c616-4b83-4c2f-867e-dc68821be215	ea5ebf85-f433-452c-ba48-3f8c921b68c0	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6dbcbbad-96d4-4380-8e68-629206d01843	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	22	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
167a57df-ab76-4257-98ee-e15fa4c21828	fab99f9a-b0b2-4e61-989f-5a2da8585cb8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6e14224b-5623-42ef-840f-a590227e5a0b	3e76ff9b-1c77-4346-891b-0123b161eac8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
70bcecb0-b21a-429d-a70c-d792e727c22d	653d76e0-0733-41e3-8620-8901b926557f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
af002da2-2679-4845-a840-b115da050a49	421af267-9183-4ddb-a550-00597fb5a6f0	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9be88fd4-f2b9-423c-bb24-052cb6af894d	64b67e4d-cc43-47ca-87aa-5ba976f98625	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
343d0571-259c-41ea-be54-dc7b47c0c03b	5f57a013-29c1-4526-b33a-dee64e43db66	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
eaf2ac0c-6dae-4bfe-8085-497961868e03	bc6e03e2-4719-41ca-ae33-56363faf99a3	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
aba57409-a220-4043-8d0e-78bae4f1194d	1bbd62da-cf4f-473a-a6e4-1b76dae811b5	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
61e10487-7349-4847-b243-68851c083c87	6c0ed636-bee3-4945-ba22-9947e85b0e8a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
45f7e012-070a-4161-a2eb-334bcd0b297b	c4ada7ad-90dc-4f0b-80c8-255fb280929f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
569b6899-8efc-4f6a-8c7d-4aad438723fb	5dd86b23-1a0f-4610-b26f-1844b931e8cb	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0169681b-f745-42a2-be65-d9639a2e7213	c4be0085-5b40-4025-8c3b-daaa440d0605	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3c33fd2b-7611-4052-8676-03b246d1a415	2b78a00f-31f9-49df-bbc8-6a974284d9b3	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
c5100782-71a9-440d-89a9-c964c1b4ef65	bf552471-6e68-44ee-87c9-d9fd808c3f05	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e6b84ff6-95cd-483f-be65-ceb3a33eb3e0	c7d35921-00d7-4dd9-99f3-9d97185c8190	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
089cffef-e572-42c3-a34a-587b9bcf22b6	5dae3134-fa21-4b2f-8ddf-a1570bd60b39	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
5b796233-d068-4f43-b08a-e837a0dcffb1	04e87bfa-87b9-4bb3-ba33-679389a8fac5	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fde28b62-89ed-42af-afd2-39ae65af0cec	2a93e8fb-51d0-4098-8240-98a251b14f1d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4f8e0a1d-f6e7-421d-843a-9f14d9dd8473	cab8db31-f31f-433f-8bf2-8f551509c2f7	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
97658f0a-84a9-4a98-ab9f-22a13d00cdc2	d95e9245-a421-4351-89a2-6c363c15c948	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
cb813698-c635-4465-baaa-3d300ff265eb	b9b11539-9378-401d-b02f-1a6c57468a00	5	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9c37b039-c385-417b-8435-a159b3074422	7fecdac8-2555-4a55-972b-e44c988f2e3b	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
60663f72-fc34-4d9f-ab60-7ef356e5ac0d	5f6badbf-8cf8-4416-9bf4-873503e719c5	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
d39b143d-1026-4f6e-bb4f-3b1bcce0a7b8	308fcffa-e9b6-4762-a000-74f95c9ca638	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
1ea1c9ef-16ff-48f4-96f8-f80b89532f92	4cd01e41-701c-48c4-991e-459cc8e31a3b	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3da8523c-0e5c-41b2-8b71-6c11dbafc0f4	d5ef0c98-1636-44ab-beb9-00c32af409e6	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4f30fd94-a66c-480e-a799-a839b70d9ef9	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
08925466-7de9-46e6-a9f2-5dc600709a6d	659be18d-7cb2-47fa-a814-6d48cc07b97b	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
9543b91e-cee0-4dbb-a94b-2ab7e9f6d7ce	65f2bdb9-292e-4f42-87af-ba69db497a1d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f7d1a290-78b7-45f1-a42b-eb48451a600c	461e45a1-6171-4515-9ada-d619ef45641b	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f27fb801-a6a1-4fb8-b540-bac1b2fc7d43	2a0b04c3-f851-4a67-9850-2fbf78c5e078	44	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e736fe9c-afa0-47ab-a383-3bf5f1988891	2ff86e38-152d-49ab-801f-dbc3b8f682ac	20	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
dd5b6e25-b627-4c80-aca9-257be59c8b6b	c4e57f6d-25dc-4abf-8212-37351a30f621	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
32b6b8c6-d53e-405f-86c3-7fd090f97213	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
876e9feb-d5ce-436a-b9b4-be0c34639e97	051566a2-cdd1-4edc-b86b-afc306c0f1ef	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
5937c5f0-a259-4194-b4d2-623bc0da752c	f2b1be08-5c83-4eda-8b9f-6ea582926dc1	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
7e2244e6-101d-4fac-ae2d-0a0e339de03c	34de459c-89d8-4821-9511-5b271b020f1f	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
40deab5f-8bf6-4fcf-9be5-6ee7abb73f11	8e99c78f-3a46-4b61-84cb-e621621ccb57	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
99172a19-8570-4b86-b24d-800e0638e40c	3c9fc04b-2f30-484a-9889-9236bd4342a0	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6413a0cc-5757-432e-b466-267a9f8143d6	056fe8d8-9df5-4505-9a85-faaaf1cd5377	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
3d5f2544-aeb3-4e97-ba8e-a2b9c405864b	322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
6a2030e8-7545-43c6-851a-7f8cbdf0b75d	75adac4f-8200-439b-8426-0d1986416946	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3bf06c3-8196-421d-b084-59e850e918ef	757ad4e5-8fd5-41a8-8141-bc0909726064	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
308aaffa-b94e-4341-aa46-726fe2ad4da8	cdfc7193-716c-401e-987e-ce20381b3e44	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
91d6de20-bcbf-4c6f-927b-9283a47e2810	d64307a7-c776-44e1-9823-0a94a43d9fcd	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a5c3ed8c-49f2-4010-8b21-aed93dfb495c	190becce-9184-429f-b602-55c7beecea24	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
81b1eb6d-156e-4209-abfd-6ba142212101	a1d9955d-4411-4f64-9dd7-b460068d52bc	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
38c661e1-b05d-4185-86e5-d54672f8eab1	cba33b9f-880c-42fa-b4ff-bf55a415bfb7	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4a527ff6-bca7-4467-a4ac-67222e3fc066	d4790878-c6c0-4c47-8c42-d8fdee4727d0	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f1061a6c-7246-40a0-be24-ffd6bb9f50e8	e43b07dc-3e00-442b-8ab0-1b78e55d200e	6	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
081b926a-235d-48b0-aa27-767cf6c62e0a	26d5d1c1-9d87-4970-97e6-57791b50c3df	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
475e7100-bd24-49b5-a661-2e0afab5dcf8	f6f3649f-2f07-4c67-9943-5ab1429892e6	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
4d4215db-2c63-4831-a0b3-059939b1361a	576cd245-ef27-4989-8960-f52085ab307d	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
ae0d333a-ee64-43e2-81e4-77b2b60c4ed2	1c945adf-e636-446a-a0a9-1f3a712271c9	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
68bd7870-e1d5-4455-ac78-0c55879d1200	60c5327c-1e65-45be-8e6c-d466d560f1f4	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
29df2627-fe6a-46d8-821a-b1aa15167e88	ad8ca44c-84e8-47a9-869a-0cb70f002019	7	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f906e05d-f2b4-4003-8532-4ed70569e6f5	14192d9b-42e4-43bf-b319-4cd7584aa3d8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
43b2c462-f3b6-4be8-b8e1-433a0adb00b1	def0af54-5508-4904-8e51-c0dbf72a1618	17	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
118637f4-c040-41e9-82aa-214a90cee714	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
57c8eca3-c0f2-4bae-9fce-32dcce8d7b81	491bd73e-fc85-400e-beb7-c0f433899ed8	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a09aee42-ffec-42c9-a532-a75a7840b79f	acf4c443-9c3c-4c75-8886-738a9765d34a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
98614ced-241c-434c-9303-bfb04d6a7f53	98816970-f9e2-4868-a95b-873475f0db3e	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
045ef821-55e5-48b1-bf95-7e33df7bd3f3	61dec910-f577-481c-93ef-f832bcec3d9f	3	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
ae54c3e9-8b58-4003-a364-eb0ef70ebc38	7fed6899-c746-49a4-a2da-cf871ceb495f	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
b46697b0-f894-44b7-adaa-046ce80d3b70	5b736c5f-3c02-4672-8497-7dfc17b49a80	2	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fcab40fc-819d-4d5f-9218-776eb4687737	313c3a6a-b5bd-4b67-b3bb-9552f7207c59	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
80575a80-bdf0-41af-b5d1-d9e2476ff597	05e53106-69b8-4682-a6be-b6de4bd64000	10	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f6c66ee1-e252-43e5-9714-c5148b2facf4	99777cff-18a4-4e87-bc75-988d35589c33	16	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
fef1d322-e0b3-4da9-9ad0-159bac723386	d4185435-b8a9-48bf-b7b1-7446245b35ab	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
2f5f0856-997a-47db-aef5-ef9ab42455fa	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a8260762-933a-4566-85e5-61eae3e79dfd	59c06c74-f342-4be2-bc93-547b7f242c03	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a13a43eb-3459-4840-80cd-da7753bac51d	5ebb6d12-aa2b-4275-b322-949e5e7cc086	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
e7489add-c73b-4911-b75f-60a07796a9cb	41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
0f6ef486-38fe-41e3-a3d1-5b82c9de50fe	9db7aae9-12d8-4716-aff7-0532026f939a	9	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
1fb4b3bc-5d6a-4de3-bbda-59d7b7513de0	ec733761-dbcb-4ae3-839b-8f759f29057f	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
adc7d873-10f8-4376-ac2f-a5d2ff49ab39	371b2c03-2b4b-4a87-87f4-bd2694338ef5	4	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
a24bc1c8-f661-47c7-b988-8a6125607789	1cfbbd77-1dd6-41ac-b603-35af72ec737d	1	Opening stock	2026-10-15	a6271f16-534a-4325-aee1-5ed0ab3eb261
f0d20f88-efdb-4c85-977a-769ffd8cab24	fa3c9366-9b08-440c-8725-c5180ae578ee	60	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0ea97be4-762e-4dcc-bf5b-9164e964eb6e	a7206327-20b6-44b6-b489-d2f563ee49b2	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c4b8816c-365d-4263-9091-c4d49f01283b	feed7224-1883-4dbb-87e9-244150e61d54	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c5c62af2-ca25-460f-98b8-37adea874c3d	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	27	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
8a3988f4-2192-4c1a-a234-bf87f915c909	731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a71965b5-704c-4ad5-a207-7fcefe3e19e3	ed335ad7-006a-4922-ad15-53f8faa37e4a	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b70fb650-b812-4d81-b6f0-564447fbb114	d359c066-20dd-4f17-baed-699c38753958	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
10b52c4a-7f8c-4b2d-b40d-06e527de4ac9	0f537939-ec3d-4520-8ec6-450b21480858	15	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
932975aa-2de6-46c2-800c-700597d64693	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	42	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
83d22553-a49e-4360-8856-c5320ba88c7a	d3992ca7-83aa-453b-a8d0-21d9644f6782	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
939cd3bd-a3d0-4159-bbd8-b62ed688d822	daea334f-45d9-498f-91c5-c57769160d0b	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a03bc520-1560-4167-b9a4-d055d01235aa	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b3a0c4c4-41dd-4be3-8c2c-c7211c240dd5	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
831d7775-35bc-4951-b897-ce534528758e	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
278ce567-0c61-4ccd-9f45-a9e1d6eca771	c02fa806-d252-4315-b4ae-b1ea0846c420	16	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
780a6a13-dc74-4990-b1e6-1da8c3399cd4	613b356c-997c-425c-98f3-876bb2203c6a	7	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
480c3547-9c1e-490e-90e3-8863648d8dcd	0ded23de-1d23-4279-b783-1e5c5a59ca5d	7	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
56fc55c3-543c-4293-85eb-12c0b5df9367	b5fe9c12-b945-4aec-9049-39a8b9159733	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
944a4edc-0958-49f1-a2b3-8deeeda7d5d6	3572f4d3-23dc-405a-a94e-3fa793df5fee	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
728addc7-f5a6-4355-8ef3-e997b34bf2de	bb775507-b788-41fb-ba00-660b1911bba2	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
655ab62f-6fea-4b04-be82-adc14b8f286e	b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	68	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5c7e1734-b2fb-4ab5-9dd1-2f5ee7228e24	ef7a13be-5ef7-4044-a641-60561d491a66	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9158fb42-2768-4d31-acea-ec6524543749	28103a7e-6f63-430a-bac2-a8c6eef4b4e5	4	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
28f6a5aa-bdfd-4ae2-94dc-10fd0fd2d605	9b2a4a10-c691-4cdf-957e-78ec49a74c7d	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
327ef374-9d23-4e6d-befb-dc584b8f3675	56cdbdf2-3b93-46e7-9f90-83373145f827	18	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
bfd49a35-b040-4f54-a5d8-ab1691a971c1	1d462684-8f12-4d3c-8828-8b4f20f01e28	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
683e30d0-f58a-4b4e-b370-b011795b1dcd	4a0b448d-3fb8-4474-a9d9-267f5319518f	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
d15bc34d-0286-4757-b9ac-9c4042c73d75	63e1b692-a6ed-4edf-8373-9349000b5f5e	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
da3f4e65-bbfc-4b47-aa65-11cb0f3a7120	f697ee81-89c0-4297-a5de-62ac36f325b5	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
186b2e51-650b-4955-a05e-7ddd469ddd8f	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	52	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0fc12562-3229-4cc8-b37c-b727bca6ad0f	42433484-7a92-4459-9509-536e55910c3f	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0f70e1b6-7c39-4bee-be0e-db1692949c0a	9d3efcc1-82a7-4697-9aca-9c11c4a31037	200	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
3ba202f0-2f1d-491e-912d-4c7f4b153165	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	20	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5a164b5e-1c67-4bb7-b1e5-2a78c6e11439	b50611fb-eeca-4b74-a02a-91e2ea2d9846	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
ad794469-4905-490e-b0e2-03ce490239f8	154fbfed-8711-471d-badf-6bad744ce246	10	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
e7ca05af-920a-4312-807d-d14e03723f9d	2f1bb631-b9aa-435b-9217-341aa3fe9ada	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a2ffaff9-0904-47b4-8ffa-293c0e5b255f	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	12	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
dfd5d96e-20e5-42b0-9c0b-8d73ee2935c5	1df32cc2-2332-4453-9847-ad60db9ed220	13	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
c967ebfe-6e3b-4c24-bee8-40084e8e0ffb	d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
155afeb7-1b3a-4c9d-8146-df15476a0929	e1d8a6b9-b965-479f-a777-f85b0df18c59	24	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
b1068c37-31f0-4e52-a896-e3923431f31f	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	16	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7af6808d-daf2-4bbb-9947-a1931c79b7ca	7640cb52-77e0-4374-a235-bdb6e0d41503	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
62b4c693-815b-469c-9204-4abc12dda5f0	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
df926210-4524-48bf-a5d2-d26f273eb814	12524346-ae4c-414d-a09c-d1fd4640cb50	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
88d4d842-caac-460b-98dc-a5c7f6cee8ea	fda6810f-87ff-4863-9c2b-e0213ac55cc8	9	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
6d4243f7-643a-4a10-99c0-5d5f4e1ef120	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
80c03a04-1099-46d9-8ccb-df6c483520bd	38150feb-b79b-45e8-b451-9a1aeb96af06	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
83e06e6f-a216-4a39-b517-3019273d7749	f5336cfc-123e-412b-9128-4aab6543591c	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
e209644a-8ef2-4bd6-8844-5a1ee0bf588c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	67	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
3eeea862-ac92-4e79-8087-065405f8c882	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	13	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
5cf44534-2523-4b40-b077-a6f9409c80f5	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	32	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7c3e0fa5-15ba-4824-8369-0d125dc45899	f1aabb46-04f7-4c4f-83c0-d532953304a1	36	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
04a66bca-4b1a-43c5-abc4-c7497b6e7f14	48c8796e-48a2-4355-b4e7-16bce21b2710	23	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a575e709-0194-4957-ae9c-328bac5d00a3	f837a23f-6bcd-4d96-9291-bba4d69caf3c	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
94bc1afb-d07e-4deb-8a35-82193b48f6c7	6faff9cb-851d-4fcc-8478-a18c83228de5	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a8aec445-b83a-4da2-9d26-b8a1a1031d70	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
d9da2076-5a2e-498c-8424-fd4b907c3a59	ba28ef00-70b2-4902-94ff-cd4545a1e506	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
ca824ccd-9a62-4b65-98a6-50804b28d664	79f46b6a-9be6-4131-a71b-79f864b7efe6	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
02484599-2c5f-4b18-a496-79516b57f665	55170fd5-00ce-4241-9620-ee6dced18987	2	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
30bb15c2-ad09-474a-b811-8212bbdd9020	0a2d780b-6404-4826-a300-d6c89964ae40	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
aee1b326-8900-4428-a4ac-2a3fe790cd92	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	6	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
7b4fb20b-562a-4fdd-ad44-5385ecb62eaa	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	15	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9be207e0-ea42-4506-aa59-4ff4ec89135d	2d096f70-6b8d-4a45-a9b9-0388c96a945d	1	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
952cedd6-99fd-4815-82a1-d76273b61fb3	9cbfc261-d617-42b5-be18-97be0da5540b	85	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
9efcec25-b85b-439e-ae0c-1dbdf9dfcabb	5a072e55-b0c1-4102-9b9f-6e786d9a2343	18	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a9cab9e3-370b-48a5-887c-480e85fe1905	94d568da-7421-440c-839d-30290b500f97	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
1c0a6628-e265-479a-b9fb-97bbf068539f	2506f42e-d3d7-41f8-ab97-0473118c3630	5	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0798e611-4408-4563-bc95-dfa3bc5caf83	49147609-1a68-4612-a2a5-3845b60a2d38	50	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
aa5547c0-3680-4233-957b-0d501dfb2a3d	2589ccdd-7774-4eb6-952f-aff007ddc585	500	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
00fe6107-bea7-4b2a-8016-58b5a9215e67	5325af28-0ff3-479d-ba25-2507b2dcb708	1000	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
0e7607f8-d698-4b5d-81a3-a9a2be2deece	598eb297-3ff5-47e5-8cb9-5904f6bbf516	24	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
bff73855-d302-4677-8cd3-d947511408e1	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	94	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
a39244a4-109d-45a6-b6b7-1631cfc9d9db	571fa9c2-9b3f-4171-aebe-a02e9a9e79db	3	Opening stock	2026-10-16	a6271f16-534a-4325-aee1-5ed0ab3eb261
eaf48bcc-82ed-4fd7-9119-11c98042aecb	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	1	\N	2026-10-16	34cb4aa6-890b-4397-bf22-95f48620affa
b7ae2d03-58ce-4c3b-b18b-37d3b8642f01	0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	2	Opening stock	2026-10-16	34cb4aa6-890b-4397-bf22-95f48620affa
16dae8f1-0060-4b23-8321-10afb7545eca	929c42a1-1e18-4063-9cf4-f75586cdd858	2	Opening stock	2026-10-19	82735742-c8fd-4042-b60f-67a9fca0d0ab
8ced2586-8d2c-4408-b979-c809b23aa722	17c581bc-76b8-4beb-8a2c-e00047754559	20	Opening stock	2026-10-20	34cb4aa6-890b-4397-bf22-95f48620affa
abb2caf4-9586-4cbb-b95b-a4955a7359c7	f1bd219d-1c82-4b0e-9f30-0d6518f99b92	21	Opening stock	2026-10-21	34cb4aa6-890b-4397-bf22-95f48620affa
c19d17be-dd61-442a-922e-4f79fa20ef4f	697b3608-ae6b-4cc2-bf54-4826386e5ba1	6	Opening stock	2026-10-21	34cb4aa6-890b-4397-bf22-95f48620affa
1c011462-b8dd-4dd9-8d3b-2058a883105b	9977e869-da83-4601-bee1-77d5e29f1ed5	1	Opening stock	2026-10-27	34cb4aa6-890b-4397-bf22-95f48620affa
148392f4-a2d3-488e-9257-f980fefaa6ed	561a9cbb-7026-4bed-becc-73e235cb6f79	1	Opening stock	2026-10-27	34cb4aa6-890b-4397-bf22-95f48620affa
6cd151b7-aeed-4e21-8b06-9c82b800034b	bd357ee5-7fff-4f95-8ca9-144fc25b9d4d	10	Opening stock	2026-10-27	34cb4aa6-890b-4397-bf22-95f48620affa
5b0b753e-4094-4612-89ad-b09b0e6a96ef	ee10fbe5-4a96-4440-a3fb-b29fa0de930b	10	Opening stock	2026-10-27	34cb4aa6-890b-4397-bf22-95f48620affa
4a0b77e5-755f-4a5d-87a5-24373d9014a0	e059c881-7d54-4209-b77c-89e0aa17f462	2	Opening stock	2026-11-02	34cb4aa6-890b-4397-bf22-95f48620affa
985f1e2d-7204-4d32-808a-c4ce488521e0	3790e5e0-27aa-46dc-83bf-2e2fc39ed784	1	\N	2026-11-02	34cb4aa6-890b-4397-bf22-95f48620affa
b8f4cda0-49ee-4993-b714-e58881535507	28ae0672-5605-420e-b7d5-2143099672a3	2	Opening stock	2026-11-02	34cb4aa6-890b-4397-bf22-95f48620affa
73c6b18c-e3e4-4213-aca7-f02ace2a8c1f	467055cd-1828-456d-a743-8a6f62e4ce28	8	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
ac45fd68-fa04-4bac-80e5-01e57d87cea5	8baabf93-fdc9-41ba-b8d9-799e11986431	1	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
60c52f54-c403-4f87-beb6-e65c1b2dd682	c73c4429-709a-4c4c-9071-5b1e701f82cf	6	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
a898e908-1f22-462f-be64-feec573cbacf	12c37938-1696-4321-ae41-c4472ba319a1	2	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
2593058a-96fb-4597-bd8d-61611acf9da5	dc70ad7e-0402-4c06-84fe-4beb2fa3a36f	1	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
833f0bae-9a70-4852-8d69-8e7adda1295e	91abfef3-d9b8-40d2-9109-a66e97f2607c	35	Mindray	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
aec2d9f9-12dc-4415-a8ac-fa2b849ea398	52a235f2-a6a7-446a-b0ff-bdf02a6db56a	12	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
d69976d0-5da6-43b7-b7f1-b55a2356ba55	a552e2f5-77c6-4565-b54b-e657f0b975e4	12	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
43ec9fdc-cea8-41f8-972e-1b6954f810ef	47a585ae-b9a1-44d5-bb04-776aff161924	12	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
c35373c6-fe14-48b8-9d6e-7bcfc748ce19	e958369c-dad7-4aff-affb-4f37609e2b25	18	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
7494a386-4fc3-413d-83bc-d0b81d77bf5c	79d3a498-b877-4953-9d58-d7593e7228b9	2	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
2c81d0fe-ad93-493e-8590-82c733fb4c55	b5f0a744-b1ac-449a-9b48-4e01ef12dd65	3	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
3a05a0fc-02be-45f9-9af2-c112cdf01802	fe9b3591-df32-4986-b2ff-53f59d5322a8	2	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
be1d179b-ab27-4ece-8049-dc31b839a9cf	12a3cecf-0723-4dac-8edc-c61f04338e8d	3	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
29f9fe22-c4ae-4186-9f78-417d598c90d9	37d50b0d-a5fb-4240-81f3-f704b905cefd	12	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
a5f9fae3-3e2e-47ba-a23a-7f99b82175b9	92a3d14a-f626-4345-8abe-6e843aeb7428	10	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
28dfc057-225c-4239-9457-7df0c13b8f63	3a99f833-4946-4e84-9fc8-4e6e9355dc49	15	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
195e6640-0ed0-405f-b1fa-cfde6d76cc00	aa9ea515-00d3-406b-86ce-e0d78cdbba38	8	Opening stock	2026-11-03	34cb4aa6-890b-4397-bf22-95f48620affa
2858703a-532b-4a1a-afae-34b28fc4af75	74666bf3-cbf4-4bca-99d1-5cfda8c5ab88	10	Opening stock	2026-11-09	34cb4aa6-890b-4397-bf22-95f48620affa
5809a8a9-d6f2-433b-ab21-a1683f8c184d	75ffd9c4-f52f-4312-8858-63386f191793	1	Opening stock	2026-11-09	34cb4aa6-890b-4397-bf22-95f48620affa
e689f156-b44c-4ba2-955a-b77cfab45ae2	23f521a0-b968-4fa8-9de0-4e3668bb8e0a	10	Opening stock	2026-11-11	34cb4aa6-890b-4397-bf22-95f48620affa
e408fa44-e9cb-484d-b2f1-a0909feb27cc	229a0575-21db-4b59-ad3b-847e58391d35	3	Opening stock	2026-11-11	34cb4aa6-890b-4397-bf22-95f48620affa
8028a952-c73c-4d24-aea8-2190d2dd57cc	d4937cc1-d2c2-488f-bc93-36b8e0186036	2	Opening stock	2026-11-11	34cb4aa6-890b-4397-bf22-95f48620affa
d1358a46-184b-4017-bd62-229863d05f35	92d9c316-0bc5-45c9-904d-706f232663f7	2	Opening stock	2026-11-13	34cb4aa6-890b-4397-bf22-95f48620affa
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, product_id, change, balance_after, kind, order_id, note, created_by, created_at, pending_id) FROM stdin;
1d5664e3-e114-4d91-9c5d-0d6d6e7080db	ead2b374-e435-4025-bead-d804071dda77	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-12 00:00:00+00	\N
7b1fafd6-1724-491a-b253-070cf9774424	ead2b374-e435-4025-bead-d804071dda77	-2	1	adjustment	\N	Other: sold by boss	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:14:12.29217+00	\N
c5cf5837-70a6-4fac-9f28-1f6611c609c9	d6d4fda9-6087-410a-8bc9-0a5622f40e32	8	8	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:16:44.535088+00	\N
64abc2fa-594b-442f-bcad-c3360708db0d	cf5815de-94e6-426d-8eca-594e2ef0f803	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:18:36.41876+00	\N
16b2374d-4885-4955-9e09-610fd834320a	9ff4f240-9f00-460f-87f1-e745c6647e36	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:20:57.98406+00	\N
73942ac0-33c7-42c4-9e39-49c78bbe52ce	91abfef3-d9b8-40d2-9109-a66e97f2607c	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:23:13.341824+00	\N
7976fa30-e9f6-4dc6-95a7-49f0041e5846	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:24:22.226628+00	\N
88f6144f-01e4-4285-b1ac-58fbd61db39b	51291b09-5c9c-4ece-b5ab-caab1507e9e2	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:25:58.615783+00	\N
1b254707-54c9-4a4a-93de-1bb74b15cfd0	e32d59af-01ec-496c-9be5-ae5285d46a1a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:28:01.609741+00	\N
528a9a2e-496b-41b1-9a88-74a054a634e2	427a9551-fb8c-45c7-9076-19c9ee015002	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:32:07.155804+00	\N
802ecac6-cc6b-4578-bcaf-9822b156ba32	9c309e3f-ca58-4ed7-b6f8-1ff19b498864	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:33:13.400178+00	\N
523a8e77-f5ee-4a7f-84ba-96402d1b9192	6452048e-904a-481d-9879-dfbc9b3b89ba	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:38:06.406846+00	\N
f7ea004b-3e6d-4f4b-b52e-2126894aa22b	5a58c58c-8ed5-4082-a9e3-3d91b026c57d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:39:35.792907+00	\N
9d6d86e8-3e26-428d-8144-15f52d6ee0c7	280a9428-5bc6-41a2-beee-924f8d94d88f	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:40:47.695585+00	\N
d3f186bb-918e-4dda-935d-edfa7159866c	81ef7ace-0699-42db-85ba-4c050a08a008	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:44:07.803391+00	\N
a3cf6ed5-4119-4916-af5a-b9be249edeba	c8247369-36e0-4af0-99cc-13be486f3c9d	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:45:29.740931+00	\N
91da6700-443b-46c7-8064-ca5ef206624a	2cf77d43-efc0-4773-9519-610d10df99b7	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:46:06.554927+00	\N
28622306-091c-45f7-b91e-e82edd095f8c	6d4f3554-2ee0-412a-af30-471500879cbf	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:46:53.924006+00	\N
9255b687-4a77-4d55-9128-a0ec78a66f86	171c693e-768a-4e98-9fa7-b78f91a85944	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:48:04.386968+00	\N
c7f530d6-ad9a-43bd-b212-e58543f3a974	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:49:12.937227+00	\N
a2040193-198e-411f-9b82-e7c8bcd1655f	cb424877-c00e-41ba-a9ab-94854c930087	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:50:01.948199+00	\N
24c49d8f-9f2f-4223-947b-2b5663587833	a9061735-ec3b-4533-8124-e44acec27679	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 10:52:18.525726+00	\N
1203f35d-5491-4100-bc7c-db8bedf4554b	bab661ed-e425-4095-a183-0c8b35a9a73e	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:05:57.536919+00	\N
2b4c96c0-55ab-4869-be2b-0fb3056dd009	ea5ebf85-f433-452c-ba48-3f8c921b68c0	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:08:04.894889+00	\N
5acfc7b6-bc4e-4c60-811f-f55c7b3149f2	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	22	22	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:09:41.952869+00	\N
dba1c6cd-7559-437a-8ae1-361b8e40f7bf	fab99f9a-b0b2-4e61-989f-5a2da8585cb8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:14:03.599246+00	\N
355eaa65-481e-4cfb-b5e2-2b6fc3586dbf	3e76ff9b-1c77-4346-891b-0123b161eac8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:16:32.643717+00	\N
df5d08fe-7550-4bb2-bbb6-762f01956261	653d76e0-0733-41e3-8620-8901b926557f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:18:02.852007+00	\N
2ace7d52-59a5-42e0-a48e-d222097ce30f	421af267-9183-4ddb-a550-00597fb5a6f0	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:19:09.497528+00	\N
db037915-2228-4217-a80b-d2ae8c1d6ff0	64b67e4d-cc43-47ca-87aa-5ba976f98625	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:21:59.76094+00	\N
b5ae4a3a-266d-431f-8150-59313b397841	5f57a013-29c1-4526-b33a-dee64e43db66	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:23:13.941687+00	\N
985cccd5-8bbf-4ea3-a880-25ca1e532308	bc6e03e2-4719-41ca-ae33-56363faf99a3	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:24:21.620837+00	\N
b05a0502-4d3b-4ff0-8682-ad15a480963a	1bbd62da-cf4f-473a-a6e4-1b76dae811b5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:26:50.100715+00	\N
c473cae1-b4d6-4df2-afa5-ee561dd2bbb5	6c0ed636-bee3-4945-ba22-9947e85b0e8a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:30:27.75234+00	\N
126a5c7d-e572-467e-bc7e-ffec282f3bfd	c4ada7ad-90dc-4f0b-80c8-255fb280929f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:35:09.925411+00	\N
e04d004f-404d-44bd-80d5-4dba34e1889d	5dd86b23-1a0f-4610-b26f-1844b931e8cb	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:37:32.658791+00	\N
b3905f15-2bf3-4584-876a-a955ed9c7074	c4be0085-5b40-4025-8c3b-daaa440d0605	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:38:28.817446+00	\N
391fb9bc-d957-46ce-a0f4-3ca275d72de8	2b78a00f-31f9-49df-bbc8-6a974284d9b3	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:41:15.428713+00	\N
835adb62-df19-4dc8-a6f8-512de4717f45	bf552471-6e68-44ee-87c9-d9fd808c3f05	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:43:07.785748+00	\N
d3e2c591-52be-4bba-9ccf-9bc62c440781	c7d35921-00d7-4dd9-99f3-9d97185c8190	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:43:38.989417+00	\N
1bbd0637-fee9-4bdd-b88b-fdbed40b4665	5dae3134-fa21-4b2f-8ddf-a1570bd60b39	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:44:09.655478+00	\N
09d6b410-7177-40b7-8cda-7fce1146c8f7	04e87bfa-87b9-4bb3-ba33-679389a8fac5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:44:59.354466+00	\N
9bb96e5a-6bad-41cc-a10f-99b14980ae16	2a93e8fb-51d0-4098-8240-98a251b14f1d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:45:31.161547+00	\N
9f885a59-9e2f-4dec-b32d-8cf4994d2d83	cab8db31-f31f-433f-8bf2-8f551509c2f7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:51:31.447343+00	\N
9f42c85e-5b7e-4756-8513-a0ed9b3bf389	d95e9245-a421-4351-89a2-6c363c15c948	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:52:23.418291+00	\N
44a71255-2272-49fe-b230-8cdc6c4d1b38	b9b11539-9378-401d-b02f-1a6c57468a00	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:52:46.877588+00	\N
cb174aed-0aa7-4d5c-a7aa-7debfbf174dc	7fecdac8-2555-4a55-972b-e44c988f2e3b	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:17.657303+00	\N
c3b99081-15a3-409f-a0ce-01015f0fee64	5f6badbf-8cf8-4416-9bf4-873503e719c5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:40.283243+00	\N
148a3afc-c478-4afc-8e48-0f4d9d795523	308fcffa-e9b6-4762-a000-74f95c9ca638	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:53:57.9823+00	\N
20ee4c46-8fff-4419-a9bd-9549f00e28b9	4cd01e41-701c-48c4-991e-459cc8e31a3b	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:54:56.210398+00	\N
15572c8d-d657-4de4-905d-1d67c5499554	d5ef0c98-1636-44ab-beb9-00c32af409e6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:55:33.096023+00	\N
7283a673-e7ac-4850-90c0-5bff1195826c	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 11:55:52.096984+00	\N
ae350ed0-5be6-4aef-bb01-6145ac1bb1db	659be18d-7cb2-47fa-a814-6d48cc07b97b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:00:46.464725+00	\N
45729c40-9b20-46a2-92f6-9d5d58d7cdff	65f2bdb9-292e-4f42-87af-ba69db497a1d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:02:36.217299+00	\N
2d3c788f-0a20-4639-87f9-998742b36248	461e45a1-6171-4515-9ada-d619ef45641b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:04:29.527882+00	\N
d409ff18-b806-4915-bd5f-c02b2cd1fce4	2a0b04c3-f851-4a67-9850-2fbf78c5e078	44	44	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:08:23.222799+00	\N
06cc839c-e101-413a-bfb3-fe2f8423c2ea	2ff86e38-152d-49ab-801f-dbc3b8f682ac	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:11:39.939786+00	\N
f76b573d-9b3e-445e-8794-54934f36c11b	c4e57f6d-25dc-4abf-8212-37351a30f621	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:13:15.447314+00	\N
45fc191f-43b0-4ec1-9870-0b1f8fb3f264	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:16:49.598773+00	\N
374a3a26-6286-474d-b033-6ad3c302a8ef	051566a2-cdd1-4edc-b86b-afc306c0f1ef	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:23:48.591876+00	\N
a3f9fffe-ab0b-4f1f-aa4a-cc5ddf7b0352	dd3669d4-2f57-453d-a7b6-aa21012d7813	6	12	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:24:18.744078+00	\N
e2966a06-e5df-479b-b95a-55a24d3ccf2e	2ff86e38-152d-49ab-801f-dbc3b8f682ac	1	21	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:24:33.278915+00	\N
c4830510-3e3a-4afb-aabd-c03dc5191e57	f2b1be08-5c83-4eda-8b9f-6ea582926dc1	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:26:16.381748+00	\N
a90751f1-3780-410f-bfe8-a839ed46d4f3	34de459c-89d8-4821-9511-5b271b020f1f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:26:59.152921+00	\N
6ba92b0b-2218-4b89-be86-abc6ea17d0fa	8e99c78f-3a46-4b61-84cb-e621621ccb57	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:28:04.323414+00	\N
0e294ded-523b-4db9-adcb-c1f2ea08bdec	3c9fc04b-2f30-484a-9889-9236bd4342a0	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:28:36.037254+00	\N
8792f564-c31a-4a5d-80a7-186592705fc1	056fe8d8-9df5-4505-9a85-faaaf1cd5377	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:03.873261+00	\N
b0f4994a-e500-4370-9191-a74782da9d81	322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:23.622546+00	\N
e5380581-a8f6-43ab-9c6a-05d472007e79	75adac4f-8200-439b-8426-0d1986416946	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:29:56.154485+00	\N
c2e5a42f-b6c5-4314-a911-9f5cb8d65f8b	757ad4e5-8fd5-41a8-8141-bc0909726064	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:30:36.365946+00	\N
b84b58f0-1a51-42de-bb6d-0bc0c81ffacb	cdfc7193-716c-401e-987e-ce20381b3e44	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:30:56.292159+00	\N
03a0563c-84f5-431a-a288-823d8b8d185a	d64307a7-c776-44e1-9823-0a94a43d9fcd	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:31:16.206873+00	\N
40a49c8a-751a-42d7-a586-fa22c6896883	190becce-9184-429f-b602-55c7beecea24	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:31:40.624424+00	\N
871ceb20-159a-4977-998b-3b21d11e3f11	a1d9955d-4411-4f64-9dd7-b460068d52bc	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:32:11.197926+00	\N
29b306c8-21bb-41cd-b71e-677455082576	cba33b9f-880c-42fa-b4ff-bf55a415bfb7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:36:17.270806+00	\N
f7b2ec67-816c-4a4b-b978-5b4d21c7f1db	d4790878-c6c0-4c47-8c42-d8fdee4727d0	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:38:22.807798+00	\N
a21f3042-1e27-4864-af7c-c2a49dfc2620	e43b07dc-3e00-442b-8ab0-1b78e55d200e	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:40:40.220539+00	\N
49ca0cdf-ceda-4e82-bee9-328dea8bbdc2	26d5d1c1-9d87-4970-97e6-57791b50c3df	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:42:32.548036+00	\N
16bb6be8-89f8-437c-93c8-26d344353157	f6f3649f-2f07-4c67-9943-5ab1429892e6	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:43:56.548351+00	\N
e6273221-2b47-44e4-a20d-f2771bd15f07	576cd245-ef27-4989-8960-f52085ab307d	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:46:22.262119+00	\N
0264bdc5-3112-4cf7-bfbb-e83b384538d8	1c945adf-e636-446a-a0a9-1f3a712271c9	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:48:14.096528+00	\N
5cc93e09-0db3-4765-a924-a45a544e5389	60c5327c-1e65-45be-8e6c-d466d560f1f4	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:50:13.801932+00	\N
83884bf2-ace7-4739-9f67-8516b4265865	ad8ca44c-84e8-47a9-869a-0cb70f002019	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:52:17.507223+00	\N
0952a8ac-ca0e-4a52-bbed-18e1a2a33e72	14192d9b-42e4-43bf-b319-4cd7584aa3d8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:54:01.006756+00	\N
4c8c4c79-1d4a-4cce-a410-5dccbce6ea9a	50ab9fee-98df-4ae0-ac78-4cbbc592272d	10	10	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:55:44.466965+00	\N
6240c01c-ce39-4ee6-9569-93f8a01d621f	def0af54-5508-4904-8e51-c0dbf72a1618	17	17	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:56:47.232969+00	\N
18df09c6-c186-4cfc-8cbd-f34910a2b4cb	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 12:58:48.852895+00	\N
97f9f66a-658e-4bd3-905f-95aeae3c9d0a	491bd73e-fc85-400e-beb7-c0f433899ed8	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:01:16.607114+00	\N
1faabf66-8006-49eb-8d72-bed978a6e3f1	acf4c443-9c3c-4c75-8886-738a9765d34a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:03:01.342056+00	\N
e208c8fb-4fff-442a-b22a-89d5a23ac101	98816970-f9e2-4868-a95b-873475f0db3e	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:04:33.931128+00	\N
34fa8a9e-ab1f-494c-8da3-b1f6ae02389e	61dec910-f577-481c-93ef-f832bcec3d9f	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:06:52.385005+00	\N
02cdd717-684a-4a2d-8010-81e5ba391519	7fed6899-c746-49a4-a2da-cf871ceb495f	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:08:35.681418+00	\N
a839c873-a2c6-4637-9fd5-356fc85b4dc7	5b736c5f-3c02-4672-8497-7dfc17b49a80	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:09:18.916113+00	\N
bc5cd33a-ea82-459a-8346-30ae9534e743	313c3a6a-b5bd-4b67-b3bb-9552f7207c59	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:11:04.366202+00	\N
3bc5d049-2f34-4d99-8ec4-970170a5013c	05e53106-69b8-4682-a6be-b6de4bd64000	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:13:12.180141+00	\N
f0fde5da-864a-4aa3-bb69-d4b2a6f626d5	99777cff-18a4-4e87-bc75-988d35589c33	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:14:57.015913+00	\N
0e254a6c-c250-451b-a2ef-300fb3ae711f	d4185435-b8a9-48bf-b7b1-7446245b35ab	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:16:02.34628+00	\N
4309d138-15b8-481b-be8c-206f09e26bab	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:19:10.162089+00	\N
195119eb-5aff-45d1-9b01-a683b652bba0	59c06c74-f342-4be2-bc93-547b7f242c03	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:20:58.183658+00	\N
d22b14cd-fd16-4463-9cc1-d25cc8c32d93	5ebb6d12-aa2b-4275-b322-949e5e7cc086	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:21:57.233403+00	\N
9293f975-7bf1-441a-867b-4ec242771263	41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:23:29.167174+00	\N
6eb41013-46ee-42f3-8483-e91efc69488c	4fd457b6-2f0f-4771-b8fd-d54283355d9a	1	1	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:24:33.167517+00	\N
50bbe44d-8be2-4b8c-a1c8-8caad2871d29	9db7aae9-12d8-4716-aff7-0532026f939a	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:25:46.783427+00	\N
bd8318d0-bb8b-4fd1-a6af-4f05b9747d6c	ec733761-dbcb-4ae3-839b-8f759f29057f	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:27:30.010478+00	\N
d8dc3903-a4cf-4bd4-b449-73b4ad349fee	371b2c03-2b4b-4a87-87f4-bd2694338ef5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:28:49.996738+00	\N
4d28ea23-02c2-4980-9805-2b07c7453229	1cfbbd77-1dd6-41ac-b603-35af72ec737d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:40:16.980545+00	\N
d3a4ccca-a452-4616-8b2d-f3fe560fed8b	d95e9245-a421-4351-89a2-6c363c15c948	2	5	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:40:58.896836+00	\N
06e0ca8a-0dab-4ca5-9b81-5e0fb437eef6	7fecdac8-2555-4a55-972b-e44c988f2e3b	1	5	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:20.045874+00	\N
4190264b-ac75-4015-ba4f-d5f38d0c8ffe	308fcffa-e9b6-4762-a000-74f95c9ca638	1	3	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:36.58368+00	\N
e955d6e9-eec3-4496-8519-985dede857ce	d5ef0c98-1636-44ab-beb9-00c32af409e6	2	3	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:41:58.567531+00	\N
be76b756-87d3-46a2-ab5c-0d8ea051e021	cfbd97f4-63db-4d59-a335-c37e37750f8a	1	2	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-15 13:46:06.366686+00	\N
3deac078-3387-49c2-847f-e2c945af2fcc	fa3c9366-9b08-440c-8725-c5180ae578ee	60	60	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:25:55.426066+00	\N
ae8e536f-89be-461f-ae3d-3795860dfabc	a7206327-20b6-44b6-b489-d2f563ee49b2	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:27:37.56164+00	\N
01a2340e-7979-448d-be1b-5ec4f50bbcee	feed7224-1883-4dbb-87e9-244150e61d54	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:32:57.133409+00	\N
5bf3531b-5404-41ad-a3a8-70d042c953da	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	27	27	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:36:46.900424+00	\N
a531605d-f77a-41cc-9834-87003692fe07	731d3503-1fe8-4c2e-87a6-5fb5f9f0cf1b	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:39:52.5792+00	\N
6fa7768d-25eb-4386-bda6-2c9978bfddc4	318473b7-12f1-4a7f-ae4a-ab5e033fe6d8	-1	26	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:40:12.223541+00	\N
dcebae7b-5997-426d-9ce4-527971d475c4	ed335ad7-006a-4922-ad15-53f8faa37e4a	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:42:14.398541+00	\N
c7ce8ac8-aaa6-4a0e-84bb-c3fb1f24cc2c	d359c066-20dd-4f17-baed-699c38753958	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:45:27.149209+00	\N
f7620eea-3fca-4d70-b97d-950fb48a05cd	0f537939-ec3d-4520-8ec6-450b21480858	15	15	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:47:32.295762+00	\N
f31f9e65-0ff2-4685-b4a9-d824b5d1da25	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	42	42	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:48:41.125475+00	\N
7c150249-db88-4b5d-9b15-c927b31b9f8d	d3992ca7-83aa-453b-a8d0-21d9644f6782	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:50:51.617834+00	\N
949f926e-fbda-4dc7-85c4-f292ba0ac4c9	daea334f-45d9-498f-91c5-c57769160d0b	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:52:44.224183+00	\N
e5c3a42a-022a-489c-bc39-c0470e1a6ac3	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 08:55:51.694873+00	\N
b790b994-ba0a-4347-a226-66c3439f837b	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:03:08.565117+00	\N
b794e984-00ec-4b19-bcb3-9bb37b369d05	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:03:59.623732+00	\N
82a04529-536f-45c2-bdc3-6b96aa7b372a	c02fa806-d252-4315-b4ae-b1ea0846c420	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:08:25.671193+00	\N
819c8fc9-8c95-423a-b4cf-a2c45c589475	613b356c-997c-425c-98f3-876bb2203c6a	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:09:59.197722+00	\N
6ed0c437-54dc-492a-b1a2-0d08fb1830d2	0ded23de-1d23-4279-b783-1e5c5a59ca5d	7	7	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:12:15.949485+00	\N
40a10de7-07b0-4fad-a356-231e9617f9ab	b5fe9c12-b945-4aec-9049-39a8b9159733	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:13:18.191631+00	\N
f13aeb52-b8af-4d6a-8bf8-9e8fa406eb81	3572f4d3-23dc-405a-a94e-3fa793df5fee	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:14:51.719011+00	\N
d532df4e-035d-4d21-a10d-0f1da8b108ca	bb775507-b788-41fb-ba00-660b1911bba2	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:15:32.700862+00	\N
a03e705b-60aa-41c8-a728-6e93d1367d99	b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	68	68	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:16:58.562776+00	\N
dfcc3570-1714-4c7f-b80f-badd0a0af39c	ef7a13be-5ef7-4044-a641-60561d491a66	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:19:36.514642+00	\N
7c9e9383-4dac-4a40-91be-3ec63f75b11c	28103a7e-6f63-430a-bac2-a8c6eef4b4e5	4	4	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:22:29.264026+00	\N
94f7e891-c787-422f-9d29-5bb5da59a433	d3992ca7-83aa-453b-a8d0-21d9644f6782	117	122	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:24:25.086295+00	\N
2be70da0-4105-479f-bb63-6bc7395ca408	9b2a4a10-c691-4cdf-957e-78ec49a74c7d	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:26:12.380536+00	\N
ab9a12b0-7953-48c3-9a4d-13738da63277	56cdbdf2-3b93-46e7-9f90-83373145f827	18	18	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:29:58.216707+00	\N
35584b73-889d-4f58-af52-4bf5ed624d2e	1d462684-8f12-4d3c-8828-8b4f20f01e28	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:31:09.888534+00	\N
7f0e56e7-84c7-43ef-8fa2-66d0353ef0fa	4a0b448d-3fb8-4474-a9d9-267f5319518f	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:32:44.837015+00	\N
209d3fb5-b9aa-4cfa-88f1-58f4603279e8	63e1b692-a6ed-4edf-8373-9349000b5f5e	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:34:48.562526+00	\N
4f1a2fa5-36c7-46c0-806a-a9cf842454a2	f697ee81-89c0-4297-a5de-62ac36f325b5	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:36:02.915495+00	\N
52d8ba86-47de-41f1-aa7e-bd6426a1fca0	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	52	52	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:36:58.670777+00	\N
676857a7-843d-4334-940e-9a08d6fe2b20	42433484-7a92-4459-9509-536e55910c3f	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:38:20.649965+00	\N
b00ffef1-3a72-4318-af86-9f4cde4abe15	9d3efcc1-82a7-4697-9aca-9c11c4a31037	200	200	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:39:50.841446+00	\N
69716f9b-79a7-4222-b501-ac5dc701a603	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	20	20	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:41:42.818716+00	\N
5d0641d7-0094-4c4a-a006-6dad573e6470	b50611fb-eeca-4b74-a02a-91e2ea2d9846	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:43:20.639024+00	\N
e2044940-5e71-4de4-a168-55c3517c7756	154fbfed-8711-471d-badf-6bad744ce246	10	10	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:44:28.587121+00	\N
12a0c5a4-e81d-4c69-95e2-b7ff6f347647	2f1bb631-b9aa-435b-9217-341aa3fe9ada	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:45:23.247029+00	\N
4fe3a15a-1fda-48f2-bf06-2053aac9e079	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	12	12	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:46:31.782951+00	\N
6a10b3f2-f106-4824-b2ac-de2a4909f6c3	1df32cc2-2332-4453-9847-ad60db9ed220	13	13	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:47:20.287321+00	\N
f7fc3019-6869-4869-baaa-14cfbe2d73b2	d8a6a84e-2c9c-4904-b87a-882deb2ab7c7	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:48:15.048272+00	\N
f0e4563c-3b64-438c-965f-4f6124959c61	e1d8a6b9-b965-479f-a777-f85b0df18c59	24	24	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:49:34.544987+00	\N
2b6a243d-7e49-4df2-b38d-755760d00f00	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	16	16	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:51:14.325327+00	\N
5daebd62-ef82-44bf-a780-514b09298dc5	7640cb52-77e0-4374-a235-bdb6e0d41503	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:53:13.281167+00	\N
b296f55d-7f6b-489d-b5f7-8dff6fda5494	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:54:35.16856+00	\N
5d3550be-1817-4bce-8118-ddf250d42a06	12524346-ae4c-414d-a09c-d1fd4640cb50	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:55:56.633947+00	\N
d3156697-5bfb-4162-bee3-3449c478ba4c	fda6810f-87ff-4863-9c2b-e0213ac55cc8	9	9	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:57:21.216536+00	\N
bf691f26-3881-4378-be24-97753bda56ae	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:58:00.32373+00	\N
f9b40e3a-06e1-4dcc-8a85-3554648fa33f	38150feb-b79b-45e8-b451-9a1aeb96af06	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 09:59:47.711554+00	\N
c513967e-0443-4a70-8c27-361435f75423	f5336cfc-123e-412b-9128-4aab6543591c	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:00:47.249339+00	\N
34b7559c-74fb-4bbf-8e0c-7a2ba7fa7d08	507af4d6-75cf-43f6-a30a-3c118c7cd48a	67	67	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:01:19.240937+00	\N
c9ab1bc6-dd80-45d0-bcfb-7ee6fa4d8088	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	13	13	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:02:03.875897+00	\N
5eef7668-f2ff-4597-8cba-2f4aa1dc10ca	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	32	32	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:06:35.02952+00	\N
b0aeb07e-e1b4-4689-8eee-4539b31599fc	f1aabb46-04f7-4c4f-83c0-d532953304a1	36	36	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:09:22.540332+00	\N
27af9e52-47eb-4d07-975d-1a7a25e4e38c	48c8796e-48a2-4355-b4e7-16bce21b2710	23	23	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:10:03.162946+00	\N
5e3f3f7b-1c44-441a-be14-fad2c7cf7ae2	f837a23f-6bcd-4d96-9291-bba4d69caf3c	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:12:37.388415+00	\N
187b1117-249d-4762-a245-4e651510727e	6faff9cb-851d-4fcc-8478-a18c83228de5	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:15:47.122132+00	\N
7955863d-2584-4bfe-b706-8c73a5ac0167	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:17:57.350648+00	\N
2ee3a92b-de03-44b3-b87e-52a1412b01a7	ba28ef00-70b2-4902-94ff-cd4545a1e506	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:19:17.253652+00	\N
16db488c-8b1b-46ac-b10a-cc473c5667de	79f46b6a-9be6-4131-a71b-79f864b7efe6	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:20:19.855329+00	\N
93615c14-6482-4430-a0d9-c144fe261e12	55170fd5-00ce-4241-9620-ee6dced18987	2	2	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:21:27.24692+00	\N
63d0af46-daec-4a46-8570-002f1d8e0a39	0a2d780b-6404-4826-a300-d6c89964ae40	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:22:33.170715+00	\N
bee27afc-b1bb-4515-83c3-4abec2c1e21f	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	6	6	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:26:04.88851+00	\N
7a574de8-49d7-403e-b4d0-45bd0dd912c9	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	15	15	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:29:18.840437+00	\N
9d006dbb-5b8c-4514-9ce5-3ac05916a057	9d3efcc1-82a7-4697-9aca-9c11c4a31037	2300	2500	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:30:49.716027+00	\N
7926c793-db53-4e33-a1f9-1438014ca253	2d096f70-6b8d-4a45-a9b9-0388c96a945d	1	1	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:32:26.761328+00	\N
78b233a3-f1a8-4a5d-b4a6-98cf37dc8536	9cbfc261-d617-42b5-be18-97be0da5540b	85	85	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:36:38.056063+00	\N
43e9dc19-7d79-4302-be62-7f105d11d29d	4a0b448d-3fb8-4474-a9d9-267f5319518f	3	4	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:42:48.909531+00	\N
cadb62b2-c117-4407-98c1-841f21b21c20	5a072e55-b0c1-4102-9b9f-6e786d9a2343	18	18	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:46:43.250801+00	\N
5a09cff3-4591-408f-ac53-5778b104032c	94d568da-7421-440c-839d-30290b500f97	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:49:17.042516+00	\N
62e77a08-cbf9-4c0c-a16a-48e01bb53109	2506f42e-d3d7-41f8-ab97-0473118c3630	5	5	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:51:15.45247+00	\N
a35983da-66eb-4410-bea7-6df0b93ffdb3	49147609-1a68-4612-a2a5-3845b60a2d38	50	50	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:52:18.141454+00	\N
ac84ff18-ae51-4333-a997-a88fe48768a6	2589ccdd-7774-4eb6-952f-aff007ddc585	500	500	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:54:20.93816+00	\N
36579a6e-2391-4155-91e6-c6df697b042c	5325af28-0ff3-479d-ba25-2507b2dcb708	1000	1000	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:55:19.10569+00	\N
65440439-098b-4d1f-9e05-48cbc1cb0e48	9db7aae9-12d8-4716-aff7-0532026f939a	1	10	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 10:56:39.746481+00	\N
410eb004-3135-44db-ac40-8ae0e4922ff9	598eb297-3ff5-47e5-8cb9-5904f6bbf516	24	24	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:00:05.004468+00	\N
8a48991d-d2a3-4daf-be60-bc3a38d3b1b7	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	94	94	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:10:04.940058+00	\N
9605764d-4d51-494f-a00d-682dbb927f97	ec733761-dbcb-4ae3-839b-8f759f29057f	2	6	adjustment	\N	Correction	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:12:48.674876+00	\N
282586d5-380e-4a4b-8a01-64d3987520af	571fa9c2-9b3f-4171-aebe-a02e9a9e79db	3	3	received	\N	Opening stock	a6271f16-534a-4325-aee1-5ed0ab3eb261	2026-10-16 11:21:30.398568+00	\N
d652e59f-121d-4760-8a90-f60a15ec9b25	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	1	33	received	\N	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:36:58.896125+00	\N
a7315ce2-7daf-4a11-a63d-98b7d81763eb	6e4cc8a8-1d22-4ec1-a8c2-3a897dee3ed1	-1	32	adjustment	\N	Correction	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:38:03.728297+00	\N
de1344a8-82fc-4d83-ae9e-2222a3bf65d3	50ab9fee-98df-4ae0-ac78-4cbbc592272d	-1	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:40:14.448504+00	\N
9e14c553-44f3-41aa-a74d-a2846c1a15df	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	-1	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:41:24.978977+00	\N
625955ec-09e9-46d7-a855-bcc52e14daf5	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	-1	93	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:41:38.551529+00	\N
46397558-13f5-4a01-974d-a061f2159219	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-3	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:42:36.01917+00	\N
de45fb1d-d55a-490b-8c0c-e15a17a0a90c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-3	64	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:43:33.688274+00	\N
59651727-c0b6-40f0-8bb6-1ce7c456ec24	e1d8a6b9-b965-479f-a777-f85b0df18c59	-1	23	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:44:00.11749+00	\N
b5086c26-80b1-4378-abff-923435fb4154	7640cb52-77e0-4374-a235-bdb6e0d41503	-1	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:44:16.151972+00	\N
43321001-5fd3-4922-af88-40786cf7692d	0f0811e7-e8e8-4aab-a086-25b1d3bbe31d	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 13:47:46.004914+00	\N
106270d7-3314-4bb3-a6fd-b92deeb1687b	0ded23de-1d23-4279-b783-1e5c5a59ca5d	-1	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:43:26.88346+00	\N
095dcb1b-cc5f-4f44-af0c-0e832da9b7c6	598eb297-3ff5-47e5-8cb9-5904f6bbf516	-2	22	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:43:52.577425+00	\N
b8b96552-b864-4129-983b-d6b8f48c7b6b	371b2c03-2b4b-4a87-87f4-bd2694338ef5	-2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-16 14:44:35.144694+00	\N
2cca9c91-d43b-423c-a2c5-63b6ce5c43aa	929c42a1-1e18-4063-9cf4-f75586cdd858	2	2	received	\N	Opening stock	82735742-c8fd-4042-b60f-67a9fca0d0ab	2026-10-19 08:55:32.53582+00	\N
1a32fb8f-4e67-4348-9136-c77243ef60de	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-5	37	sale	b8dc1b57-18b7-4f58-a906-a6f699a11711	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 09:47:55.885325+00	\N
1078f04d-cebc-4125-ba31-42dd470e3f9e	0a2d780b-6404-4826-a300-d6c89964ae40	-3	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 13:30:58.14399+00	\N
3422c99e-f38c-4ef0-8f3e-5a59eaf8d8d0	371b2c03-2b4b-4a87-87f4-bd2694338ef5	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 13:31:49.118126+00	\N
e412f2d0-e5a1-46c4-98ac-0acf7749528e	55170fd5-00ce-4241-9620-ee6dced18987	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 13:32:13.727513+00	\N
bc5f0dd9-4295-4329-8d88-7b163632b158	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	-2	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 09:16:59.885638+00	\N
e2ce6b1c-3227-4c55-8390-dffa1fa1b6fe	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	-2	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 09:17:24.114025+00	\N
75972171-1c7b-47f8-8485-a06d70d4cfc0	c8247369-36e0-4af0-99cc-13be486f3c9d	2	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:55:00.962008+00	\N
826e7c36-605e-476a-9ed1-51798b1509ee	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	3	4	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:55:32.189919+00	\N
6015de5c-5de2-4614-971d-cec4b98f228d	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	3	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:55:56.509062+00	\N
74f4a656-f705-429c-b45b-e742374f6f37	91abfef3-d9b8-40d2-9109-a66e97f2607c	2	4	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:56:17.514132+00	\N
12203fcf-6c00-42ec-850d-820bbb9c3908	280a9428-5bc6-41a2-beee-924f8d94d88f	1	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:56:41.218609+00	\N
26b2e9de-bfd4-42dd-9ed2-3f5cdc3a3201	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	2	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 10:57:08.121019+00	\N
9fd0a9c3-fde8-4716-adb6-376daa3a1b4d	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-1	12	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 11:40:04.238113+00	\N
c0a0bc71-2289-46de-a18f-858568c48d5e	2cf77d43-efc0-4773-9519-610d10df99b7	-2	14	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:31:33.75859+00	\N
14b787f7-32bc-4cb7-aceb-8e10cc676fba	2cf77d43-efc0-4773-9519-610d10df99b7	-2	12	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:33:15.074165+00	\N
8a94e337-74f8-4464-9eba-36d35e4da0b8	cb424877-c00e-41ba-a9ab-94854c930087	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:33:34.49885+00	\N
9e465b29-7e26-43d5-bf91-cd46a3cc3bdd	94d568da-7421-440c-839d-30290b500f97	-1	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:40:29.672906+00	\N
807a592b-22f0-4d2f-8733-4106957c8453	507af4d6-75cf-43f6-a30a-3c118c7cd48a	3	67	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:41:27.26592+00	\N
c506a11c-a9f9-4d0d-8a91-474f767bdfe7	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-6	61	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:42:46.567094+00	\N
a65edd3e-b08b-4e81-a5bf-71c76472a8f2	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-1	11	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:43:53.446449+00	\N
274a905a-8f46-4d5d-b4a4-fb2d64db7889	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	1	12	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:44:09.638855+00	\N
424772cc-f072-4eb4-aa24-494dda4baad8	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	8	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:44:28.776623+00	\N
8d013bb0-136f-453e-bccf-2e83022d0c93	2cf77d43-efc0-4773-9519-610d10df99b7	-1	11	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 12:45:02.575632+00	\N
41b44891-dd36-4681-b883-8315cd6061b6	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	-1	15	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:12:38.318928+00	\N
2e130ca0-18d9-4bef-9bda-f421d9b4a0a9	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	19	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:13:04.608348+00	\N
70b2efb4-1a25-4aab-84a9-ff1bbbba5c8c	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	21	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:13:39.585487+00	\N
049cf6fd-f640-413e-94a6-a207021b50fc	12524346-ae4c-414d-a09c-d1fd4640cb50	-1	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:14:27.141511+00	\N
ec43ed31-7d6b-48bb-b7ed-451b86e1df60	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-1	11	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:14:55.126448+00	\N
cc7b2dfb-7705-411e-bb82-ac2ee955ae6b	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	8	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:15:27.265595+00	\N
0f752d5a-c633-4c06-bc9b-f2e0d1856c5e	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	19	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:15:47.728924+00	\N
918e2bd0-98eb-437a-8a4d-9dcf09e088cb	17c581bc-76b8-4beb-8a2c-e00047754559	20	20	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:17:27.951322+00	\N
d71317d6-41d3-4820-abfc-99baa705ae57	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	60	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:18:09.217293+00	\N
546cb465-70d8-45b3-8da5-efd130891e1b	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	59	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:18:44.345403+00	\N
6fd83ec4-20de-41fe-a2e9-9bc453a758d4	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	7	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:19:00.994115+00	\N
20ab6520-ca68-4fb0-b4ed-6d9408f35ef0	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-1	10	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:19:34.632957+00	\N
037f7613-720c-4a29-83fd-520d76d60e97	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	7	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:19:56.188325+00	\N
c3e52679-35b0-40fe-9d28-6d10d1eb6c6c	f5336cfc-123e-412b-9128-4aab6543591c	-1	4	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-20 15:20:25.586592+00	\N
11226e35-ace8-4ca8-ac37-4766799831f7	2cf77d43-efc0-4773-9519-610d10df99b7	1	12	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 08:03:26.815073+00	\N
aaf9a498-ed83-48a6-90e1-17b631e1df1a	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 08:52:37.236486+00	\N
b93d9684-9b41-4392-bbf8-bee420d7ea5e	daea334f-45d9-498f-91c5-c57769160d0b	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:02:05.760355+00	\N
fa533ad1-0159-451f-875f-39dbb3ad223f	051566a2-cdd1-4edc-b86b-afc306c0f1ef	-2	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:02:37.288628+00	\N
bfb52db2-08cc-438f-93d3-978d55760894	f1bd219d-1c82-4b0e-9f30-0d6518f99b92	21	21	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:05:12.008414+00	\N
13753de3-5210-4e23-94a5-6f83d9df3589	697b3608-ae6b-4cc2-bf54-4826386e5ba1	6	6	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:05:44.834181+00	\N
90bb9e07-797a-4a90-85ea-b0b8a50c832f	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	-2	91	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:06:44.905417+00	\N
3d67989b-f333-4efe-b286-02082b9003a6	923b5487-1db2-46d0-a0a3-3af4a83830e6	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:11:31.518326+00	\N
1045d3fb-2f80-45b7-892d-9b85c8546baf	cfbd97f4-63db-4d59-a335-c37e37750f8a	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:11:56.26407+00	\N
1e24fcc5-d7dd-40f4-a68a-ea0b26a04911	3c9fc04b-2f30-484a-9889-9236bd4342a0	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:22:36.968435+00	\N
acc7f0f4-791b-427e-b6f5-a431b602ca2c	75adac4f-8200-439b-8426-0d1986416946	-1	0	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 09:22:55.814188+00	\N
3fce943b-d8e7-4f60-8737-db762bac1720	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	20	27	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:16:48.12401+00	\N
1566d149-e0d8-42b0-82f3-95611a05ea27	3c9fc04b-2f30-484a-9889-9236bd4342a0	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:17:15.646853+00	\N
b997e25e-8c58-43bf-a028-1f47e2deed91	75adac4f-8200-439b-8426-0d1986416946	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:17:29.710659+00	\N
b0f3cbed-396d-408d-af2e-85eeb902a8a8	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	18	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:18:04.498852+00	\N
28b2e361-1592-4c1b-b494-7a56ddd75fab	17c581bc-76b8-4beb-8a2c-e00047754559	-1	19	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:18:21.328577+00	\N
2b7cbfce-2cc0-4b30-ad04-ff2b92d6852c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	58	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:18:56.360094+00	\N
bdddaa71-ca61-447b-ba0e-a8077f8e65ee	34de459c-89d8-4821-9511-5b271b020f1f	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:23:39.8034+00	\N
e53e2fdd-f67a-4fce-a888-569b38ad7a69	fa3c9366-9b08-440c-8725-c5180ae578ee	-3	57	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:37:37.886911+00	\N
4d62e58e-19a2-444b-ad65-f368388fd160	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	10	10	adjustment	\N	Other: Received	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:38:03.618063+00	\N
192c2165-3798-4a8a-bb74-e7f94a29ced9	929c42a1-1e18-4063-9cf4-f75586cdd858	-2	0	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:41:22.710219+00	\N
a42f6822-fed4-493c-aede-d808d34ac171	55170fd5-00ce-4241-9620-ee6dced18987	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:56:26.705676+00	\N
a6f7643f-4b4e-457e-9b63-d14803b1f50d	4fd457b6-2f0f-4771-b8fd-d54283355d9a	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:56:54.923335+00	\N
09bf5843-0619-488b-93a7-7eb7b521f6da	59c06c74-f342-4be2-bc93-547b7f242c03	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:57:11.08464+00	\N
44c9cea6-f339-4408-b022-7df7e52631ba	41a1e8b0-5a6f-4bda-8604-ac6eddaa0a14	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 11:57:26.792401+00	\N
2b310781-d92d-4300-a9b3-906e9c241de1	d4790878-c6c0-4c47-8c42-d8fdee4727d0	-2	0	adjustment	\N	Other: Stanco	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 12:45:22.312388+00	\N
02c85d99-8b1d-4b5a-ab74-6198cd20ac18	0eaebabc-c4c6-414f-9b9f-adc3f94f66da	1	1	adjustment	\N	Returned to supplier: Stanco	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 13:47:37.544133+00	\N
f9fdb20b-1323-4dca-802d-c79b80610762	d4790878-c6c0-4c47-8c42-d8fdee4727d0	2	2	adjustment	\N	Returned to supplier: Stanco	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-21 13:49:01.846166+00	\N
fbd8fa2d-2b08-4359-80cc-a403e99743e9	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	1	hold	\N	Pending order for Sonoscan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-19 09:47:07.157806+00	\N
efedf10e-bbd9-475f-a402-e445bd341cab	c8247369-36e0-4af0-99cc-13be486f3c9d	1	4	release	\N	Pending order for Sonoscan deleted	82735742-c8fd-4042-b60f-67a9fca0d0ab	2026-10-22 05:15:34.939482+00	\N
95c7a356-f8bc-4188-82e2-00f09695d79f	154fbfed-8711-471d-badf-6bad744ce246	-2	8	sale	a7444737-9725-4c82-a742-028e54a28d9c	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:40:19.005624+00	\N
59007656-238c-403f-9c7f-0ccf1b70dfa0	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	56	sale	a7444737-9725-4c82-a742-028e54a28d9c	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:40:19.005624+00	\N
e3b850cc-ffa4-4d20-9b0e-2c8c1690001c	12524346-ae4c-414d-a09c-d1fd4640cb50	-1	4	sale	a7444737-9725-4c82-a742-028e54a28d9c	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:40:19.005624+00	\N
f7921177-742b-4096-8bec-8f86744feba2	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	-1	14	sale	a7444737-9725-4c82-a742-028e54a28d9c	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:40:19.005624+00	\N
dba11f4e-566c-41eb-95e8-58cc286cf2e0	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	25	sale	a7444737-9725-4c82-a742-028e54a28d9c	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:40:19.005624+00	\N
07b07ac7-bab3-47fc-82ef-7b9a473e208e	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	-1	2	adjustment	\N	Other: Eva	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 10:46:21.768446+00	\N
310c9256-b959-4fa9-923c-fb7783ea6c90	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	14	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:08:23.68648+00	\N
4ef29d55-eb4f-4776-a9b0-dc533416975b	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	7	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:08:55.143257+00	\N
81f8e609-8744-45eb-858e-fac4cc7c36b7	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	2	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:09:16.264138+00	\N
9258b663-ae21-438d-8933-2c32b99f0b9c	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	6	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:09:33.099846+00	\N
4e74f59f-1df4-47ec-94ce-3fef524fd153	cb424877-c00e-41ba-a9ab-94854c930087	-1	0	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:09:50.608684+00	\N
b0a83f1d-2870-4b13-b64c-3eeb73183b0a	2cf77d43-efc0-4773-9519-610d10df99b7	-1	11	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:10:05.956974+00	\N
f497ac2c-6b23-4977-855f-93aec981aeb3	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	2	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:10:20.379056+00	\N
3c5d64b1-8581-4a62-a13c-2a02419604e8	c8247369-36e0-4af0-99cc-13be486f3c9d	-2	2	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:10:49.40393+00	\N
921825eb-58f2-4975-b6d1-b76db4230aab	ead2b374-e435-4025-bead-d804071dda77	-1	0	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:11:15.654259+00	\N
c1a76c20-4ac8-4a13-94b1-1692b9dad387	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	3	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:11:37.211612+00	\N
ec65b19b-a35e-420d-887b-2e7dfd3d90cd	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	13	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:12:22.85713+00	\N
0193a7c9-e7a4-4ead-8f32-471267a10988	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	6	adjustment	\N	Other: Baffour	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:12:58.536074+00	\N
32f96b20-7a10-4a20-ba27-aabda960d59f	2cf77d43-efc0-4773-9519-610d10df99b7	-1	10	adjustment	\N	Other: Ba4	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:13:17.561255+00	\N
8aab3086-db96-4f3f-ba43-d4a22cee3bc8	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	12	adjustment	\N	Other: Ba4	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:13:57.886635+00	\N
163d2fc9-5fb3-4e99-a504-d820f278c9ba	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	1	adjustment	\N	Other: Baff	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:15:46.148727+00	\N
e15d380d-8683-488a-9633-d54f5bc8d2dc	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	54	adjustment	\N	Other: Baffour	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:16:07.349025+00	\N
609c4942-451e-4633-ba5f-a0eab1ba9438	e1d8a6b9-b965-479f-a777-f85b0df18c59	-1	22	adjustment	\N	Other: Baffour	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:17:33.668158+00	\N
fbd8aef0-f4ac-4cc0-8582-2156db1ad660	7640cb52-77e0-4374-a235-bdb6e0d41503	-1	1	adjustment	\N	Other: Baffour	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:18:02.216175+00	\N
43abfafc-0dd1-493f-97a6-456605b2d169	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	23	adjustment	\N	Other: Baffour	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:19:02.056985+00	\N
1533c1c5-a484-4007-b769-b2bb625e0962	55170fd5-00ce-4241-9620-ee6dced18987	1	1	adjustment	\N	Returned to supplier: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-22 11:24:12.723116+00	\N
39f2949b-ef98-4064-a3f2-544527fd52f7	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	20	adjustment	\N	Other: Trustcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:27:11.614883+00	\N
7bccc68d-c002-4a86-9b01-69c462928c2e	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	18	adjustment	\N	Other: Trustcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:27:30.911072+00	\N
75630df7-8a96-4e67-8f43-7ff4c8a275d1	2f1bb631-b9aa-435b-9217-341aa3fe9ada	-1	4	adjustment	\N	Other: Orion	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:28:27.488451+00	\N
d13552c1-f696-4e2e-804b-72e4cc53cc7a	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	22	adjustment	\N	Other: Orion	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:28:57.850998+00	\N
795463d6-31bd-4744-9afe-2c1cc16cc591	e1d8a6b9-b965-479f-a777-f85b0df18c59	-1	21	adjustment	\N	Other: Orion	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:29:31.141889+00	\N
22bd2f75-88ad-48ec-86ef-a240912fc11f	7640cb52-77e0-4374-a235-bdb6e0d41503	-1	0	adjustment	\N	Other: Orion	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:29:54.29071+00	\N
3edbbfbf-3ee7-46d8-a668-4ec6b63a8f17	65f2bdb9-292e-4f42-87af-ba69db497a1d	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:30:22.883096+00	\N
2ffd69c9-1700-4e92-ac91-883bde0f2933	659be18d-7cb2-47fa-a814-6d48cc07b97b	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:30:43.309355+00	\N
d72b38d4-4e7c-4243-994b-b1a59492635a	461e45a1-6171-4515-9ada-d619ef45641b	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:31:07.438808+00	\N
b6c190ee-3fa0-46c4-8b40-60b335d27ece	55170fd5-00ce-4241-9620-ee6dced18987	-1	0	adjustment	\N	Other: Adiebeba	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:31:28.650649+00	\N
7342f1b0-5e54-4c9e-b0f9-64837baad18e	17c581bc-76b8-4beb-8a2c-e00047754559	-1	18	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:32:25.472647+00	\N
e4b331af-ccb2-4f32-a0ca-bc8e6cf59b81	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	17	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:32:38.109649+00	\N
160fa1d3-b8fc-408b-9753-89d58030ba45	12524346-ae4c-414d-a09c-d1fd4640cb50	-2	2	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:32:58.712141+00	\N
b9e7f0e6-5c9c-4fc4-b843-074b8e3cc8fc	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-3	19	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:33:36.39992+00	\N
ed9d154e-1d3b-4580-b4cf-bb33e97e02d9	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-3	51	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:34:01.633384+00	\N
f6a631ec-a8a9-45c8-a35f-3a4ba285ae5c	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	17	adjustment	\N	Other: Dimmer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-23 18:34:47.270852+00	\N
eca79aa4-2e17-4c45-90e8-a26c4764cc86	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-1	9	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-24 17:40:49.521961+00	\N
417a8213-57b4-4815-b356-4dba03235f2f	f5336cfc-123e-412b-9128-4aab6543591c	-1	3	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-24 17:41:16.110224+00	\N
331e597e-a1a9-4d44-a578-3850f058656e	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-1	36	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:48:51.676424+00	\N
c9f85720-01b1-4260-915f-829ec82e7a6f	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	17	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:49:31.156134+00	\N
77ed65c1-df70-4e9a-8430-7fb86df74edf	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	-3	7	adjustment	\N	Other: Mr Otabil	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:50:19.523676+00	\N
60f28c80-4388-472f-9655-4ff029e9996b	613b356c-997c-425c-98f3-876bb2203c6a	-3	4	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:53:44.746208+00	\N
87025be6-6a57-45ed-8f5f-ae0573150680	c02fa806-d252-4315-b4ae-b1ea0846c420	-1	15	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:54:59.126904+00	\N
3d0479ac-6fc2-4072-a8e0-d61d1b1df4a8	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	16	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:55:50.660273+00	\N
dd45fa7d-74d4-49da-bf3c-87a4bafe8849	17c581bc-76b8-4beb-8a2c-e00047754559	-1	17	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 10:59:52.355086+00	\N
b9a77fc5-b418-4b19-805f-819b3b5a89b7	571fa9c2-9b3f-4171-aebe-a02e9a9e79db	-2	1	adjustment	\N	Other: Kumasi South and Tech	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:01:14.251028+00	\N
7d56d938-ddc8-4773-b0d4-ce27f12102bc	a7206327-20b6-44b6-b489-d2f563ee49b2	-1	2	adjustment	\N	Other: Kumasi South	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:01:43.039699+00	\N
97373934-3783-49e7-9ddf-ce6a835f1f44	ad538600-13a1-417b-93d5-18a7d808d596	3	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:07:44.677612+00	\N
95be8125-e71f-4e61-b41f-4fb6e075e023	ad538600-13a1-417b-93d5-18a7d808d596	-3	0	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:08:10.948052+00	\N
098736d0-4d37-4c15-ae92-3aea686e71f9	9ff4f240-9f00-460f-87f1-e745c6647e36	3	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:08:21.926623+00	\N
0992b48b-625c-429a-b974-0c984686a1aa	ead2b374-e435-4025-bead-d804071dda77	3	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:08:36.50549+00	\N
66853138-af1d-475e-949b-01d76a1505ef	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	2	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:08:53.531239+00	\N
acb68760-de8a-48d3-b7b5-22a95bd9f19c	cb424877-c00e-41ba-a9ab-94854c930087	3	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:09:11.070481+00	\N
e587fab6-9353-41b9-885d-c2f55a28189e	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:09:26.977158+00	\N
26a51996-7d5a-4147-9e97-0a2bd2915ad5	9977e869-da83-4601-bee1-77d5e29f1ed5	1	1	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:09:58.235296+00	\N
300407b8-a752-4609-bf11-2d85b678f45c	561a9cbb-7026-4bed-becc-73e235cb6f79	1	1	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:10:20.484338+00	\N
bf4f29f3-43e7-4e43-a798-61e0cb5dae84	0a2d780b-6404-4826-a300-d6c89964ae40	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 11:38:27.325488+00	\N
5f2e3ac3-aec8-44ff-a44e-b50808f83d41	4cd01e41-701c-48c4-991e-459cc8e31a3b	-1	3	adjustment	\N	Other: Elijah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:05:20.813398+00	\N
c117d18f-23c4-41c2-b628-0bc5887610be	7640cb52-77e0-4374-a235-bdb6e0d41503	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:06:00.961074+00	\N
ac7740ae-98e0-46d1-8223-f19cba35bee8	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	8	11	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:06:18.182342+00	\N
8d26d2a0-57bf-4314-b5e1-7489ea955419	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	10	13	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:06:47.59543+00	\N
2071cfb9-f5c3-4656-b373-dbd245a0bee3	0f537939-ec3d-4520-8ec6-450b21480858	20	35	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:07:00.792237+00	\N
3b3fe854-0a73-4b17-b7eb-45180d43dcfa	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	20	56	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:07:16.036434+00	\N
ce07c516-0c6e-467b-92e0-c3d6ac5cff07	cab8db31-f31f-433f-8bf2-8f551509c2f7	3	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:07:31.066268+00	\N
c285d80b-6ef2-4419-8b62-c019e76de890	bd357ee5-7fff-4f95-8ca9-144fc25b9d4d	10	10	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:08:10.127998+00	\N
911e069c-2563-46e6-9baf-ebe9f8e4d203	b9b11539-9378-401d-b02f-1a6c57468a00	5	10	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:08:28.977184+00	\N
3162a013-19d9-42dc-93fd-31eca73edfb9	5f6badbf-8cf8-4416-9bf4-873503e719c5	2	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:08:55.839431+00	\N
077c1a70-de87-4993-bfc6-11689f4fbea3	d95e9245-a421-4351-89a2-6c363c15c948	2	7	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:09:08.138163+00	\N
ea401450-3da1-47fc-8679-258e42f580a1	d5ef0c98-1636-44ab-beb9-00c32af409e6	10	13	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:09:24.619315+00	\N
b014bf24-4d0a-4be1-9716-5ec97e96748f	4cd01e41-701c-48c4-991e-459cc8e31a3b	3	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:09:42.943339+00	\N
9e38097e-9571-4b6b-ab8a-992fb86d92b2	ee10fbe5-4a96-4440-a3fb-b29fa0de930b	10	10	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:10:20.679408+00	\N
5b8cbf57-83f3-4bf2-9cd4-28da15bff139	0ded23de-1d23-4279-b783-1e5c5a59ca5d	-2	4	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:33:36.032046+00	\N
99ab0e18-037b-4874-9411-5ef5cf637b26	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-2	10	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:34:01.08397+00	\N
1004b744-5562-4c2c-8276-5c94955b8694	561a9cbb-7026-4bed-becc-73e235cb6f79	-1	0	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:34:14.418935+00	\N
d1dbe04d-dd68-4677-b85e-b8828ce9f9cb	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	2	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:35:23.566815+00	\N
bb902f59-9bbb-4928-8f1e-7554df999f8e	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	6	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:37:34.267995+00	\N
3afcf8da-013c-4d33-b1b6-970271b20705	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	16	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:38:05.021929+00	\N
cfbcaf0f-de97-4cbd-9bb4-dcf0bdf1b279	3572f4d3-23dc-405a-a94e-3fa793df5fee	46	47	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 15:50:26.383681+00	\N
965d5cfb-b3b9-4328-954c-5b7d007696e9	4cd01e41-701c-48c4-991e-459cc8e31a3b	-1	5	adjustment	\N	Other: Henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 16:08:14.582008+00	\N
bd774e72-a777-4829-869b-5c4011529a23	cab8db31-f31f-433f-8bf2-8f551509c2f7	-1	4	adjustment	\N	Other: Henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 16:08:32.865138+00	\N
3c183d8d-4cb7-4a87-ab1e-af09f40bbc5b	5f6badbf-8cf8-4416-9bf4-873503e719c5	-1	5	adjustment	\N	Other: Henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 16:08:51.548022+00	\N
4c3117db-33b8-4df3-ab5d-b5b693681261	d95e9245-a421-4351-89a2-6c363c15c948	-1	6	adjustment	\N	Other: Henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-27 16:09:19.210212+00	\N
5121e3bd-4a30-4db0-bcfb-cbd7180b779c	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	19	adjustment	\N	Other: Rabito	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:40:12.642509+00	\N
8caafb5b-f6ff-4513-9c6e-4f9c5babe579	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	16	adjustment	\N	Other: Rabito	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:40:32.899759+00	\N
8cda4c1e-80a5-4591-b474-02b43acc6e84	190becce-9184-429f-b602-55c7beecea24	-1	0	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:41:17.279071+00	\N
f521435d-0e68-4135-85a3-333729889120	f2b1be08-5c83-4eda-8b9f-6ea582926dc1	-1	0	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:41:55.707585+00	\N
eb1fff7e-6910-4561-b9c2-2f3a9d714b20	757ad4e5-8fd5-41a8-8141-bc0909726064	-1	0	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:42:16.723199+00	\N
402da3e3-f3a6-46a4-9ddb-54c93ea633d7	322c6581-1f2b-4a2c-9de4-5a9a8ffd0150	-1	0	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:42:39.005896+00	\N
776ab4e1-27ed-4f75-b7a6-e225c7e0c1e5	8e99c78f-3a46-4b61-84cb-e621621ccb57	-1	0	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:42:54.386803+00	\N
b1172973-6546-48dd-a748-41a62251f27c	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	2	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:43:16.96747+00	\N
3c5bfeeb-d558-4fef-b8b8-97f46ae3ee99	ead2b374-e435-4025-bead-d804071dda77	-1	2	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:43:30.932226+00	\N
03dde4b8-6435-4f02-9cff-e7085afe1999	cb424877-c00e-41ba-a9ab-94854c930087	-1	2	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:43:50.570413+00	\N
e1192f5a-1e7c-46bc-addc-5bb990dc7720	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	2	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:44:05.496766+00	\N
2a326d03-bdc0-4149-b82e-1aa97587fb39	6d4f3554-2ee0-412a-af30-471500879cbf	-1	9	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:44:20.226106+00	\N
40e5304a-5ef9-4393-b6ce-d678de1a394d	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	5	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:44:35.756137+00	\N
e9e7f5a9-e621-4ab4-81fe-58b9dc4aad6f	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	5	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:44:55.720707+00	\N
156f5fe9-e9a0-4b7c-b815-30b892d83ac0	171c693e-768a-4e98-9fa7-b78f91a85944	-1	4	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:45:14.749542+00	\N
a38923dd-0231-443f-b10f-3357cd956bee	2cf77d43-efc0-4773-9519-610d10df99b7	-1	9	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:45:31.631826+00	\N
8b5f8c7a-955a-4925-9d24-a9a03de0a19d	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-3	7	adjustment	\N	Other: Suame	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-28 09:46:04.454081+00	\N
c88e5060-135a-4dc8-9c3a-5bd2cdf3951c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	50	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 14:07:00.38999+00	\N
d29340b4-6829-4251-a7ca-068a3b31ee1c	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	15	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 14:07:22.066146+00	\N
3c8895a5-38df-4f23-9993-ec4cf674bb2d	c02fa806-d252-4315-b4ae-b1ea0846c420	-3	12	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 14:07:39.114723+00	\N
1c575ff4-d91a-47b0-a316-103d0036951b	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	4	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:35:57.104958+00	\N
9549c20a-cb8d-40b5-96be-af13d0a498d2	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:36:19.293661+00	\N
b0cd8f07-2d02-4d87-84d4-3e08a9eabbdf	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	4	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:36:38.792816+00	\N
1676db2b-4688-42e8-af64-b722a6b6a705	ead2b374-e435-4025-bead-d804071dda77	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:37:01.536989+00	\N
9a817501-9378-461f-af0f-9d426fdd413e	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:37:32.925079+00	\N
b4ad9cfd-4dea-46c6-b76e-e66d9f4cb3bb	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:38:02.746223+00	\N
1a5cc319-b8af-4e06-bbb2-014fab372059	cb424877-c00e-41ba-a9ab-94854c930087	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:38:46.758581+00	\N
21b4625a-6ac5-406e-b10e-54499506c819	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:39:10.15115+00	\N
9d350fe4-6a98-4d7f-b514-c925d4a4b352	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:39:44.600659+00	\N
cf9bd152-5851-4c0a-8aa5-bd3d37bd9d62	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	0	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:40:40.482911+00	\N
a338c898-ba64-4347-8dba-fcc220cdb93a	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	6	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:41:02.649427+00	\N
48cb92e4-036c-4ffb-8bcb-9ed695ab2cc5	ea5ebf85-f433-452c-ba48-3f8c921b68c0	-1	15	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:41:38.414266+00	\N
9967525a-17ea-4255-a2dd-002c4ee6f2b7	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	18	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:42:14.260122+00	\N
d3f8ea60-27fa-4a16-a5ee-c88bfb756f84	9b21331b-4332-4cbc-97d3-33ed2ecc6acc	-2	0	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:43:10.12401+00	\N
68f28f6d-b5a8-4ae5-b318-5c4ae0859e1b	923b5487-1db2-46d0-a0a3-3af4a83830e6	-1	0	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-10-29 17:43:58.267277+00	\N
2fe260c8-82f9-4ab0-9158-a67a1dd1e39c	e059c881-7d54-4209-b77c-89e0aa17f462	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:04:38.992994+00	\N
b8966be3-2b41-4d44-9b60-6f3b7ef52b4c	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	1	16	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:05:00.819163+00	\N
57684d26-f155-4153-9187-0d88869cdd7b	12524346-ae4c-414d-a09c-d1fd4640cb50	4	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:05:17.503258+00	\N
3b5be839-760e-4310-b6c5-75339a49a516	3790e5e0-27aa-46dc-83bf-2e2fc39ed784	1	1	received	\N	\N	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:06:02.73381+00	\N
adff8bb3-4e1c-4d20-a6e7-2a539047ddb0	28ae0672-5605-420e-b7d5-2143099672a3	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:06:34.658782+00	\N
ef953b6b-98ad-41e3-b448-071433fbab76	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	-5	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:06:49.902741+00	\N
b59822ff-062f-496f-a587-3a97477e139a	f5336cfc-123e-412b-9128-4aab6543591c	-2	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:07:01.953654+00	\N
08209e35-e282-4227-8b93-d9ad7f1e8415	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	-2	3	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:07:13.785441+00	\N
a08d2943-8163-49f6-b1c3-2a24b490cf6f	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	19	25	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:07:36.134617+00	\N
96c5297b-7e17-425a-9888-9f46182b792b	b50611fb-eeca-4b74-a02a-91e2ea2d9846	-1	4	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:07:56.449935+00	\N
701bcd66-c4d4-44e0-bf8d-407ce6491e96	caa4cb49-6e74-4abf-a9e3-2c8fe5e01ee7	-2	12	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:09:31.214551+00	\N
e184b420-f515-47bc-aba9-62ff76f8b5f7	2cf77d43-efc0-4773-9519-610d10df99b7	-3	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:10:10.336863+00	\N
0c59c7a6-b836-4f45-aa93-ec1ccb01271e	0f537939-ec3d-4520-8ec6-450b21480858	-7	28	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:11:02.005574+00	\N
33ae7286-72f5-420a-9f90-ae7c2a7041db	51291b09-5c9c-4ece-b5ab-caab1507e9e2	-1	3	adjustment	\N	Other: Onga	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:11:57.229811+00	\N
53d53ac0-04be-4d03-9040-b1494f053a2a	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	-1	15	adjustment	\N	Other: Maxwell	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:12:37.092988+00	\N
4727ef4a-eb22-41b9-80fe-376c237b66a7	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	-1	6	adjustment	\N	Other: Saqs	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:13:08.225496+00	\N
206e7531-f253-495c-af6b-cf7f635653db	fa3c9366-9b08-440c-8725-c5180ae578ee	-10	47	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-02 09:13:21.917399+00	\N
88f79eed-ce4a-48bf-b2a8-5b4fa4e58738	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	14	adjustment	\N	Other: Otabil	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:19:07.761962+00	\N
323ab789-6ebd-4132-988c-0050cfa42993	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	-1	2	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:19:44.632582+00	\N
ff42aec0-b3ff-4fb3-a03a-fbdaed859c2e	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-3	13	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:20:32.792985+00	\N
8bfefda7-0202-4f2f-a2fd-a54665210e33	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-2	7	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:21:16.186213+00	\N
adec77f2-19db-4938-8b29-21dbf487dec2	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-7	43	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:21:33.273407+00	\N
04b973c4-f789-42e0-ac02-34d56fff2743	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	-1	5	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:21:48.959322+00	\N
0cb5fd30-66d4-4e58-bd5a-50c8a0123433	467055cd-1828-456d-a743-8a6f62e4ce28	8	8	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:22:29.534141+00	\N
caf7d433-0811-4c86-b434-8c2b9636cfc2	8baabf93-fdc9-41ba-b8d9-799e11986431	1	1	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:23:16.297802+00	\N
ebcbb5bb-2b0f-438d-8855-cd317aabb96a	c73c4429-709a-4c4c-9071-5b1e701f82cf	6	6	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:23:50.727405+00	\N
7f9a25bd-9cd3-4d85-b692-c1e7334f789f	12c37938-1696-4321-ae41-c4472ba319a1	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:25:36.175801+00	\N
0d491e30-1b45-4af9-a09f-a911afae7ede	576cd245-ef27-4989-8960-f52085ab307d	1	3	adjustment	\N	Other: 2800	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:26:00.313443+00	\N
4547efa5-7e56-40e4-8022-730a738ef19e	dc70ad7e-0402-4c06-84fe-4beb2fa3a36f	1	1	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:26:26.089617+00	\N
d363b4a7-dde1-4f33-9302-769f009bbfa0	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	0	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:27:48.984597+00	\N
f917dac6-6889-44e0-af09-eba7a41b7bfe	2cf77d43-efc0-4773-9519-610d10df99b7	-1	5	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:28:03.136969+00	\N
b52ad09e-c251-4e3e-b542-eb016c436bdb	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	0	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:28:28.344059+00	\N
9900b6f8-260f-4bc9-8cbe-a3490609e91e	81ef7ace-0699-42db-85ba-4c050a08a008	-1	0	adjustment	\N	Other: Ike	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:28:46.900074+00	\N
7230ca48-ed9e-46f4-8cff-50b0407ae5aa	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	24	adjustment	\N	Other: Amos	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:29:21.160261+00	\N
e2aa2b19-16fa-4b3f-94e7-fafa326b5253	99777cff-18a4-4e87-bc75-988d35589c33	-1	15	adjustment	\N	Other: Amos	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:29:44.573422+00	\N
c799d094-61ba-4c90-9b3f-8621a7684be7	d359c066-20dd-4f17-baed-699c38753958	-1	0	adjustment	\N	Other: Poku transport	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:30:25.569647+00	\N
d2ca44ac-a500-4627-914c-1ea59cef17d9	91abfef3-d9b8-40d2-9109-a66e97f2607c	35	36	received	\N	Mindray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:30:58.972605+00	\N
5080bbdb-308f-4dec-b287-36eead160398	d6d4fda9-6087-410a-8bc9-0a5622f40e32	10	14	adjustment	\N	Other: 147426015	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:31:40.830097+00	\N
c4696385-923d-43c4-ad4d-2e37c1493156	81ef7ace-0699-42db-85ba-4c050a08a008	8	8	adjustment	\N	Other: 140426011	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:32:09.144797+00	\N
50708a31-48a3-4ead-8cd0-80098b372b39	6d4f3554-2ee0-412a-af30-471500879cbf	30	39	adjustment	\N	Other: 141626015	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:32:51.408696+00	\N
86a108a4-7b5e-44cf-93e3-8135a34584ae	171c693e-768a-4e98-9fa7-b78f91a85944	17	21	adjustment	\N	Other: 141726013	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:33:49.820051+00	\N
36971911-71b1-4cc1-a77a-ce5a8481ba78	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	10	28	adjustment	\N	Other: 150126011	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:34:20.009476+00	\N
c8e17c5b-e0f2-41da-b824-a1c5143caa35	52a235f2-a6a7-446a-b0ff-bdf02a6db56a	12	12	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:36:47.918581+00	\N
6e444b8a-6b69-4a67-b59b-601e01899f5a	a552e2f5-77c6-4565-b54b-e657f0b975e4	12	12	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:37:24.593425+00	\N
c6c3c3b3-92eb-48e9-918e-fc94196f4056	47a585ae-b9a1-44d5-bb04-776aff161924	12	12	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:37:45.069639+00	\N
1d4016d1-b644-4b13-a4f8-6c4ef63f4713	e958369c-dad7-4aff-affb-4f37609e2b25	18	18	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:38:14.144443+00	\N
838f1ee0-aa13-466f-a616-71511ece4233	ea5ebf85-f433-452c-ba48-3f8c921b68c0	6	21	adjustment	\N	Other: 059326012	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:39:29.221543+00	\N
e08c9c18-0b24-4f2c-b812-e4e914224ac7	bab661ed-e425-4095-a183-0c8b35a9a73e	6	22	adjustment	\N	Other: 059426008	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:39:51.315246+00	\N
3ffae0ea-5c1f-44e8-9088-bf4bad0b810b	6c0ed636-bee3-4945-ba22-9947e85b0e8a	12	13	adjustment	\N	Other: 158626003	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:40:29.502151+00	\N
481839af-276f-4143-b6ec-03a022c8f1c9	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	35	36	adjustment	\N	Other: 147526009	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:40:59.662252+00	\N
ddb24dbb-34d7-40d6-ad92-9fda8c670979	9c309e3f-ca58-4ed7-b6f8-1ff19b498864	5	7	adjustment	\N	Other: 141526014	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:41:49.710715+00	\N
c4968fae-ef8a-4e4c-9c73-d340604233c4	c8247369-36e0-4af0-99cc-13be486f3c9d	49	49	adjustment	\N	Other: 141126015	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:43:34.296114+00	\N
ed4a55ca-0917-4eee-81ef-93c2c6ac7f9a	79d3a498-b877-4953-9d58-d7593e7228b9	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:43:59.460026+00	\N
0088cf62-df47-4eb5-8b20-c8b57a182dfc	79d3a498-b877-4953-9d58-d7593e7228b9	2	4	adjustment	\N	Other: 043426003	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:44:50.956477+00	\N
7cfe3687-3931-4e41-8cf4-5cb478fe6a95	79d3a498-b877-4953-9d58-d7593e7228b9	-2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:44:57.369715+00	\N
620aec4c-d2c5-48ff-92d8-c53f3ef68db9	2cf77d43-efc0-4773-9519-610d10df99b7	70	75	adjustment	\N	Other: 142126009	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:45:27.71183+00	\N
26bae9ee-d8d3-4c36-97c9-a53e03383399	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	15	15	adjustment	\N	Other: 140826005	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:45:52.385386+00	\N
7a4bcaee-c4ac-4d8a-a63c-a8624df76245	b5f0a744-b1ac-449a-9b48-4e01ef12dd65	3	3	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:46:33.000345+00	\N
701e1b93-0a1a-4fed-84ea-90cf9c4f26b7	fe9b3591-df32-4986-b2ff-53f59d5322a8	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:47:01.033639+00	\N
289e5c43-4d39-4f84-bfbe-c4f56d2cdc35	ead2b374-e435-4025-bead-d804071dda77	24	25	adjustment	\N	Other: 14022608	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:47:31.728295+00	\N
6fbf4810-acc5-4d23-8ed0-e21c2f994e82	cb424877-c00e-41ba-a9ab-94854c930087	15	16	adjustment	\N	Other: 148326010	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 08:48:06.778975+00	\N
2c9f5fb3-7fa2-4729-bb70-ebe6a0e57b17	421af267-9183-4ddb-a550-00597fb5a6f0	20	22	adjustment	\N	Other: 141226012	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:22:56.455439+00	\N
af1e7bba-2a15-469f-a806-3730628222d1	280a9428-5bc6-41a2-beee-924f8d94d88f	35	36	adjustment	\N	Other: 141326019	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:23:22.598111+00	\N
7dbc1266-9daa-4fcf-8f45-50c9f2816529	12a3cecf-0723-4dac-8edc-c61f04338e8d	3	3	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:23:50.485114+00	\N
04413650-9d07-4c7d-995a-f7602b6b5972	12a3cecf-0723-4dac-8edc-c61f04338e8d	3	6	adjustment	\N	Other: 044626007	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:24:22.999732+00	\N
1cb10cf0-7765-4b33-ab79-f576b0939751	12a3cecf-0723-4dac-8edc-c61f04338e8d	-3	3	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:24:27.435809+00	\N
c59e108d-6305-4253-a44e-aebaabf81d18	cf5815de-94e6-426d-8eca-594e2ef0f803	17	21	adjustment	\N	Other: 140326010	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:25:08.010242+00	\N
233db890-75fb-40d0-9127-1affe6060473	9ff4f240-9f00-460f-87f1-e745c6647e36	20	20	adjustment	\N	Other: 140126019	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:25:31.681893+00	\N
23efc280-c124-4b0a-8116-e98f91b65bb2	7640cb52-77e0-4374-a235-bdb6e0d41503	-1	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:26:37.420113+00	\N
aa47093f-5312-4ef3-8a25-b10792de3ddd	b5fe9c12-b945-4aec-9049-39a8b9159733	-1	0	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:28:49.440729+00	\N
bcc0d423-6547-4cb6-8e72-fb0dee2faec4	328cc8a1-848e-4c8b-ad40-4a6fe279bcc2	2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:29:11.486299+00	\N
ef172195-8047-4bf9-9a8c-fabb7e4ccd52	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	-52	0	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:37:27.93465+00	\N
9f41e2a1-03cc-47a1-981d-6d242ac00a95	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	300	300	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:37:48.802125+00	\N
11a57d5a-6a0e-4f99-acec-0268f5ff3f63	f5cf61f8-72f0-4426-b0b3-2095ee7155b2	-100	200	adjustment	\N	Other: Raymond	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:37:59.700197+00	\N
fd25e11c-a423-4d63-82a5-682defcb12d4	3572f4d3-23dc-405a-a94e-3fa793df5fee	-5	42	adjustment	\N	Other: Raymond	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:38:18.308838+00	\N
40cf5e87-7e10-47a4-8638-9b62b997df61	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	-1	12	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:38:44.815389+00	\N
6224629c-fe1e-467f-b250-d8f91abebbda	0f537939-ec3d-4520-8ec6-450b21480858	-1	27	adjustment	\N	Other: Rat	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:38:59.443285+00	\N
9af94e20-849e-4cdf-8c20-048526dcc02b	6e2e3bf7-34a4-4bfe-b707-1302a5e205ec	-1	10	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:39:29.338279+00	\N
1c1bdf5f-fcca-4856-93b7-33d51f4aaac5	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-1	55	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:39:45.173093+00	\N
af0d299c-e11b-4cdb-aa61-bf1bc146ec23	c02fa806-d252-4315-b4ae-b1ea0846c420	-1	11	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:40:18.261967+00	\N
a47434ed-c57a-4a5b-82b4-02845b7645d8	ec733761-dbcb-4ae3-839b-8f759f29057f	-2	4	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:40:39.252461+00	\N
3692e9cc-0104-48b6-afdf-00974a47190e	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	13	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:40:54.38183+00	\N
16a5e0fd-5377-4188-8e98-d36b4f47e9a2	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	42	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:41:08.944681+00	\N
7e35566e-365a-4b51-847a-3127908d83f9	d4790878-c6c0-4c47-8c42-d8fdee4727d0	-1	1	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:42:23.88193+00	\N
ce9bdcc1-92d0-4ded-acde-1bcdb7448952	56cdbdf2-3b93-46e7-9f90-83373145f827	-1	17	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:42:50.863137+00	\N
f6bd46b8-41a5-48bc-91cf-741f063831d1	bb775507-b788-41fb-ba00-660b1911bba2	-1	1	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:43:04.156357+00	\N
6aabb71e-5d27-4f66-aba4-77bae18b7787	b92fdd4b-cc69-4e01-bdf7-1da0d0903dce	-10	58	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:43:20.158848+00	\N
be9a18fa-1a09-413c-aa25-af4ba2e695e4	dc70ad7e-0402-4c06-84fe-4beb2fa3a36f	-1	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:43:32.979619+00	\N
1d8cf272-b582-4aa2-8346-4b65ff893557	2589ccdd-7774-4eb6-952f-aff007ddc585	-500	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:43:49.411433+00	\N
8c12b136-68d1-4102-a19a-34f4fc4fd650	5325af28-0ff3-479d-ba25-2507b2dcb708	-1000	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:44:08.018343+00	\N
5423231e-e915-4882-aced-bfce07140c3b	613b356c-997c-425c-98f3-876bb2203c6a	-4	0	adjustment	\N	Other: Ray and akonta	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 09:44:30.944279+00	\N
e06f030f-366c-4018-868c-4d940b5c2636	b5fe9c12-b945-4aec-9049-39a8b9159733	12	12	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 10:25:13.247928+00	\N
d07d886c-f7f5-4c98-9ad6-21a032348523	613b356c-997c-425c-98f3-876bb2203c6a	12	12	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 10:25:57.470161+00	\N
8082d532-4b55-4ebe-b289-270fb5c85650	37d50b0d-a5fb-4240-81f3-f704b905cefd	12	12	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 10:26:22.057079+00	\N
09fa69b6-98b8-4476-b9ca-89b53e8c6b83	92a3d14a-f626-4345-8abe-6e843aeb7428	10	10	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 10:26:47.637832+00	\N
f73278a7-99de-4383-8a51-cf10e3155d5e	3a99f833-4946-4e84-9fc8-4e6e9355dc49	15	15	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 10:27:34.755198+00	\N
034573e5-bed7-4fb4-8ab5-d95f5b5b8539	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	12	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 11:58:34.754166+00	\N
a98cf908-e623-4fb7-a3bf-c6c8807d7dd9	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	5	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 11:58:50.035415+00	\N
19e6a979-564d-4dfc-94c3-d2c9be6d8fe3	b50611fb-eeca-4b74-a02a-91e2ea2d9846	-1	3	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 12:01:00.318542+00	\N
363abe83-b0f0-4932-aebe-bd3c2ba63415	17c581bc-76b8-4beb-8a2c-e00047754559	-1	16	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 12:01:14.686277+00	\N
ecec8669-8de5-4580-b52f-18245c91ae07	d4790878-c6c0-4c47-8c42-d8fdee4727d0	-1	0	adjustment	\N	Other: Omar	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 12:18:13.225679+00	\N
26669f09-ebb3-451e-bd6f-5052f9d20b28	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	27	adjustment	\N	Other: Owass	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 14:44:57.245994+00	\N
4d5a6b35-4dba-4e45-b84d-811d43478726	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-3	52	adjustment	\N	Other: Aaron	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 14:45:37.879682+00	\N
c415d6d9-afa6-408a-a892-1c323c4fe337	f1aabb46-04f7-4c4f-83c0-d532953304a1	-20	16	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 14:46:06.856441+00	\N
3474515a-f3ec-4a7e-a16f-e0eba3e3a2fb	aa9ea515-00d3-406b-86ce-e0d78cdbba38	8	8	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 14:47:13.066354+00	\N
47adadd5-98c8-4733-8374-2fe53fe2e5a5	598eb297-3ff5-47e5-8cb9-5904f6bbf516	-22	0	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 14:57:12.934088+00	\N
4e5144e0-1259-498f-9f7f-069b80e1804b	e059c881-7d54-4209-b77c-89e0aa17f462	-1	1	adjustment	\N	Other: Bremang Sda	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-03 16:00:38.045161+00	\N
19b5cbc6-2a3a-4056-b36a-5e7d36d941c3	923b5487-1db2-46d0-a0a3-3af4a83830e6	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-05 09:15:14.307076+00	\N
820b2f4e-6075-4215-bfa8-151f81a48e96	fa3c9366-9b08-440c-8725-c5180ae578ee	-4	43	adjustment	\N	Other: Metro and Wesley	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:48:07.971521+00	\N
7bb0f5cd-fdba-42ab-a007-b85fa3d98772	aa9ea515-00d3-406b-86ce-e0d78cdbba38	-5	3	adjustment	\N	Other: Metro, Wesley and Divine Grace	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:48:54.403613+00	\N
d141b3cf-5467-42b5-b39f-e85308b751ab	0ded23de-1d23-4279-b783-1e5c5a59ca5d	-2	2	adjustment	\N	Other: Metro	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:49:28.439531+00	\N
cca7e645-d9bb-4dea-875a-8e5db210f335	0ded23de-1d23-4279-b783-1e5c5a59ca5d	4	6	adjustment	\N	Other: Aaron	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:49:45.299091+00	\N
ce271c32-e1a4-48cd-b89f-a135215dfc69	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-7	5	adjustment	\N	Other: Metro and Famcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:50:14.194908+00	\N
0057ad02-8aa9-48a3-a60c-f88899a3a74c	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-5	37	adjustment	\N	Other: Metro and	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:50:52.805484+00	\N
45fb6ebd-9ee9-47ac-8c3c-5b61db3b73d8	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-2	11	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:51:51.895405+00	\N
f18f7426-372a-4ca1-83c6-0ebec16d2c2c	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	35	adjustment	\N	Other: Metro	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:51:22.312253+00	\N
18438fd0-b475-47bc-8b4c-3eed2feffc6f	17c581bc-76b8-4beb-8a2c-e00047754559	-2	14	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:52:19.765415+00	\N
90e68166-591a-4763-bd4c-6e477882debd	12524346-ae4c-414d-a09c-d1fd4640cb50	-2	4	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:54:01.637191+00	\N
da8afa9d-88ab-49c6-a87b-ea0f2d424b15	fa3c9366-9b08-440c-8725-c5180ae578ee	-3	40	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:54:29.664968+00	\N
8bf04c78-df44-4e74-a72f-906207bd4a70	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	-4	1	adjustment	\N	Other: Nana Boakye and Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:55:13.17813+00	\N
b8a5f3a7-b806-4398-af01-ca37129ef2c7	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	-5	86	adjustment	\N	Other: Nana Boakye and Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:55:55.825311+00	\N
93fbaf58-f6d8-48a8-b9c0-cc9d6d66d877	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	48	adjustment	\N	Other: Famcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:56:32.206487+00	\N
1e7f7502-adf7-4a87-8837-e3564c8ad419	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	47	adjustment	\N	Other: Famcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:56:49.579579+00	\N
738dd17e-577d-4777-bd86-669b3db81062	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	34	adjustment	\N	Other: Kumasi South	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:59:12.329027+00	\N
bae8c93c-f2bc-4d8e-a579-a695afb6e5f1	0ded23de-1d23-4279-b783-1e5c5a59ca5d	-1	5	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 17:59:47.633478+00	\N
4602d9b5-0b05-45c9-9d86-3466c0d5d229	75adac4f-8200-439b-8426-0d1986416946	-1	0	adjustment	\N	Other: Omar	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 18:00:18.646177+00	\N
7f57f642-8825-48ad-a071-b84e036c532f	056fe8d8-9df5-4505-9a85-faaaf1cd5377	-1	1	adjustment	\N	Other: Omar	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 18:03:36.863807+00	\N
6ffc5adb-1ac7-4ba0-90f5-1b50a0af769d	ea5ebf85-f433-452c-ba48-3f8c921b68c0	-1	20	adjustment	\N	Other: Owass	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 18:04:22.131646+00	\N
27903ae8-a400-40c0-be00-30288435eb9d	ea5ebf85-f433-452c-ba48-3f8c921b68c0	1	21	adjustment	\N	Returned to supplier: Owass	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-06 18:04:47.758506+00	\N
9b7ecb6e-0db1-4f07-be50-54eae7bd5e81	9977e869-da83-4601-bee1-77d5e29f1ed5	13	14	adjustment	\N	Other: Received	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:14:49.690445+00	\N
be7de100-0953-4d33-853d-64ade6fb15b1	9977e869-da83-4601-bee1-77d5e29f1ed5	-1	13	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:14:58.404873+00	\N
90a146bd-71d5-4105-b0f7-efd72611d030	74666bf3-cbf4-4bca-99d1-5cfda8c5ab88	10	10	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:16:05.189958+00	\N
172a2798-8e46-4ac4-aafa-1901788b9ade	aa9ea515-00d3-406b-86ce-e0d78cdbba38	16	19	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:25:28.495558+00	\N
66c68756-ece7-45bd-bf81-3b3331d68266	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	719	724	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:25:57.325541+00	\N
32dd36fa-dd8a-45c3-8eac-5f0e2eea7dba	75ffd9c4-f52f-4312-8858-63386f191793	1	1	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:26:54.646684+00	\N
e87f12a9-cfc6-4fe2-a365-1a9aafd30cd5	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	46	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:28:29.01614+00	\N
168af3d2-110c-413d-9195-89bb49a6ab9b	171c693e-768a-4e98-9fa7-b78f91a85944	-1	20	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:28:46.780391+00	\N
e2cc58c8-dea3-456b-b6e3-1c25b3c81eb0	aa9ea515-00d3-406b-86ce-e0d78cdbba38	-2	17	adjustment	\N	Other: Techiman	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:29:21.82129+00	\N
2ce7b30b-de16-45f5-a4ae-76b4b1caa21c	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	3	adjustment	\N	Other: Osbon and other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:29:47.636051+00	\N
15eb4316-8aaa-4efa-9c70-587403a40bcf	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	10	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:30:02.926724+00	\N
ba73b1d3-b980-40a4-849e-584289ad7de9	17c581bc-76b8-4beb-8a2c-e00047754559	-1	13	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:30:17.039599+00	\N
2bc29bee-da05-40c9-9f98-598bed03d2fa	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:30:25.722811+00	\N
b5483857-7633-4dd5-a041-04d8de6455ca	6d4f3554-2ee0-412a-af30-471500879cbf	-1	38	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:31:06.213189+00	\N
ed252568-0564-4e4c-9ef6-9cc0d2e305e7	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	13	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:31:27.935627+00	\N
4a9cbc26-cfce-49ee-ad48-0a2a968a0169	421af267-9183-4ddb-a550-00597fb5a6f0	-1	21	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:31:50.992169+00	\N
4f3335d2-dd62-4a5f-b133-eae1f5c14e81	2cf77d43-efc0-4773-9519-610d10df99b7	-1	74	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:32:08.912693+00	\N
f2ed32c4-85b2-49a3-b79a-462e75838ded	cb424877-c00e-41ba-a9ab-94854c930087	-1	15	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:33:37.243891+00	\N
5acbae7c-d457-4ce3-acf5-013966d66125	171c693e-768a-4e98-9fa7-b78f91a85944	-1	19	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:34:42.79865+00	\N
dc031ff3-f418-4292-9a5c-42e114d127cd	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	33	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:35:05.192284+00	\N
9ed730b9-12b2-4290-9d30-c2fa00836a0c	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	45	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:35:28.703819+00	\N
5f360b44-be42-42c6-a0ce-c7bde73eec58	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	35	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:35:45.945943+00	\N
e3227839-71f3-4a26-abec-a6331e393be3	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	35	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:35:57.450726+00	\N
72b334fc-be14-4e96-babc-3dff894bb094	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	14	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:36:16.666789+00	\N
e8c9a1d6-75f4-4ea3-83b3-47e4a47ed440	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	20	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:36:29.563839+00	\N
fa0de91a-98c8-419c-8895-b51ce04f4b09	ead2b374-e435-4025-bead-d804071dda77	-1	24	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:36:50.857984+00	\N
d02eb50f-afc6-495b-ad2a-36761d6aa1c0	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	19	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:37:04.381993+00	\N
f38561ce-1349-4e82-ad15-c4b3833b8af6	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-3	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 13:42:57.845138+00	\N
1056deb5-6306-4dd9-9110-5a33e7d5cd54	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	35	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 15:41:22.174495+00	\N
852c035c-d8e9-4d1a-a0af-a9edf8d25476	2cf77d43-efc0-4773-9519-610d10df99b7	-1	73	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 15:41:45.207497+00	\N
1dc549f1-0d01-43aa-a133-61e69f8a2e8f	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	21	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 15:42:43.782236+00	\N
4628ec2e-85bc-4f87-a5b6-2ccc7d10b17f	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	26	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 15:43:14.546379+00	\N
acbcfa87-7daa-43de-888c-8e4749f7908a	fa3c9366-9b08-440c-8725-c5180ae578ee	-2	38	adjustment	\N	Other: Asokore	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-09 15:43:46.87698+00	\N
445cc9cc-023f-4ab4-904f-51b2ef9385e4	7fecdac8-2555-4a55-972b-e44c988f2e3b	-1	4	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:22:14.440995+00	\N
49e6bed3-ab1b-4764-919f-5ddf00d1f032	4cd01e41-701c-48c4-991e-459cc8e31a3b	-3	2	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:22:27.706492+00	\N
d7801e41-6e33-4387-95cf-aafa8f89172c	308fcffa-e9b6-4762-a000-74f95c9ca638	-2	1	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:22:37.534987+00	\N
18beca4e-374e-4668-9b36-481f42b857aa	5f6badbf-8cf8-4416-9bf4-873503e719c5	-1	4	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:22:48.106007+00	\N
405157ef-d14c-43b4-a9ce-593f0e1eb007	b9b11539-9378-401d-b02f-1a6c57468a00	-2	8	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:23:07.552209+00	\N
e1bb29f6-7b68-418c-957f-884a5372f65e	d95e9245-a421-4351-89a2-6c363c15c948	-2	4	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:23:17.563955+00	\N
c03ba562-db85-42d8-ad6f-a0b6bdcf4ac1	d5ef0c98-1636-44ab-beb9-00c32af409e6	-3	10	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:23:33.838662+00	\N
1def39ef-9bd0-4345-ab47-0df4878b363c	ee10fbe5-4a96-4440-a3fb-b29fa0de930b	-3	7	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:23:42.770807+00	\N
448199fa-b40a-4d1e-a8a9-1bc168d33249	bd357ee5-7fff-4f95-8ca9-144fc25b9d4d	-2	8	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:23:56.04574+00	\N
4a796606-7a8b-42ac-94ce-a0278fa98e0b	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	-2	7	adjustment	\N	Other: Dicon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 08:24:12.468434+00	\N
09738a28-f817-454b-b69a-69cfe507835f	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-5	30	adjustment	\N	Other: Church of Christ, Kwaku	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 09:08:26.708172+00	\N
08589df9-d6ed-4d3b-a85f-dee52b5378d6	ea5ebf85-f433-452c-ba48-3f8c921b68c0	-1	20	adjustment	\N	Other: Snr	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-10 10:22:03.113481+00	\N
f751ef7a-7864-4fdf-83ba-188d994b1695	9977e869-da83-4601-bee1-77d5e29f1ed5	-1	12	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:35:40.678058+00	\N
a673c776-adb1-4304-a91c-c0b5c3cf05b1	23f521a0-b968-4fa8-9de0-4e3668bb8e0a	10	10	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:36:29.587481+00	\N
d5a9cef1-08b1-411a-ba39-21da7fed3d3e	23f521a0-b968-4fa8-9de0-4e3668bb8e0a	-1	9	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:36:46.199901+00	\N
e722fe3a-f624-46e3-8b34-1916801645bc	229a0575-21db-4b59-ad3b-847e58391d35	3	3	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:37:27.022476+00	\N
6fecfe6b-e809-49f9-a588-2a4e001222f9	229a0575-21db-4b59-ad3b-847e58391d35	-1	2	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:37:49.102807+00	\N
8bff5822-f969-4626-a439-4609fdb156a3	d4937cc1-d2c2-488f-bc93-36b8e0186036	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:38:34.943737+00	\N
9b16dd10-184c-4e6b-8eff-aee7d5dec37c	d4937cc1-d2c2-488f-bc93-36b8e0186036	-1	1	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:38:48.202575+00	\N
34a4ee16-ce03-468b-a27b-cc39ff4c7d3b	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	4	adjustment	\N	Other: Martin	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:39:36.248684+00	\N
ab9cec4b-eff7-4e1a-a8cb-05b73ed6ae6d	b50611fb-eeca-4b74-a02a-91e2ea2d9846	-1	2	adjustment	\N	Other: Martin	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:40:01.067582+00	\N
374c1bed-13bd-4d13-a3c8-fd9ebb7c6e65	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	20	20	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:40:18.606182+00	\N
33ceb347-8883-4be0-a72e-c921059f735d	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	18	adjustment	\N	Other: Martin	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:40:47.145022+00	\N
af3271e8-2977-4d35-adc0-b37d35024466	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	16	adjustment	\N	Other: Obuasi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:41:16.075443+00	\N
ed933db5-852b-4660-9df8-c6575f69e89a	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	28	adjustment	\N	Other: Obuasi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:41:36.916565+00	\N
a623f448-2e26-4c12-a7df-141ca9311279	cb424877-c00e-41ba-a9ab-94854c930087	-2	13	adjustment	\N	Other: Obuasi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:42:03.852408+00	\N
5ead290c-2b1a-4fa3-80a8-71b021eaae15	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	15	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:42:29.499922+00	\N
03a60ba5-1bd2-40ae-8e04-07309754f194	d64307a7-c776-44e1-9823-0a94a43d9fcd	-1	1	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:43:33.056305+00	\N
efe52dc2-425a-4c0e-8ec4-3df57ac7ae14	598eb297-3ff5-47e5-8cb9-5904f6bbf516	65	65	adjustment	\N	Other: Aaron	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:44:19.778121+00	\N
7fde47ea-edb9-4da4-a514-c590d7ac980c	cdfc7193-716c-401e-987e-ce20381b3e44	-1	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:45:09.368755+00	\N
d03b4b3e-7d08-42a6-9785-e38d0bddd321	056fe8d8-9df5-4505-9a85-faaaf1cd5377	-1	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:45:26.931465+00	\N
2b13e483-4183-4f44-87df-84a43aad297c	daea334f-45d9-498f-91c5-c57769160d0b	1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:45:50.944668+00	\N
9008a5d3-8f3b-42c3-a963-c329a9ad5de4	6452048e-904a-481d-9879-dfbc9b3b89ba	-1	1	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:46:09.291135+00	\N
556ed415-6267-4926-8c43-e2ee454cc778	3c9fc04b-2f30-484a-9889-9236bd4342a0	-1	0	adjustment	\N	Other: Ray	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:46:46.959911+00	\N
8aaa8dd0-c554-40e2-99a0-2861fecc56f2	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	32	adjustment	\N	Other: Dimmer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:47:22.830433+00	\N
13ede4bf-3062-44f0-8d79-479cf58fd797	81ef7ace-0699-42db-85ba-4c050a08a008	-1	7	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:47:38.622883+00	\N
aaf0b3ee-b151-4075-ae66-a3e4d5f0b9de	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	44	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-11 03:48:05.496328+00	\N
d0ede2c6-dc03-4b8f-ad09-4bcbeba1110e	94d568da-7421-440c-839d-30290b500f97	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 08:57:21.437213+00	\N
2bd91155-05f6-4453-bc38-625a77508887	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	31	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 08:57:43.561601+00	\N
eb56f6a2-8ddd-4658-88fa-bad3d30ed082	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	13	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 08:59:25.169793+00	\N
55c51dab-bc4c-426a-a1dc-8462960f7d84	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	20	adjustment	\N	Other: Mansa	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 08:59:50.859556+00	\N
bc798702-bc88-425e-99b9-3273d08536e0	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	25	adjustment	\N	Other: Mansa	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 09:01:41.114845+00	\N
cd0f35f4-d215-448c-a38d-523b3066a00d	1105f1b4-ddf2-4fbd-baf4-4ab3290486ec	-1	14	adjustment	\N	Other: Onga	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:54:06.565991+00	\N
dacd3948-2276-42f7-b541-35f09da88a06	6d4f3554-2ee0-412a-af30-471500879cbf	-1	37	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:54:50.094318+00	\N
3ccb2542-f580-453f-80a3-47bc31652248	2cf77d43-efc0-4773-9519-610d10df99b7	-1	72	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:56:01.845916+00	\N
57909525-4e9f-418d-a6c2-60de543b8dc4	51291b09-5c9c-4ece-b5ab-caab1507e9e2	-1	2	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:56:39.369569+00	\N
cff5f016-d274-41f3-a0f5-d5131c98f4e6	171c693e-768a-4e98-9fa7-b78f91a85944	-1	18	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:57:02.606197+00	\N
3f6cecc4-3a9e-413d-b7dc-a9fc42dbe469	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	23	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:57:26.406556+00	\N
7916b0a9-6ccb-4a64-acfa-b57731d9c5ef	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	34	adjustment	\N	Other: Sammy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:58:04.780123+00	\N
fd5c903e-88bf-49ca-b2df-c73223bc35e7	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	18	adjustment	\N	Other: Sammy biotech	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:58:28.196869+00	\N
e9e149d7-2b79-4c73-b976-e7e891d46b48	ee10fbe5-4a96-4440-a3fb-b29fa0de930b	-4	3	adjustment	\N	Other: Snr henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:58:59.628317+00	\N
bb7e1e72-ca16-4943-8003-d402aa2ca00f	bd357ee5-7fff-4f95-8ca9-144fc25b9d4d	-6	2	adjustment	\N	Other: Snr Henry	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 13:59:17.034338+00	\N
9505ef89-666d-4aff-afdd-5b49bd9a060a	2cf77d43-efc0-4773-9519-610d10df99b7	-1	71	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 18:58:36.168201+00	\N
923b342f-d3ef-46bf-9705-e51693082481	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	30	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 18:59:09.636782+00	\N
440f3a83-01dc-4c23-9e36-ceade5a1edde	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	19	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 18:59:28.924016+00	\N
5c0dfa2b-83d5-4deb-8fcd-20de5402feb8	6d4f3554-2ee0-412a-af30-471500879cbf	-1	36	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 18:59:44.85796+00	\N
f1d9f8b1-1bf6-4420-9cc9-d9841b863216	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	43	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:00:05.010589+00	\N
0be91a9c-5f76-44d7-9099-bf812d76a44a	cb424877-c00e-41ba-a9ab-94854c930087	-1	12	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:00:23.224821+00	\N
a7bb547c-d932-4c0f-8477-0f3fe12f8da7	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	12	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:00:42.360701+00	\N
f456dfde-0eae-4e9a-803a-9f1e7a357e53	51291b09-5c9c-4ece-b5ab-caab1507e9e2	-1	1	adjustment	\N	Other: Morris	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:00:55.67561+00	\N
b8ac2924-4ccf-4c83-b981-14f7bcde6ec0	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-15	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:01:33.312275+00	\N
16fa8033-8acf-4dab-be8d-c2ebfafa7d11	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	60	60	adjustment	\N	Other: Restocked	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:02:19.194671+00	\N
dede8e93-0c7d-4abb-974a-ec3244dfa488	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	59	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:02:30.340812+00	\N
bb9dbd8d-7164-4fd3-b26a-05aa5f0c3293	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	27	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:02:52.196023+00	\N
1d416efa-d0a1-449d-b69d-994c606a889c	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	58	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:03:03.801866+00	\N
2cb17a12-a0bf-45eb-8001-45133bcfeb86	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-1	3	adjustment	\N	Other: Amedilab	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:03:31.40181+00	\N
ce46daaa-6cd0-4cbf-ae75-97ed3d52da9f	b50611fb-eeca-4b74-a02a-91e2ea2d9846	-1	1	adjustment	\N	Other: Amedilab	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:03:47.337405+00	\N
2d41395f-25a3-4f21-bedb-84fc462548c3	f5336cfc-123e-412b-9128-4aab6543591c	-1	0	adjustment	\N	Other: Amedilab	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:04:05.190393+00	\N
78cd5ae4-b356-45fe-ac8e-9b0ba5e4d7a2	28ae0672-5605-420e-b7d5-2143099672a3	-2	0	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:04:33.450351+00	\N
3ad13830-d694-4039-8147-b31c920e7f13	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-3	24	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:04:49.250384+00	\N
571a7f37-f6fb-4674-bcba-a4049ee401f7	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	-2	5	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:05:13.379989+00	\N
e76477a7-83fe-4b68-8b46-8db1c125f98b	154fbfed-8711-471d-badf-6bad744ce246	-2	6	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:05:31.315714+00	\N
fc3f8dd0-5793-4fa0-9c84-e53824080a55	fda6810f-87ff-4863-9c2b-e0213ac55cc8	-2	1	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:05:52.634213+00	\N
ba90e8a9-4cc2-45d0-9d42-2a72e032afa8	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-5	53	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:06:07.17632+00	\N
c89ddd41-46c6-4a32-97c7-7d822f100dca	92d9c316-0bc5-45c9-904d-706f232663f7	2	2	received	\N	Opening stock	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:06:28.89427+00	\N
37a5e54e-5d41-4e44-bc47-49e0c1cb97bd	92d9c316-0bc5-45c9-904d-706f232663f7	-1	1	adjustment	\N	Other: Medplus	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:06:44.377019+00	\N
ed18554b-659d-482a-b890-addf3e580865	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	52	adjustment	\N	Other: Tony Effiduase	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:07:06.804911+00	\N
1c4816e7-01fc-45e1-9c02-3960ed196fac	9977e869-da83-4601-bee1-77d5e29f1ed5	-1	11	adjustment	\N	Other: Dr Gudu	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:07:33.003176+00	\N
deef2384-72cc-4187-9d90-98960fb035ff	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	50	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:09:11.372788+00	\N
d07e2a33-62bd-4c17-b926-83791f6455db	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	19	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:09:33.2479+00	\N
84750395-cac6-4a60-ab79-230c83d9fad6	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	22	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:09:52.381922+00	\N
01713dfa-f989-4b20-8f2c-055b4dbe2a5c	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	33	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:10:44.880019+00	\N
6836ea03-005f-4572-a9be-73fdb685b3dc	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	34	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:11:24.029192+00	\N
fd1d31c7-f5a8-4d92-a2cb-6505fde00222	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	21	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:12:27.386562+00	\N
e3215b0e-03cd-44f2-ab72-787d6d42777f	e1d8a6b9-b965-479f-a777-f85b0df18c59	-2	19	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:10:20.81993+00	\N
756a8d88-9e30-4399-87f9-2153053cd972	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	32	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:11:10.833827+00	\N
2c1d8738-086e-4492-85b8-882572caa439	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-3	47	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:12:09.141616+00	\N
998f8651-3026-49e9-b960-bc1fd8730a24	2cf77d43-efc0-4773-9519-610d10df99b7	-1	70	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-13 19:11:49.577935+00	\N
a674c273-7245-468c-a377-aa108a7dd46b	fda6810f-87ff-4863-9c2b-e0213ac55cc8	20	21	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:44:35.589733+00	\N
743bc6f8-647e-46a2-9d45-4e91f9bc8287	507af4d6-75cf-43f6-a30a-3c118c7cd48a	20	41	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:45:34.218895+00	\N
d0a85df7-e709-4aae-adb2-320b94720feb	9e6aae26-f12e-45bd-a9f3-e02fdf70ee5f	5	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:45:56.242624+00	\N
9fe1e996-e5e4-4101-9357-506680261259	28ae0672-5605-420e-b7d5-2143099672a3	5	5	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:46:46.37755+00	\N
ccbb5dfd-79ca-4149-86b0-7588ac6ba65a	3790e5e0-27aa-46dc-83bf-2e2fc39ed784	5	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:47:19.946855+00	\N
5eb3e75e-1064-47fd-97e8-a697f5f55cc1	fa450c7d-bc6a-4bf7-b6ac-a45626ac7e65	10	15	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:47:37.043622+00	\N
8ea52529-f163-4f46-b924-d237895e3f4b	b25b958e-dd4a-415b-a5bf-75ef0f70bd8c	5	7	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:47:53.391768+00	\N
62ce0e61-d22a-41d5-aea7-2d4ddc8753fd	2f1bb631-b9aa-435b-9217-341aa3fe9ada	5	9	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:48:21.543708+00	\N
9f2e2900-5070-4909-9990-e3c21ed39090	b50611fb-eeca-4b74-a02a-91e2ea2d9846	5	6	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:48:44.591966+00	\N
0603c788-c5bd-409a-a065-dde8284e541f	f5336cfc-123e-412b-9128-4aab6543591c	15	15	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:49:05.488059+00	\N
057fc59e-ccf1-46e4-9a43-d1215b1f2567	12524346-ae4c-414d-a09c-d1fd4640cb50	20	24	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:49:26.86112+00	\N
048b6963-c546-47e8-b306-0a33aa311252	211da3c4-b29c-4795-8bf3-946c364d239f	10	10	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:49:53.554099+00	\N
3e23e3db-eb3f-42bb-b4a4-66bba72a5a01	659be18d-7cb2-47fa-a814-6d48cc07b97b	2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:51:17.500184+00	\N
f2cb6c7c-ffc4-4d78-9531-7831f0bf2fa8	65f2bdb9-292e-4f42-87af-ba69db497a1d	2	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:51:26.207321+00	\N
6b1ca74d-5c4a-4e08-a57e-e4330f7714ed	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	10	62	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:51:49.316709+00	\N
e08bc844-c6b2-4bf9-8e96-5db11b1bb26a	371b2c03-2b4b-4a87-87f4-bd2694338ef5	3	4	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:52:18.382173+00	\N
7081a2de-fd2b-405a-b499-e4765a2e80d6	0f537939-ec3d-4520-8ec6-450b21480858	-27	0	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-16 17:54:26.019448+00	\N
75dfaa34-4fd1-419a-8f72-b2f2e521725b	ee10fbe5-4a96-4440-a3fb-b29fa0de930b	-2	1	adjustment	\N	Other: Elijah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:45:13.774104+00	\N
780f5044-9ae8-437c-8152-14fe4f4ade9f	b9b11539-9378-401d-b02f-1a6c57468a00	-1	7	adjustment	\N	Other: Elijah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:45:44.172068+00	\N
a599e955-26e0-489f-be7e-01dfd5d621ff	b3fe153c-7bcb-4e6d-ba55-52b16dd5a111	-1	6	adjustment	\N	Other: Elijah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:46:01.732454+00	\N
3ec364f0-c005-451f-8959-8bc21f7e2b04	fa3c9366-9b08-440c-8725-c5180ae578ee	-3	35	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:46:25.288785+00	\N
fdf21bc4-5d1a-44c5-9588-f07df788fcb9	9977e869-da83-4601-bee1-77d5e29f1ed5	-1	10	adjustment	\N	Other: Effiduase Asokore	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:47:00.038796+00	\N
f1090f36-7be0-4b29-96f4-cb8015aca3b0	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	45	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:47:29.720291+00	\N
fd8b26ce-4473-481a-9ad0-9ac7a5e5a79e	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	24	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:47:48.720316+00	\N
67193e45-e768-47e4-afdb-9757b12f4f99	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	29	adjustment	\N	Other: Vednan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:48:12.908167+00	\N
4f39eb2f-0b94-4604-a2e2-26489b8bde36	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	42	adjustment	\N	Other: Vednan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:48:31.250022+00	\N
51a039ec-fb54-4101-8d92-a969c3b2813a	2cf77d43-efc0-4773-9519-610d10df99b7	-1	69	adjustment	\N	Other: Vednan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:48:53.106342+00	\N
0e3ccb19-f8f1-4c8a-a8fa-167b0ab2d1ce	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	31	adjustment	\N	Other: Vednan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:49:14.52552+00	\N
c8b5c59f-526b-4cf9-9c3b-d98c33d1e67d	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-4	19	adjustment	\N	Other: Amos	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:50:15.231657+00	\N
6ff5da7c-8655-4b82-895a-90bce9cceb63	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-2	17	adjustment	\N	Other: Vednan	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 06:50:23.429113+00	\N
a6e3c100-8fd7-4f3d-bc71-d4633f48889c	171c693e-768a-4e98-9fa7-b78f91a85944	-1	17	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:00:41.667995+00	\N
b1e04e40-6678-4e92-bfcf-3f9b22a2b81a	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	30	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:01:01.138057+00	\N
41c48471-0d9e-41ad-ab09-184a2588619e	a7206327-20b6-44b6-b489-d2f563ee49b2	-1	1	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:01:21.318836+00	\N
0b353bf0-1796-4cca-babe-d2039ff541cf	90cdf544-bf74-4d7c-9cef-c2e3148c29b2	1	2	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:02:29.31191+00	\N
3fbcc910-2061-40d6-ad2e-4ddec12d0b22	9b2e77d6-dfee-4a2a-83b0-1224f12875ef	-4	82	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:02:49.431254+00	\N
8c7ca591-16f4-4841-ab8a-f581ca3d608b	c8247369-36e0-4af0-99cc-13be486f3c9d	-2	40	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:03:16.016318+00	\N
2db55aa6-1446-4833-ac14-d1bd853d3239	47a585ae-b9a1-44d5-bb04-776aff161924	-2	10	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:03:37.502714+00	\N
3bea3609-b365-4e8f-bf38-3541aef1ed94	51291b09-5c9c-4ece-b5ab-caab1507e9e2	-1	0	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:03:54.479736+00	\N
a2e08468-56aa-4a56-a6d1-045c46588a79	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	18	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:04:12.219287+00	\N
186fdf33-3059-44a3-b44b-d15874fc9c5e	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	17	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:04:28.790805+00	\N
98653653-508a-4e1f-9f8a-0a60f9213654	81ef7ace-0699-42db-85ba-4c050a08a008	-1	6	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:04:44.951117+00	\N
3f41c8b2-5e3f-4134-bc02-42bb7b633cc4	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	29	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:05:02.721685+00	\N
4ee5502a-3a0a-4e2f-b4e1-ed4a57895ff3	91abfef3-d9b8-40d2-9109-a66e97f2607c	-1	33	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:05:13.03216+00	\N
a0e12204-3d9c-4575-81b2-afc354e1cecc	421af267-9183-4ddb-a550-00597fb5a6f0	-2	19	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:05:44.906818+00	\N
444e02fe-61f6-4af9-a221-6513d3031e0d	ead2b374-e435-4025-bead-d804071dda77	-1	23	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:05:59.998933+00	\N
986612de-cccb-4ffd-ad80-3ddb40ffc8f8	d6d4fda9-6087-410a-8bc9-0a5622f40e32	-1	12	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:06:17.309704+00	\N
91648b01-36b0-4290-bfe0-f91b7f3b0bf1	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	28	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:06:41.19453+00	\N
f3d10779-c64c-4914-abcc-80e2fed04ed9	a9061735-ec3b-4533-8124-e44acec27679	-2	1	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:07:09.777389+00	\N
ac2edcf4-b484-4729-9c64-1f5b602fcabe	12a3cecf-0723-4dac-8edc-c61f04338e8d	-1	2	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:07:31.021942+00	\N
02c31a56-95f3-47f6-ae51-f5b4d22d3a9e	cb424877-c00e-41ba-a9ab-94854c930087	-1	11	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:07:53.423615+00	\N
62a9ef9a-45b0-41d1-8d9c-805b64df9dd6	a3bcccdf-2488-4ee9-a784-1ece4fab3df0	-1	11	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:08:18.896717+00	\N
198ee915-dff1-4786-a910-17f2d76e2cea	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	16	adjustment	\N	Other: Stanko	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:08:35.718075+00	\N
78c255c7-ea5b-45e0-806c-c184ee6ae6b7	3572f4d3-23dc-405a-a94e-3fa793df5fee	-6	36	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:10:01.765465+00	\N
1d2e519f-0ce2-4c35-8ce2-a4bf9ce774d7	e059c881-7d54-4209-b77c-89e0aa17f462	-1	0	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:10:22.280294+00	\N
76405c9d-2435-4385-9bf3-e864359bd786	ce41fcc9-e4f2-4e94-b12f-2220c1ee6297	-2	10	adjustment	\N	Other: Legacy	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:10:58.364919+00	\N
de8739c2-e9a6-4a04-82a2-6fc1d71afffc	9ff4f240-9f00-460f-87f1-e745c6647e36	-1	16	adjustment	\N	Other: Church of Christ	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:11:40.96227+00	\N
00211e7d-bf89-4ba0-a320-0dfe237a0e1b	cf5815de-94e6-426d-8eca-594e2ef0f803	-1	17	adjustment	\N	Other: Church of Christ	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:11:55.695552+00	\N
9891ae72-aaaa-4fec-95d8-eeb49e939fad	ead2b374-e435-4025-bead-d804071dda77	-1	22	adjustment	\N	Other: Church of Christ	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:12:12.391845+00	\N
85ffe715-787f-42ea-903e-734fc9b84bc1	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	39	adjustment	\N	Other: Church of Christ	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:12:31.923808+00	\N
b6e8a562-4711-4af1-bd85-e09b0a7ef18f	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	43	adjustment	\N	Other: Kenyasi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:12:53.931146+00	\N
ff8abf2b-6594-4454-8f61-a4a407977b8d	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-1	40	adjustment	\N	Other: Kenyasi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:13:09.966955+00	\N
c557ca6a-f2f1-4060-80c3-108101954709	598eb297-3ff5-47e5-8cb9-5904f6bbf516	-4	61	adjustment	\N	Other: Trustcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:13:53.105295+00	\N
c2088349-d74d-4f64-a20b-6cb8d455d834	211da3c4-b29c-4795-8bf3-946c364d239f	-2	8	adjustment	\N	Other: Trustcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:14:11.774894+00	\N
de2fef6e-df92-4efe-a572-64155fd28580	1ccc204f-d62c-4f56-9a6b-39281f24d1e6	-1	15	adjustment	\N	Other: Trustcare	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:15:07.322588+00	\N
35cb7f23-606b-45fa-959a-fcace524010b	171c693e-768a-4e98-9fa7-b78f91a85944	-1	16	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:15:29.591766+00	\N
36bc0b4d-aca8-4339-9352-d556630663d6	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	38	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:15:45.157928+00	\N
4def585f-4ea2-4c34-be55-a0f4dbac7225	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	23	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:16:00.108352+00	\N
7a732f7b-c161-4b54-bdf5-6014dd5cab2f	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	18	adjustment	\N	Other: Kidney	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:16:23.233644+00	\N
d74797d3-6d14-4131-ae3f-fe9e756dd9d5	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-2	60	adjustment	\N	Other: Metro	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-18 07:16:51.266869+00	\N
b1a55086-13d7-4b48-8b12-ce553a1dcba2	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	-2	722	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:02:57.684643+00	\N
e14733d3-a8b9-436c-b481-ca06ef2e6c8e	bab661ed-e425-4095-a183-0c8b35a9a73e	-1	17	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:03:53.973198+00	\N
5a31f5c1-bda6-403a-a0d3-cb5bc71be89f	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	22	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:04:15.760696+00	\N
afedc9c3-2f13-437f-a8fd-85ee4e874749	fa3c9366-9b08-440c-8725-c5180ae578ee	-5	30	adjustment	\N	Other: Asafo Agyei	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:04:47.593306+00	\N
9d61c7c9-a22d-4924-ba7a-b33cb7dcdd1f	507af4d6-75cf-43f6-a30a-3c118c7cd48a	-2	38	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:05:23.697006+00	\N
689ad027-a5cd-4f41-a410-71ef8c1305f5	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-2	41	adjustment	\N	Other: Osbon	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:05:42.249265+00	\N
0b071459-5daf-4194-ab12-296e67a7c38e	dc49cc2d-eb6b-4fc4-a1b5-d752d63f5b5a	-1	40	adjustment	\N	Other: Jima	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:06:10.710791+00	\N
d7fe7a05-489d-4af8-964d-d5b227ccab8f	923b5487-1db2-46d0-a0a3-3af4a83830e6	-1	0	adjustment	\N	Other: Uncle	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:06:31.52976+00	\N
d60c9131-af60-453b-b2cc-99fb007d0a50	371b2c03-2b4b-4a87-87f4-bd2694338ef5	-3	1	adjustment	\N	Other: Uncle and ifeanyi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:06:58.607147+00	\N
845626a3-ccea-4965-b3ba-054d18c37599	b2301bdf-af29-4f58-ace6-7dcbfdfea5f8	-1	721	adjustment	\N	Other: Saqs	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:07:34.531054+00	\N
9ec733c7-34c7-4b73-925a-d62fe86c49bf	fa3c9366-9b08-440c-8725-c5180ae578ee	-1	29	adjustment	\N	Other: Kwapra	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:07:51.105602+00	\N
17558e2e-27eb-47de-b85a-00d5462a6d05	9977e869-da83-4601-bee1-77d5e29f1ed5	-2	8	adjustment	\N	Other: Saqs	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:08:13.396246+00	\N
0ffa507f-1ebe-4f90-9e08-b99c8c45e637	aa9ea515-00d3-406b-86ce-e0d78cdbba38	-2	15	adjustment	\N	Other: Saqs	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:08:39.566047+00	\N
177a492a-d757-4982-9abe-d29c396c84d7	dde49bd6-ec7f-49eb-a8a3-e7e79e9256fb	-1	28	adjustment	\N	Other: Mframa	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:09:13.678732+00	\N
5fcf3331-b008-4d2c-9a68-8a12df1f5ef7	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-2	58	adjustment	\N	Other: Marboah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:09:50.224768+00	\N
916d7599-82da-44be-990b-a7c26a4c8d66	211da3c4-b29c-4795-8bf3-946c364d239f	-1	7	adjustment	\N	Other: Ifeanyi	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:10:05.926181+00	\N
83ab1b1a-44ee-4f4d-9f0f-29fb1fcaea4a	9db7aae9-12d8-4716-aff7-0532026f939a	-5	5	adjustment	\N	Other: Marboah	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-21 13:10:24.633024+00	\N
ae30491c-5c7d-43a9-84c9-a8d1b3018bec	950d3492-cf9e-4b6d-b6bf-eaa830f709a9	-4	54	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:16:20.573324+00	\N
1d1a2923-e70e-42e3-9740-f6bfb497a848	9db7aae9-12d8-4716-aff7-0532026f939a	-3	2	adjustment	\N	Damaged	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:16:40.671606+00	\N
18920de1-3e31-40df-bdf7-930bfe8f6719	ea5ebf85-f433-452c-ba48-3f8c921b68c0	-1	19	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:16:56.452109+00	\N
c476c77a-43e3-4d11-8d7b-19e3dd605b83	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	21	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:17:32.382192+00	\N
9b54fe3b-18b4-4c72-af14-fa5bbbdb2adb	62f9f784-9902-45e7-869e-0ce5e8cfdbd2	-1	8	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:17:50.724619+00	\N
5c4dd87f-d42c-4837-a3e4-b6dd163190c8	c8247369-36e0-4af0-99cc-13be486f3c9d	-1	37	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-23 19:18:05.760223+00	\N
1a46e2cb-b6ba-4f47-9665-8f057a6d372d	371b2c03-2b4b-4a87-87f4-bd2694338ef5	2	3	adjustment	\N	Returned to supplier	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:55:00.617568+00	\N
177285ff-4e9b-4f94-9179-d5706939d7e7	9977e869-da83-4601-bee1-77d5e29f1ed5	-1	7	adjustment	\N	Other	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:55:39.099166+00	\N
49f5f32d-0df4-41c1-a23b-93faedcbe27d	2cf77d43-efc0-4773-9519-610d10df99b7	-1	68	adjustment	\N	Other: Snr Collins	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:56:03.64443+00	\N
ebbd1582-fbe6-401f-8f02-acffc2adb30d	2cf77d43-efc0-4773-9519-610d10df99b7	-1	67	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:56:21.988154+00	\N
2912f63a-d01d-4265-9feb-55bc20bc6fab	280a9428-5bc6-41a2-beee-924f8d94d88f	-1	27	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:56:37.10277+00	\N
9d26fb0f-e46f-446c-b78a-5d6ee15c087d	421af267-9183-4ddb-a550-00597fb5a6f0	-1	18	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:56:56.676643+00	\N
312b5708-0598-4d2c-b5b4-b14486cd74c5	ee6fe6e3-87aa-4930-8a88-97f801e23fe0	-1	20	adjustment	\N	Other: Dimer	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:57:13.38011+00	\N
38f0f0ab-ecb4-45a3-9ef4-96907493c96d	cf5815de-94e6-426d-8eca-594e2ef0f803	-2	15	adjustment	\N	Other: Saeed	34cb4aa6-890b-4397-bf22-95f48620affa	2026-11-25 06:57:38.050456+00	\N
\.


--
-- Name: orders_order_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_order_number_seq', 2, true);


--
-- Name: receipts_receipt_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipts_receipt_number_seq', 1, true);


--
-- Name: refunds_refund_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refunds_refund_number_seq', 1, false);


--
-- PostgreSQL database dump complete
--


